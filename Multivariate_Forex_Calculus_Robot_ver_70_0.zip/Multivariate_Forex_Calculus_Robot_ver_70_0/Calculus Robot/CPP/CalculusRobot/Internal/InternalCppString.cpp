/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#include "InternalCppString.h"

bool IString::AreEqual(IString a, IString b)
{
	return a.m_String == b.m_String;
}

IString::IString()
{

}

char IString::CharAtPos(int pos)
{
	return m_String.at(pos);
}

IString::IString(int number)
{
	m_String = to_string(number);
}

IString::IString(const char* str)
{
	m_String = str;
}

IString::IString(const IString &other)
{
	m_String = other.m_String;
}

void IString::AssignString(const char* str)
{
	m_String = str;
}

void IString::AssignString(IString str)
{
	m_String = str.m_String;
}

void IString::StringSplit(char c, IGenericObjectArray<IString> &res)
{

}

IString IString::StringTrimLeft()
{
	IString str;

	return str;
}

IString IString::StringTrimRight()
{
	IString str;

	return str;
}

IString IString::SubString(int beg, int am)
{
	IString res;

	res.m_String = m_String.substr(beg, am);

	return res;
}

int IString::StringLen()
{
	return (int)m_String.length();
}

bool IString::Contains(IString &search) 
{
	return false;
}

const char* IString::GetPlatformString() const
{
	return m_String.c_str();
}

IString IString::operator+(IString other)
{
	IString res;

	res.m_String = m_String + other.m_String;

	return res;
}

IString& IString::operator+(const char* other)
{
	m_String += other;

	return *this;
}

void IString::operator+=(IString other)
{
	m_String += other.m_String;
}

void IString::operator+=(const char* other)
{
	m_String += other;
}

void IString::StringReplace(const char* org, const char* rep)
{

}
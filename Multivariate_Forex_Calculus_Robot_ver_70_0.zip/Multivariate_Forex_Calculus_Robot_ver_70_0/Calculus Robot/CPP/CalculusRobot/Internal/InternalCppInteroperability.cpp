/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#include "InternalCppInteroperability.h"

void IInteroperability::Activate()
{

}

void IInteroperability::Print(const IString &str)
{
	cout << str.GetPlatformString();
}

void IInteroperability::RefreshRates()
{

}

unsigned long IInteroperability::GetLastError()
{
	return 0;
}

int IInteroperability::AccountLeverage()
{
	return 0;
}

const char* IInteroperability::AccountCurrency()
{
	return 0;
}

bool IInteroperability::OrderSelect(int nr, unsigned long ticket)
{
	return false;
}

unsigned long IInteroperability::HistoryOrderTicket(int nr)
{
	return 0;
}

IDateTime IInteroperability::OrderOpenTime(unsigned long ticket, IDateTime time)
{
	IDateTime res;

	return res;
}

double IInteroperability::OrderProfit(unsigned long ticket)
{
	return 0.0;
}

double IInteroperability::OrderOpenPrice(unsigned long ticket)
{
	return 0.0;
}

double IInteroperability::OrderCurrentPrice(unsigned long ticket)
{
	return 0.0;
}

double IInteroperability::OrderTakeProfit(unsigned long ticket)
{
	return 0.0;
}

double IInteroperability::OrderStopLoss(unsigned long ticket)
{
	return 0.0;
}

bool IInteroperability::CloseOrder(unsigned long ticket)
{
	return false;
}

const char* IInteroperability::OrderSymbol(unsigned long ticket, IString symbol)
{
	return 0;
}

double IInteroperability::AccountBalance()
{
	return 0.0;
}

double IInteroperability::GetPriceAtTime(IString symbol, IDateTime date)
{
	return m_ValuesProvider.ValueOfColumnInSpecificTime(string(symbol.GetPlatformString()), string(date.TimeCurrentAsString().GetPlatformString()));
}

double IInteroperability::GetPriceAtTimeHigh(IString symbol, IDateTime date)
{
	return m_ValuesProvider.ValueOfColumnInSpecificTime(string(symbol.GetPlatformString()), string(date.TimeCurrentAsString().GetPlatformString()));
}

double IInteroperability::Spread(IString symbol)
{
	return 0.0;
}

double IInteroperability::BuyPrice(IString symbol)
{
	return m_ValuesProvider.ValueOfColumnAtCurrentTime(string(symbol.GetPlatformString()));
}

double IInteroperability::SellPrice(IString symbol)
{
	return m_ValuesProvider.ValueOfColumnAtCurrentTime(string(symbol.GetPlatformString()));
}

long IInteroperability::OrderSend(IString symbol, bool buy, double lotSize, double price, int slippage, double stopLoss, double takeProfit)
{
	return 0;
}

int IInteroperability::OrdersHistoryTotal()
{
	return 0;
}

double IInteroperability::MathAbs(double val)
{
	return abs(val);
}

double IInteroperability::MathExp(double val)
{
	return exp(val);
}

void IInteroperability::EventSetTimer(int secs)
{

}

void IInteroperability::EventKillTimer()
{

}

bool IInteroperability::MathIsValidNumber(double val)
{
	if (val == NAN || val == INFINITY)
	{
		return false;
	}
	else
	{
		return true;
	}
}

int IInteroperability::MathCeil(double val)
{
	return (int)ceil(val);
}

void IInteroperability::MathSrand()
{

}

int IInteroperability::MathRand()
{
	return 0;
}

IString IInteroperability::DoubleToString(double val)
{
	string str = to_string(val);

	return IString(str.c_str());
}

IString IInteroperability::IntegerToString(int val)
{
	string str = to_string(val);

	return IString(str.c_str());
}

IString IInteroperability::BoolToString(bool val)
{
	if (val)
	{
		IString str("true");

		return str;
	}
	else
	{
		IString str("false");

		return str;
	}
}

int IInteroperability::SymbolsTotal(bool shown)
{
	return m_ValuesProvider.ColumnsTotal();
}

IString IInteroperability::SymbolName(int nr, bool shown)
{
	return IString(m_ValuesProvider.ColumnName(nr).c_str());
}

double IInteroperability::NormalizeDouble(double price, int digits)
{
	return price;
}

int IInteroperability::Digits()
{
	return 5;
}

double IInteroperability::StringToDouble(IString &str)
{
	return stod(str.GetPlatformString());
}

IDateTime IInteroperability::StringToTime(IString &str)
{
	return IDateTime::TimeCurrent();
}

CValuesProvider IInteroperability::m_ValuesProvider;

#include "ValuesProvider.h"

void CValuesProvider::Init(string filename)
{

}

void CValuesProvider::AssingCurrentTime(string time)
{

}

void CValuesProvider::AddSecondsToCurrentTime(int amount)
{
	m_Time += amount;
}

double CValuesProvider::ValueOfColumnAtCurrentTime(string column)
{
	return 0.0;
}

double CValuesProvider::ValueOfColumnInSpecificTime(string column, string time)
{
	return 0.0;
}

string CValuesProvider::ColumnName(int nr)
{
	string str;

	return str;
}

int CValuesProvider::ColumnsTotal()
{
	return 0;
}

void CRow::Init(int am)
{
	m_ColumnsValues.resize(am);
}

time_t CRow::GetDate()
{
	return m_RowDate;
}

void CRow::SetDate(time_t time)
{
	m_RowDate = time;
}

double CRow::GetColumnValue(int nr)
{
	return m_ColumnsValues[nr];
}

void CRow::SetColumnValue(int nr, double val)
{
	m_ColumnsValues[nr] = val;
}
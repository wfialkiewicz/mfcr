/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_DATE_TIME
#define FILE_DATE_TIME

#ifndef CPP

#include "..\..\..\Include\Tools\DateTime.mqh"
#include "..\CR Expert\CR Includes\Config.h"
#include "Interoperability.h"

//+------------------------------------------------------------------+
class IDateTime {
private:
	datetime m_time;

public:
   static bool AreEqual(IDateTime &a, IDateTime &b)
   {
       if(a.m_time == b.m_time)
       {
           return true;
       }
       else
       {
           return false;
       }
   }

	datetime GetPlatformTime()
	{
		return m_time;
	}

	IDateTime()
	{
       m_time = 0;
	}

	IDateTime(datetime time)
	{
		m_time = time;
	}

	bool operator<(const IDateTime &other)
	{
		return m_time < other.m_time;
	}

	bool operator>(const IDateTime &other)
	{
		return m_time > other.m_time;
	}

	IDateTime(const IDateTime &other)
	{
		m_time = other.m_time;
	}

	void Assign(const IDateTime *other)
	{
		m_time = other.m_time;
	}

	static IDateTime TimeCurrent()
	{
		IDateTime time;

		time.m_time = ::TimeCurrent();

		return time;
	}

	static IString TimeCurrentAsString()
	{
		IString str;
		string tm = ::TimeToString(::TimeCurrent());

		str.AssignString(tm);
		return str;
	}


	static IString GetDay(IDateTime &time)
	{
		CDateTime dateDT;

		TimeToStruct(time.m_time, dateDT);
		return IString(dateDT.DayName());
	}

	int GetHour()
	{
	#ifdef MQL4
		return ::TimeHour(m_time);
#endif
#ifdef MQL5
   MqlDateTime str;
   TimeToStruct(m_time,str);
   return str.hour;
#endif
}

	static IDateTime AddMinute(IDateTime &time)
	{
		CDateTime dateDT;

		TimeToStruct(time.m_time, dateDT);
		dateDT.MinInc(CConfig::MinutesSpan);

		IDateTime res;

		res.m_time = StructToTime(dateDT);

		return res;
	}

	static IDateTime AddMinutes(IDateTime &date, int minutes)
	{
		CDateTime dateDT;

		TimeToStruct(date.m_time, dateDT);
		if (minutes > 0)
		{
			dateDT.MinInc(minutes);
		}
		else
		{
			dateDT.MinDec(-minutes);
		}

		IDateTime res;

		res.m_time = StructToTime(dateDT);

		return res;
	}

	static IDateTime AddSeconds(IDateTime &date, int seconds)
	{
		CDateTime dateDT;

		TimeToStruct(date.m_time, dateDT);
		dateDT.SecInc(seconds);

		IDateTime res;

		res.m_time = StructToTime(dateDT);

		return res;
	}

	static int MinutesDiff(IDateTime &before, IDateTime &after)
	{
		return (int)(SecondsDiff(before, after) / 60);
	}

	static IDateTime MinusHours(IDateTime &date, int hoursAm)
	{
		CDateTime dateDT;

		TimeToStruct(date.m_time, dateDT);
		dateDT.HourDec(hoursAm);

		IDateTime res;

		res.m_time = StructToTime(dateDT);

		return res;
	}

	static double SecondsDiff(IDateTime &before, IDateTime &after)
	{
		datetime diff = (after.m_time - before.m_time);
		CDateTime dateDT;
		double ret = 0.0;

		TimeToStruct(diff, dateDT);
		ret = dateDT.sec;
		if (dateDT.min > 0)
		{
			ret += dateDT.min * 60;
		}
		if (dateDT.hour > 0)
		{
			ret += dateDT.hour * 60 * 60;
		}
		if (dateDT.day > 1)
		{
			ret += (dateDT.day - 1) * 24 * 60 * 60;
		}
		return (double)ret;
	}

	static IString FromSeconds(double seconds)
	{
		int sec = (int)(seconds);
		int min = (int)(seconds / 60.0);
		int hour = (int)(seconds / (60.0*60.0));

		sec -= min * 60;
		min -= hour * 60;

		return IString(IInteroperability::IntegerToString(hour)) + ":" + IInteroperability::IntegerToString(min) + ":" + IInteroperability::IntegerToString(sec);
	}

	static IDateTime FromString(IString &str)
	{
		return IInteroperability::StringToTime(str);
	}
};
//+------------------------------------------------------------------+
#else

#include "../CPP/CalculusRobot/Internal/InternalCppDateTime.h"

#endif
#endif
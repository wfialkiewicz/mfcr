/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_STRING
#define FILE_STRING

#ifndef CPP

#include "GenericObjectArray.h"

//+------------------------------------------------------------------+
class IString{
    private:
    	  string m_String;
    	  
    public:
        bool static AreEqual(IString &a, IString &b)
        {
            if(::StringCompare(a.m_String, b.m_String) == 0)
            {
                return true;
            }
            return false;
        }
        
        IString()
        {
        
        }
        
        IString(string str)
        {
            m_String = str;
        }
                
        void AssignString(string str)
        {
            m_String = str;
        }
        
        void AssignString(IString &str)
        {
            m_String = str.m_String;
        }
        
        IString(const IString &other)
	     {
	         m_String = other.m_String;
	     }
	     
	     void StringSplit(char c, IGenericObjectArray<IString> &res)
	     {
	         string result[];
	         
	         ::StringSplit(m_String, c, result);
	         res.Resize(ArraySize(result));
	         for(int i=0;i<res.Size();i++)
	         {
	             (*(res.GetPointerToValue(i))).AssignString(result[i]);
	         }
	     }
	     
	     IString StringTrimLeft()
	     {
	         IString str;
	         
	         str.AssignString(::StringTrimLeft(m_String));
	         return str;
	     }
	     
	     IString StringTrimRight()
	     {
	         IString str;
	         
	         str.AssignString(::StringTrimRight(m_String));
	         return str;
	     }
	     
	     IString SubString(int beg, int am)
	     {
	         IString res(::StringSubstr(m_String, beg, am));
	         
	         return res;
	     }
	     
	     int StringLen()
	     {
	         return ::StringLen(m_String);
	     }
	     
		 bool Contains(IString &search)
		 {
			 int nr = ::StringFind(m_String, search.GetPlatformString(), 0);

			 if (nr >= 0)
			 {
				 return true;
			 }
			 else
			 {
				 return false;
			 }
		 }

	     string GetPlatformString()
	     {
	         return m_String;
	     }

        void StringReplace(string org, string rep)
        {
            ::StringReplace(m_String, org, rep);
        }
	     
	     IString operator+(IString &other)
	     {
	         IString res;
	         
	         res.m_String = m_String + other.m_String;
	         
	         return res;
	     }
	     
	     IString operator+(string other)
	     {
	         IString res;
	         
	         res.m_String = m_String + other;
	         
	         return res;
	     }
	     
	     void operator+=(IString &other)
	     {   
	         m_String = m_String + other.m_String;
	     }
	     
	     void operator+=(string other)
	     {   
	         m_String = m_String + other;
	     }

		 char CharAtPos(int pos)
		 {
			 return (char)m_String[pos];
		 }
};
//+------------------------------------------------------------------+
#else

#include "../CPP/CalculusRobot/Internal/InternalCppString.h"

#endif
#endif

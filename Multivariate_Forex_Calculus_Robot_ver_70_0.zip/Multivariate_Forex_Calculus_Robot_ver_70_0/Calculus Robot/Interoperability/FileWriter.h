/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_FILE_WRITER
#define FILE_FILE_WRITER

#ifndef CPP

#include "String.h"

//+------------------------------------------------------------------+
class IFileWriter{
    private:
        int m_FileHandle;
        
    public:
        void Initialize(IString &name)
        {
            m_FileHandle = ::FileOpen(name.GetPlatformString(), FILE_TXT | FILE_ANSI | FILE_READ | FILE_WRITE | FILE_SHARE_READ | FILE_SHARE_WRITE);
            ::FileSeek(m_FileHandle, 0, SEEK_END);
        }

		void Delete(IString &name)
		{
			::FileDelete(name.GetPlatformString());
		}
        
        void Write(IString &line)
        {
            ::FileWrite(m_FileHandle, line.GetPlatformString());
            ::FileFlush(m_FileHandle);
        }
        
        ~IFileWriter()
        {
            FileClose(m_FileHandle);
        }
        
        IString ReadEndLine()
        {
            IString line;
            
            ::FileSeek(m_FileHandle, 0, SEEK_SET);
            while(!::FileIsEnding(m_FileHandle))
            {
                line.AssignString(::FileReadString(m_FileHandle));
            }
            return line;
        }
};
//+------------------------------------------------------------------+
#else

#include "../CPP/CalculusRobot/Internal/InternalCppFileWriter.h"

#endif
#endif
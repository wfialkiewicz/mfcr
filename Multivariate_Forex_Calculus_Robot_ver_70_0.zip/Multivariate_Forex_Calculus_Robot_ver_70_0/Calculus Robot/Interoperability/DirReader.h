/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_DIR_READER
#define FILE_DIR_READER

#ifndef CPP

#include "String.h"
#include "GenericObjectArray.h"
#include "DateTime.h"
#include "../CR Expert/CR Includes/Config.h"
#include "SortableArray.h"

//+------------------------------------------------------------------+
class IDirReader {
private:
	static string InpFilter;

public:
	static void ReturnSpecialLogsNames(IGenericObjectArray<IString> &ret)
	{
		string file_name;
		long search_handle = ::FileFindFirst(InpFilter, file_name);
		int am = 0;

		if (search_handle != INVALID_HANDLE)
		{
			am++;
			while (::FileFindNext(search_handle, file_name))
			{
				am++;
			}
		}

		IGenericObjectArray<IDateTime> dates;
		IGenericObjectArray<IString> names;

		dates.Resize(am);
		names.Resize(am);
		am = 0;
		search_handle = ::FileFindFirst(InpFilter, file_name);
		if (search_handle != INVALID_HANDLE)
		{
			(*(names.GetPointerToValue(am))).AssignString(file_name);
			(*(dates.GetPointerToValue(am))) = IDateTime(::FileGetInteger(file_name, FILE_CREATE_DATE));
			am++;
			while (::FileFindNext(search_handle, file_name))
			{
				(*(names.GetPointerToValue(am))).AssignString(file_name);
				(*(dates.GetPointerToValue(am))) = IDateTime(::FileGetInteger(file_name, FILE_CREATE_DATE));
				am++;
			}
		}

		int logs_am = CConfig::LogsAmountToAnalyze;
		
		if (names.Size() < logs_am)
		{
			logs_am = names.Size();
		}
		
		if(logs_am < 1)
		{
		    return;
		}
		
		ret.Resize(logs_am);
		
		ISortableArray<long> arr;

		arr.Resize(names.Size());
		for (int i = 0; i < names.Size(); i++)
		{
			arr.SetValue(i, (*(dates.GetPointerToValue(i))).GetPlatformTime());
			arr.SetPos(i, i);
		}
		arr.Sort();
		for (int i = 0; i < logs_am; i++)
		{
			(*(ret.GetPointerToValue(i))).AssignString((*(names.GetPointerToValue(arr.GetPos(names.Size() - i - 1)))));
		}
	}
};
string IDirReader::InpFilter = "special_*";
//+------------------------------------------------------------------+
#else

#include "../CPP/CalculusRobot/Internal/InternalCppDirReader.h"

#endif
#endif
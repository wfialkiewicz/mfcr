/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_GENERIC_OBJECT_ARRAY
#define FILE_GENERIC_OBJECT_ARRAY

#ifndef CPP
//+------------------------------------------------------------------+
template <typename T>
class IGenericObjectArray{
     private:
		   int GROW_BY;
         T m_Array[];
		   int m_Size;

     public:
         IGenericObjectArray()
         {
             GROW_BY = 5;
             m_Size = 0;
         }
         
         void Resize(int am)
         {
             ArrayResize(m_Array, am);             
			    m_Size = am;
         }         
         
         void GrowIfNeeded()
         {
             if (m_Size < ArraySize(m_Array))
	  	     {  
				  			 			 
			 }
			 else
			 {
			    ArrayResize(m_Array, m_Size + GROW_BY);
			 }			      
         }

		 void IncreaseSize()
		 {
			 m_Size++;
		 }
         
         void SetValue(int nr, const T &val)
         {
             m_Array[nr] = val;
         }
         
         T* GetPointerToValue(int nr)
         {
             return &(m_Array[nr]);
         }
         
         const int Size()
         {
             return m_Size;
         }

		 void Add(const T &val)
		 {
			 GrowIfNeeded();
			 m_Array[m_Size] = val;
			 m_Size++;
		 }
		 
		 int LastNr()
		 {
			 return m_Size - 1;
		 }

		 void Remove(int nr)
		 {
			 if (nr == m_Size - 1)
			 {
				 m_Size--;
			 }
			 else if (nr < m_Size - 1)
			 {
				 m_Array[nr] = m_Array[m_Size - 1];
				 m_Size--;
			 }
		 }
};
//+------------------------------------------------------------------+
#else

#include "../CPP/CalculusRobot/Internal/InternalCppGenericObjectArray.h"

#endif
#endif
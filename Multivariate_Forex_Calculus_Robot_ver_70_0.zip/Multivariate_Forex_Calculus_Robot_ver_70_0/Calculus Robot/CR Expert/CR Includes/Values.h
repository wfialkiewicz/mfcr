/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_VALUES
#define FILE_VALUES

#include "CurrencyPairs.h"
#include "Config.h"
#include "../../Interoperability/DateTime.h"
#include "Logger.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/GenericArray.h"
#include "../../Interoperability/GenericObjectArray.h"

//+------------------------------------------------------------------+
class CPastValues{
    public:
        IGenericArray<double> Values;
        IDateTime Date;
        
        void Init(int am)
        {
            Values.Resize(am);            
        }
        
        void Log()
        {
             IString values;
             
             for(int i=0;i<Values.Size();i++)
             {
                 values += (IInteroperability::DoubleToString(Values.GetValue(i)) + "; ");
             }
             CLogger::HeavyLog(IString(IDateTime::GetDay(Date)) + "; " + values);
        }
        
        static bool SameValues(CPastValues &a, CPastValues &b)
        {
            for(int i=0;i<a.Values.Size();i++)
            {
                if(a.Values.GetValue(i) != b.Values.GetValue(i))
                {
                    return false;
                }
            }
            return true;
        }
        
        static void CopyValues(CPastValues &src, CPastValues &dest)
        {
            dest.Date = src.Date;
			dest.Values.Resize(src.Values.Size());
            for(int i=0;i<src.Values.Size();i++)
            {
                dest.Values.SetValue(i, src.Values.GetValue(i));
            }
        }
};
//+------------------------------------------------------------------+
class CValues{
    private:
        IGenericObjectArray<CPastValues> PastValues;
        IGenericArray<bool> PresentBuy;
        IGenericArray<bool> PresentSell;
        IGenericArray<bool> PresentOtherBuy;
        IGenericArray<bool> PresentOtherSell;
        CCurrencyPairs *m_Pairs;
    
        static int AmountOfPastTimes()
        {
            return CConfig::PastHoursCount * 60;
        }
        
        static void CheckSymbolsToBuy(CCurrencyPairs &pairs, IGenericArray<bool> &present, IDateTime &past)
        {
            for(int i=0;i<pairs.AmountCurrencyPairsToBuy();i++)
            {
				IString pair(pairs.ReturnCurrencyPairToBuyNr(i));

                if(CValues::GetPriceAtTime(pair, past) == 0.0)
                {
                    present.SetValue(i, false);
                }
                else
                {
                    present.SetValue(i, true);
                }
            }
        }

        static void CheckSymbolsToSell(CCurrencyPairs &pairs, IGenericArray<bool> &present, IDateTime &past)
        {
            for(int i=0;i<pairs.AmountCurrencyPairsToSell();i++)
            {
				IString pair(pairs.ReturnCurrencyPairToSellNr(i));

                if(CValues::GetPriceAtTime(pair, past) == 0.0)
                {
                    present.SetValue(i, false);
                }
                else
                {
                    present.SetValue(i, true);
                }
            }
        }
        
        static void CheckOtherSymbolsToBuy(CCurrencyPairs &pairs, IGenericArray<bool> &present, IDateTime &past)
        {
            for(int i=0;i<pairs.AmountOtherSymbolsToBuy();i++)
            {
				IString pair(pairs.ReturnOtherSymbolToBuyNr(i));

                if(CValues::GetPriceAtTime(pair, past) == 0.0)
                {
                    present.SetValue(i, false);
                }
                else
                {
                    present.SetValue(i, true);
                }
            }
        }
        
        static void CheckOtherSymbolsToSell(CCurrencyPairs &pairs, IGenericArray<bool> &present, IDateTime &past)
        {
            for(int i=0;i<pairs.AmountOtherSymbolsToSell();i++)
            {
				IString pair(pairs.ReturnOtherSymbolToSellNr(i));

                if(CValues::GetPriceAtTime(pair, past) == 0.0)
                {
                    present.SetValue(i, false);
                }
                else
                {
                    present.SetValue(i, true);
                }
            }
        }
        
        static int CountTrues(IGenericArray<bool> &present)
        {
            int am = 0;
            
            for(int i=0;i<present.Size();i++)
            {
                if(present.GetValue(i))
                {
                    am++;
                }
            }
            return am;
        }
        
        static int CountFalses(IGenericArray<bool> &present, int pos)
        {
            int am = 0;
            
            for(int i=0;i<=pos;i++)
            {
                if(present.GetValue(i) == false)
                {
                    am++;
                }
            }
            return am;
        }        
        
    public:
        static double GetPriceAtTime(IString &symbol, IDateTime &date)
        { 
            return IInteroperability::GetPriceAtTime(symbol, date);
        }
        
        static double GetPriceAtTimeHigh(IString &symbol, IDateTime &date)
        { 
            return IInteroperability::GetPriceAtTimeHigh(symbol, date);
        }
        
        static double Spread(IString &symbol)
        {
            return IInteroperability::Spread(symbol);
        }
        
        static double BuyPrice(IString &symbol)
        {
            return IInteroperability::BuyPrice(symbol);
        }

		static double Price(IString &symbol, bool Buy)
		{
			if (Buy)
			{
				return IInteroperability::BuyPrice(symbol);
			}
			else
			{
				return IInteroperability::SellPrice(symbol);
			}
		}

        static double SellPrice(IString &symbol)
        {
            return IInteroperability::SellPrice(symbol);
        }
        
        bool InitWithNowTime(CCurrencyPairs &pairs)
        {
            IDateTime past, now;
            
            now = IDateTime::TimeCurrent();
            past = IDateTime::MinusHours(now, CConfig::PastHoursCount);
            PresentBuy.Resize(pairs.AmountCurrencyPairsToBuy());
            PresentSell.Resize(pairs.AmountCurrencyPairsToSell());
            PresentOtherBuy.Resize(pairs.AmountOtherSymbolsToBuy());
            PresentOtherSell.Resize(pairs.AmountOtherSymbolsToSell());
            CheckSymbolsToBuy(pairs, PresentBuy, past);
            CheckSymbolsToSell(pairs, PresentSell, past);
            CheckOtherSymbolsToBuy(pairs, PresentOtherBuy, past);
            CheckOtherSymbolsToSell(pairs, PresentOtherSell, past);
            PastValues.Resize(AmountOfPastTimes());
            
            int amBuy = CountTrues(PresentBuy);
            int amSell = CountTrues(PresentSell);
            int amOtherBuy = CountTrues(PresentOtherBuy);
            int amOtherSell = CountTrues(PresentOtherSell);
            
            if(amBuy == 0 && amSell == 0 && amOtherBuy == 0 && amOtherSell == 0)
            {
                return false;
            }
            
            for(int i=0;i<PastValues.Size();i++)
            {
                (*(PastValues.GetPointerToValue(i))).Init(amBuy + amSell + amOtherBuy + amOtherSell);
            }
            
            pairs.LimitCurrencyPairs(PresentBuy, PresentSell, PresentOtherBuy, PresentOtherSell);
            
            int nr = 0;
            CPastValues values;
            
            values.Init(amBuy + amSell + amOtherBuy + amOtherSell);            
            do
            {
                values.Date = past;
                for(int i=0;i<pairs.AmountCurrencyPairsToBuy();i++)
                {
					IString pair(pairs.ReturnCurrencyPairToBuyNr(i));

                    values.Values.SetValue(i, CValues::GetPriceAtTime(pair, past));   
                }
                for(int i=0;i<pairs.AmountCurrencyPairsToSell();i++)
                {
					IString pair(pairs.ReturnCurrencyPairToSellNr(i));

                    values.Values.SetValue(pairs.AmountCurrencyPairsToBuy() + i, CValues::GetPriceAtTime(pair, past));   
                }
                for(int i=0;i<pairs.AmountOtherSymbolsToBuy();i++)
                {
					IString pair(pairs.ReturnOtherSymbolToBuyNr(i));

                    values.Values.SetValue(pairs.AmountCurrencyPairsToBuy() + pairs.AmountCurrencyPairsToSell() + i, CValues::GetPriceAtTime(pair, past));
                }
                for(int i=0;i<pairs.AmountOtherSymbolsToSell();i++)
                {
					IString pair(pairs.ReturnOtherSymbolToSellNr(i));

                    values.Values.SetValue(pairs.AmountCurrencyPairsToBuy() + pairs.AmountCurrencyPairsToSell() + pairs.AmountOtherSymbolsToBuy() + i, CValues::GetPriceAtTime(pair, past)); 
                }
                if(nr == 0 || !CPastValues::SameValues(values, (*(PastValues.GetPointerToValue(nr-1)))))
                {
                    CPastValues::CopyValues(values, (*(PastValues.GetPointerToValue(nr))));
                    nr++;
                }
                past = IDateTime::AddMinute(past);
            }while(past<now);
            m_Pairs = &pairs;
            PastValues.Resize(nr);
            CLogger::Log(IString("Got ") + IInteroperability::DoubleToString(PastValues.Size() / (24.0 * 60.0)) + " days of history.");
            return true;
        }
        
        int PastValuesAmount()
        {
            return PastValues.Size();
        }
        
        double ReturnPastValueNrToBuy(int pastNr, int symbolNr)
        {
            return (*(PastValues.GetPointerToValue(pastNr))).Values.GetValue(symbolNr);
        }

        double ReturnPastValueNrToSell(int pastNr, int symbolNr)
        {
            return (*(PastValues.GetPointerToValue(pastNr))).Values.GetValue((*m_Pairs).AmountCurrencyPairsToBuy() + symbolNr);
        }
        
        double ReturnOtherPastValueNrToBuy(int pastNr, int symbolNr)
        {
            return (*(PastValues.GetPointerToValue(pastNr))).Values.GetValue((*m_Pairs).AmountCurrencyPairsToBuy() + (*m_Pairs).AmountCurrencyPairsToSell() + symbolNr);
        }
        
        double ReturnOtherPastValueNrToSell(int pastNr, int symbolNr)
        {
            return (*(PastValues.GetPointerToValue(pastNr))).Values.GetValue((*m_Pairs).AmountCurrencyPairsToBuy() + (*m_Pairs).AmountCurrencyPairsToSell() + (*m_Pairs).AmountOtherSymbolsToBuy() + symbolNr);
        }
        
        IDateTime ReturnDateTimeOfPastNr(int pastNr)
        {
            return (*(PastValues.GetPointerToValue(pastNr))).Date;
        }        
        
        void Log()
        {
            for(int i=0;i<PastValues.Size();i++)
            {
                (*(PastValues.GetPointerToValue(i))).Log();
            }
        }
        
        int PastValuesStartNr()
        {
            int nr = PastValuesAmount() - CConfig::PastHoursCountForAnalysis * 60;
            
            if(nr>0)
            {
                return nr;
            }
            else
            {
                return 0;
            }
        }	

		void AssignPastValues(IGenericObjectArray<CPastValues> &values, CCurrencyPairs &pairs)
		{
			m_Pairs = &pairs;
			PastValues.Resize(values.Size());
			for (int i = 0; i < PastValues.Size(); i++)
			{
				CPastValues::CopyValues((*(values.GetPointerToValue(i))), (*(PastValues.GetPointerToValue(i))));
			}
		}
};
//+------------------------------------------------------------------+
#endif
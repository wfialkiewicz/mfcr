/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_ORDERS
#define FILE_ORDERS

#include "../../Interoperability/DateTime.h"
#include "CurrencyPairs.h"
#include "../../Interoperability/String.h"

//+------------------------------------------------------------------+
class COrders{
    private:
		static CCurrencyPairs *m_Pairs;
		static double m_Profit;
		static int m_OrdersAmount;

		static double BuyPriceInDefaultCurrency(IString &pair)
		{
			return 0.0;
		}

		static double SellPriceInDefaultCurrency(IString &pair)
		{
			return 0.0;
		}

		double m_OrderPrice;
		bool m_OrderBuy;
		IString m_Symbol;

		static double PriceInDefaultCurrency(IString &symbol, bool buy)
		{
			if (buy)
			{
				return BuyPriceInDefaultCurrency(symbol);
			}
			else
			{
				return SellPriceInDefaultCurrency(symbol);
			}
		}

    public:
		static void Init(CCurrencyPairs &pairs)
		{
			m_Pairs = &pairs;
		}

		void SendOrder(IString &symbol, bool buy)
		{
			m_OrderBuy = buy;
			m_OrderPrice = PriceInDefaultCurrency(symbol, m_OrderBuy);
			m_Symbol = symbol;
		}

		void AddToProfit()
		{
			double price;
			
			m_OrdersAmount++;
			price = PriceInDefaultCurrency(m_Symbol, m_OrderBuy);
			if (m_OrderBuy)
			{
				m_Profit += (price - m_OrderPrice);
			}
			else
			{
				m_Profit += (m_OrderPrice - price);
			}
		}

		static void ZeroProfit()
		{
			m_Profit = 0.0;
			m_OrdersAmount = 0;
		}

		static double Profit(int &total)
		{
			total = m_OrdersAmount;
			return m_Profit;
		}
};
CCurrencyPairs* COrders::m_Pairs;
double COrders::m_Profit = 0.0;
int COrders::m_OrdersAmount = 0;
//+------------------------------------------------------------------+
#endif
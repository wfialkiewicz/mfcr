/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_LOGS
#define FILE_LOGS

#include "../../Interoperability/FileReader.h"
#include "../../Interoperability/DirReader.h"
#include "../../Interoperability/String.h"
#include "../../Interoperability/GenericObjectArray.h"
#include "../../Interoperability/GenericArray.h"
#include "../../Interoperability/SortableArray.h"
#include "Trade.h"
#include "Fcnnhn/Vectors.h"

//+------------------------------------------------------------------+
class CLogs{
    private:
		IGenericObjectArray<IGenericObjectArray<IString>> m_files_content;
		IGenericObjectArray<IGenericObjectArray<CTrade>> m_Trades;
		IGenericObjectArray<IGenericObjectArray<CTrade>> m_FinishedTrades;
		IGenericObjectArray<IGenericObjectArray<IGenericObjectArray<CTrade>>> m_SuccessiveTrades;
		IGenericObjectArray<IGenericArray<bool>> m_Successes;
		IGenericObjectArray<IGenericArray<bool>> m_TradableAfter;
		int m_TradesAmount;
		CVectors m_Vectors;

		bool static Seek(IFileReader &reader)
		{
			double size;

			size = reader.FileSize();
			if (size > CConfig::TrendAnalysisMaxLogFileSize)
			{
				double percent = 1.0 - size / CConfig::TrendAnalysisMaxLogFileSize;

				reader.Seek(percent);
				reader.ReadLine();
				return true;
			}
			else
			{
			   reader.Seek(0.0);
				return false;
			}
		}

		bool static ReadFileLines(IString &name, IGenericObjectArray<IString> &file)
		{
			IFileReader reader;
			int am = 0;
			bool ret;

			reader.Initialize(name);
			ret = Seek(reader);
			while (!reader.IsEnd())
			{
				reader.ReadLine();
				am++;
			};
			file.Resize(am);
			Seek(reader);

			IString line;
			am = 0;

			while (!reader.IsEnd())
			{
				line = reader.ReadLine();
				(*(file.GetPointerToValue(am))).AssignString(line);
				am++;
			}
			return ret;
		}

		int static FindTrade(IGenericObjectArray<CTrade> &trades, IString &id)
		{
			for (int i = 0; i < trades.Size(); i++)
			{
				if (IString::AreEqual((*(trades.GetPointerToValue(i))).Id, id))
				{
					return i;
				}
			}
			return -1;
		}

		bool static SearchLine(IString &line, IString &search, IString &id, IDateTime &date)
		{
			if (line.Contains(search))
			{
				IGenericObjectArray<IString> arr;
				IGenericObjectArray<IString> arrB;

				line.StringSplit(',', arr);
				date = IDateTime::FromString((*(arr.GetPointerToValue(0))));
				(*(arr.GetPointerToValue(arr.Size() - 1))).StringSplit(' ', arrB);
				id = (*(arrB.GetPointerToValue(arrB.Size() - 1)));
				return true;
			}
			else
			{
				return false;
			}
		}

		int static ExtractTradableAmount(IString &str)
		{
			IGenericObjectArray<IString> arr;
			IGenericObjectArray<IString> arrB;
			IGenericObjectArray<IString> arrC;
			IString number;

			str.StringSplit(',', arr);
			(*(arr.GetPointerToValue(arr.Size() - 1))).StringSplit(':', arrB);
			(*(arrB.GetPointerToValue(arrB.Size() - 1))).StringSplit('|', arrC);
			number = (*(arrC.GetPointerToValue(0)));

			return (int)(IInteroperability::StringToDouble(number));
		}

		int static FindClosestClose(IGenericObjectArray<CTrade> &trades, IDateTime &close)
		{
			int closest = 0;
			int diff = (int)((*(trades.GetPointerToValue(0))).CloseTime.GetPlatformTime() - close.GetPlatformTime());

			for (int i = 0; i < trades.Size(); i++)
			{
				if ((diff <= 0.0) || (((*(trades.GetPointerToValue(i))).CloseTime.GetPlatformTime() - close.GetPlatformTime() < diff) && ((*(trades.GetPointerToValue(i))).CloseTime.GetPlatformTime() - close.GetPlatformTime() > 0.0)))
				{
					closest = i;
					diff = (int)((*(trades.GetPointerToValue(closest))).CloseTime.GetPlatformTime() - close.GetPlatformTime());
				}
			}
			return closest;
		}

		void ExtractTradesInt(int tradableAmount)
		{
			IString str;
			CTrade trade;
			IDateTime date;
			IString id;
			int nr;
			IString start("Profit Search Start Nr");
			IString found("Profit found,");
			IString lost("Profit lost,");
			IString tradable("Tradable|Learnable");
			bool guard = true;

			for (int i = m_files_content.Size() - 1; i >= 0; i--)
			{
				for (int j = 0; j < (*(m_files_content.GetPointerToValue(i))).Size(); j++)
				{
					str = (*((*(m_files_content.GetPointerToValue(i))).GetPointerToValue(j)));

					if (str.Contains(tradable))
					{
						int tradableAm = ExtractTradableAmount(str);

						if (IInteroperability::MathAbs(tradableAmount - tradableAm) <= CConfig::TradableAmountMaxDiff)
						{
							guard = true;
						}
						else
						{
							guard = false;
						}
					}
					else if (guard && SearchLine(str, start, id, date))
					{
						trade.OpenTime = date;
						trade.Id = id;
						(*(m_Trades.GetPointerToValue(i))).Add(trade);
					}
					else if (SearchLine(str, found, id, date))
					{
						nr = FindTrade((*(m_Trades.GetPointerToValue(i))), id);
						if (nr >= 0)
						{
							(*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(nr))).CloseTime = date;
							(*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(nr))).Successfull = true;
					    }
					}
					else if (SearchLine(str, lost, id, date))
					{
						nr = FindTrade((*(m_Trades.GetPointerToValue(i))), id);
						if (nr >= 0)
						{
							(*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(nr))).CloseTime = date;
							(*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(nr))).Successfull = false;
						}
					}
				}
			}
		}		

		void ExtractTradesIntRT(int tradableAmount)
		{
			IString str;
			CTrade trade;
			IDateTime date;
			IString id;
			int nr;
			IString start("Profit Search Start Nr");
			IString found("Profit_found_RT,");
			IString lost("Profit_lost_RT,");
			IString tradable("Tradable|Learnable");
			bool guard = true;

			for (int i = m_files_content.Size() - 1; i >= 0; i--)
			{
				for (int j = 0; j < (*(m_files_content.GetPointerToValue(i))).Size(); j++)
				{
					str = (*((*(m_files_content.GetPointerToValue(i))).GetPointerToValue(j)));

					if (str.Contains(tradable))
					{
						int tradableAm = ExtractTradableAmount(str);

						if (IInteroperability::MathAbs(tradableAmount - tradableAm) <= CConfig::TradableAmountMaxDiff)
						{
							guard = true;
						}
						else
						{
							guard = false;
						}
					}
					else if (guard && SearchLine(str, start, id, date))
					{
						trade.OpenTime = date;
						trade.Id = id;
						(*(m_Trades.GetPointerToValue(i))).Add(trade);
					}
					else if (SearchLine(str, found, id, date))
					{
						nr = FindTrade((*(m_Trades.GetPointerToValue(i))), id);
						if (nr >= 0)
						{
							(*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(nr))).CloseTime = date;
							(*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(nr))).Successfull = true;
						}
					}
					else if (SearchLine(str, lost, id, date))
					{
						nr = FindTrade((*(m_Trades.GetPointerToValue(i))), id);
						if (nr >= 0)
						{
							(*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(nr))).CloseTime = date;
							(*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(nr))).Successfull = false;
						}
					}
				}
			}
		}

    public:
		void ReadLogs()
		{
			IGenericObjectArray<IString> names;
			int pos = 0;

			IDirReader::ReturnSpecialLogsNames(names);
			m_files_content.Resize(names.Size());
			for (int i = 0; i < names.Size(); i++)
			{
				if (!ReadFileLines((*(names.GetPointerToValue(i))), (*(m_files_content.GetPointerToValue(i)))))
				{
				
				}
				else
				{
					names.Resize(i + 1);
					m_files_content.Resize(i + 1);
				}
			}
		}

		void ExtractTrades(int tradableAmount, bool rt = false)
		{
         IDateTime firstPast;

         m_Trades.Resize(m_files_content.Size());
		 if (rt)
		 {
			 ExtractTradesIntRT(tradableAmount);
		 }
		 else
		 {
			 ExtractTradesInt(tradableAmount);
		 }
			for (int i = 0; i < m_Trades.Size(); i++)
			{
				for (int j = 0; j < (*(m_Trades.GetPointerToValue(i))).Size(); j++)
				{
					if (IDateTime::AreEqual((*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(j))).CloseTime, firstPast))
					{
						(*(m_Trades.GetPointerToValue(i))).Remove(j);
						j--;
					}
				}
			}
		}

		void FillTrades(IGenericObjectArray<CTrade> &trades)
		{
			int am = 0;

			for (int i = 0; i < m_Trades.Size(); i++)
			{
				am += (*(m_Trades.GetPointerToValue(i))).Size();
			}
			trades.Resize(am);
			am = 0;
			for (int i = 0; i < m_Trades.Size(); i++)
			{
				for (int j = 0; j < (*(m_Trades.GetPointerToValue(i))).Size(); j++)
				{
					(*(trades.GetPointerToValue(am))) = (*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(j)));
					am++;
				}
			}
		}

		void AssignOrder()
		{
			IGenericObjectArray<ISortableArray<int>> sort;
			int am;
			int closestPos;
			int amFound;

			sort.Resize(m_Trades.Size());
			m_FinishedTrades.Resize(m_Trades.Size());
			m_SuccessiveTrades.Resize(m_Trades.Size());
			m_Successes.Resize(m_Trades.Size());
			m_TradableAfter.Resize(m_Trades.Size());
			for (int i = 0; i < m_Trades.Size(); i++)
			{
			   (*(sort.GetPointerToValue(i))).Resize((*(m_Trades.GetPointerToValue(i))).Size());
				for (int j = 0; j < (*(m_Trades.GetPointerToValue(i))).Size(); j++)
				{
					(*(sort.GetPointerToValue(i))).SetPos(j, j);
					(*(sort.GetPointerToValue(i))).SetValue(j, (int)((*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue(j))).OpenTime.GetPlatformTime()));
				}
				(*(sort.GetPointerToValue(i))).Sort();
				(*(m_FinishedTrades.GetPointerToValue(i))).Resize((*(m_Trades.GetPointerToValue(i))).Size());
				(*(m_SuccessiveTrades.GetPointerToValue(i))).Resize((*(m_Trades.GetPointerToValue(i))).Size());
			}
			for (int i = 0; i < m_Trades.Size(); i++)
			{
				for (int k = 0; k < (*(m_Trades.GetPointerToValue(i))).Size(); k++)
				{
					(*((*(m_FinishedTrades.GetPointerToValue(i))).GetPointerToValue(k))) = (*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(k))));
					am = 0;
					closestPos = FindClosestClose((*(m_Trades.GetPointerToValue(i))), (*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(k)))).CloseTime);
					for (int j = 0; j < (*(m_Trades).GetPointerToValue(i)).Size(); j++)
					{
						if (((*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(k)))).CloseTime < (*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(j)))).OpenTime) 
							&& ((*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(j)))).OpenTime < (*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(closestPos)))).CloseTime))
						{
							am++;
						}
					}
					(*((*(m_SuccessiveTrades.GetPointerToValue(i))).GetPointerToValue(k))).Resize(am);
					amFound = 0;
					for (int j = 0; j < (*(m_Trades.GetPointerToValue(i))).Size(); j++)
					{
						if (((*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(k)))).CloseTime < (*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(j)))).OpenTime)
							&& ((*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(j)))).OpenTime < (*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(closestPos)))).CloseTime))
						{
							(*((*((*(m_SuccessiveTrades.GetPointerToValue(i))).GetPointerToValue(k))).GetPointerToValue(amFound))) = (*((*(m_Trades.GetPointerToValue(i))).GetPointerToValue((*(sort.GetPointerToValue(i))).GetPos(j))));
							amFound++;
						}
					}
				}
				(*(m_Successes.GetPointerToValue(i))).Resize((*(m_Trades.GetPointerToValue(i))).Size());
				(*(m_TradableAfter.GetPointerToValue(i))).Resize((*(m_Trades.GetPointerToValue(i))).Size());
			}
			for (int i = 0; i < m_Trades.Size(); i++)
			{
				for (int k = 0; k < (*(m_Trades.GetPointerToValue(i))).Size(); k++)
				{
					am = 0;
					for (int j = 0; j < (*((*(m_SuccessiveTrades.GetPointerToValue(i))).GetPointerToValue(k))).Size(); j++)
					{
						if ((*((*((*(m_SuccessiveTrades.GetPointerToValue(i))).GetPointerToValue(k))).GetPointerToValue(j))).Successfull)
						{
							am++;
						}
					}
					if (am == 0)
					{
						(*(m_TradableAfter.GetPointerToValue(i))).SetValue(k, false);
					}
					else if (am / (double)((*((*(m_SuccessiveTrades.GetPointerToValue(i))).GetPointerToValue(k))).Size()) >= 0.5)
					{
						(*(m_Successes.GetPointerToValue(i))).SetValue(k, true);
						(*(m_TradableAfter.GetPointerToValue(i))).SetValue(k, true);
					}
					else
					{
						(*(m_Successes.GetPointerToValue(i))).SetValue(k, false);
						(*(m_TradableAfter.GetPointerToValue(i))).SetValue(k, true);
					}
				}
			}
			m_TradesAmount = 0;
			for (int i = 0; i < m_Trades.Size(); i++)
			{
				int amm = 0;

				for (int k = 0; k < (*(m_Trades.GetPointerToValue(i))).Size(); k++)
				{
					if ((*(m_TradableAfter.GetPointerToValue(i))).GetValue(k))
					{
  					    amm++;
					}
				}
     			m_TradesAmount += amm;
			}
  	    }

		int TradesAmount()
		{
			return m_TradesAmount;
		}

		CVectors* ReturnVectors()
		{
			return &m_Vectors;
		}

		void AssignVectors(int size)
		{
			CVector vec;
			int VecAmount = 0;

			for (int i = 0; i < m_Trades.Size(); i++)
			{
				int am = 0;

				for (int k = 0; k < (*(m_Trades.GetPointerToValue(i))).Size(); k++)
				{
					if ((*(m_TradableAfter.GetPointerToValue(i))).GetValue(k))
					{
						if (k >= size)
						{
							am++;
						}
					}
				}
				VecAmount += am;
			}

         int am = VecAmount - 1;
         
			vec.Init(size, 1);
			m_Vectors.Init(VecAmount, size, 1);
			for (int i = m_Trades.Size() - 1; i >= 0; i--)
			{
				for (int k = (*(m_Trades.GetPointerToValue(i))).Size() - 1; k >= 0; k--)
				{
					if ((*(m_TradableAfter.GetPointerToValue(i))).GetValue(k))
					{
						if (k >= size)
						{
							for (int j = 0; j < size; j++)
							{
								if ((*((*(m_FinishedTrades.GetPointerToValue(i))).GetPointerToValue(k - size + j))).Successfull)
								{
									vec.Input.SetValue(j, CVector::BTRUE);
								}
								else
								{
									vec.Input.SetValue(j, CVector::BFALSE);
								}
							}
							if ((*(m_Successes.GetPointerToValue(i))).GetValue(k))
							{
								vec.Output.SetValue(0, CVector::BTRUE);
							}
							else
							{
								vec.Output.SetValue(0, CVector::BFALSE);
							}
							CVector::CopyVector(vec, (*(m_Vectors.Vectors.GetPointerToValue(am))));
							am--;
						}
					}
				}
			}
		}

		void LimitVectorsAmount()
		{
			if (m_Vectors.Vectors.Size() > CConfig::PastTradesVectorsMaxAmount)
			{
				for (int i = 0; i < CConfig::PastTradesVectorsMaxAmount; i++)
				{
					CVector::CopyVector((*(m_Vectors.Vectors.GetPointerToValue(m_Vectors.Vectors.Size() - CConfig::PastTradesVectorsMaxAmount + i))), (*(m_Vectors.Vectors.GetPointerToValue(i))));
				}
				m_Vectors.Vectors.Resize(CConfig::PastTradesVectorsMaxAmount);
			}
		}
};
//+------------------------------------------------------------------+
#endif
/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_MATH
#define FILE_MATH

#include "../../Interoperability/GenericArray.h"

//+------------------------------------------------------------------+
class CMath{
    private:
        static bool ContainsIn(int nr, IGenericArray<int> &arr)
        {
            for(int i=0;i<arr.Size();i++)
            {
                if(arr.GetValue(i) == nr)
                {
                    return true;
                }
            }
            return false;
        }
        
        static int FindBiggestExcept(IGenericArray<double> &values, IGenericArray<int> &except)
        {
            int biggestNr = 0;
            
            while(ContainsIn(biggestNr, except))
            {
                biggestNr++;
            }
            
            for(int i=biggestNr + 1;i<values.Size();i++)
            {
                if(!ContainsIn(i, except))
                {
                    if(values.GetValue(i) > values.GetValue(biggestNr))
                    {
                        biggestNr = i;
                    }
                }
            }
            return biggestNr;
        }
    
    public:
        static void DetermineOrder(IGenericArray<double> &values, IGenericArray<int> &order)
        {
            int biggestNr;
        
            order.Resize(0);
            for(int i=0;i<values.Size();i++)
            {
                biggestNr = FindBiggestExcept(values, order);
                order.Resize(order.Size() + 1);
                order.SetValue(order.Size() - 1, biggestNr);
            }
        }		
};
//+------------------------------------------------------------------+
#endif
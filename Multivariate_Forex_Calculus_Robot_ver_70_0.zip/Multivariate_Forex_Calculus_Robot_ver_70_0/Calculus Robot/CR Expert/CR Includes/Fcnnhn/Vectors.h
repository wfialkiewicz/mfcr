/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_VECTORS
#define FILE_VECTORS

#include "Vector.h"
#include "../../../Interoperability/GenericObjectArray.h"
#include "../../../Interoperability/GenericArray.h"

//+------------------------------------------------------------------+
class CVectors{
    private:
        double m_Max;
        
        double FindMin()
        {
            double min = (*(Vectors.GetPointerToValue(0))).MinValue();
            
            for(int i=1;i<Vectors.Size();i++)
            {
                double tmp = (*(Vectors.GetPointerToValue(i))).MinValue();
                
                if(min > tmp)
                {
                    min = tmp;
                }
            }
            double tmp = LastVector.MinValue();
            
            if(min > tmp)
            {
                min = tmp;
            }            
            return min;
        }

        double FindMax()
        {
            double max = (*(Vectors.GetPointerToValue(0))).MaxValue();
            
            for(int i=1;i<Vectors.Size();i++)
            {
                double tmp = (*(Vectors.GetPointerToValue(i))).MaxValue();
                
                if(max < tmp)
                {
                    max = tmp;
                }
            }
            double tmp = LastVector.MaxValue();
            
            if(max < tmp)
            {
                max = tmp;            
            }
            
            return max;
        }

    public:
        IGenericObjectArray<CVector> Vectors;
        CVector LastVector;        
        
        void OneVectors()
        {
            for(int i=0;i<Vectors.Size();i++)
            {
                (*(Vectors.GetPointerToValue(i))).OneVector();
            }
            LastVector.OneVector();
        }
        
        void Init(int am, int in, int out)
        {
            Vectors.Resize(am);
            for(int i=0;i<am;i++)
            {
                (*(Vectors.GetPointerToValue(i))).Init(in, out);
            }
            LastVector.Init(in, out);
        }
        
        void SetRandomValues(double min, double max)
        {
            for(int i=0;i<Vectors.Size();i++)
            {
                (*(Vectors.GetPointerToValue(i))).SetRandomValues(min, max);
            }
            LastVector.SetRandomValues(min, max);
        }
        
        void Normalize()
        {
            double min = FindMin();
            double max = FindMax();
            
            if(max >= min)
            {
                m_Max = IInteroperability::MathAbs(max);
            }
            else
            {
                m_Max = IInteroperability::MathAbs(min);
            }
            
            for(int i=0;i<Vectors.Size();i++)
            {
                (*(Vectors.GetPointerToValue(i))).Normalize(m_Max);                
            }
            LastVector.Normalize(m_Max);
        }
        
        void DeNormalize()
        {
            for(int i=0;i<Vectors.Size();i++)
            {
                (*(Vectors.GetPointerToValue(i))).DeNormalize(m_Max);
            }
            LastVector.DeNormalize(m_Max);
        }
        
        void DeNormalize(CVector &vec)
        {
            vec.DeNormalize(m_Max);
        }
        
        void DeNormalize(IGenericArray<double> &values)
        {
            for(int i=0;i<values.Size();i++)
            {
                values.SetValue(i, CMathNet::DeNormalize(values.GetValue(i), m_Max));
            }
        } 
        
        void RemoveEmptyVectors()
        {
            IGenericObjectArray<CVector> vectors;
            int nr = 0;
            
            vectors.Resize(Vectors.Size());
            for(int i=0;i<Vectors.Size();i++)
            {
                if(!(*(Vectors.GetPointerToValue(i))).EmptyVector())
                {
                    CVector::CopyVector((*(Vectors.GetPointerToValue(i))), (*(vectors.GetPointerToValue(nr))));
                    nr++;
                }
            }
            Vectors.Resize(nr);
            for(int i=0;i<nr;i++)
            {
                CVector::CopyVector((*(vectors.GetPointerToValue(i))), (*(Vectors.GetPointerToValue(i))));
            }
        }  
        
        void Log()
        {
            for(int i=0;i<Vectors.Size();i++)
            {
                (*(Vectors.GetPointerToValue(i))).Log();
            }        
            LastVector.Log();
        }     
};
//+------------------------------------------------------------------+
#endif
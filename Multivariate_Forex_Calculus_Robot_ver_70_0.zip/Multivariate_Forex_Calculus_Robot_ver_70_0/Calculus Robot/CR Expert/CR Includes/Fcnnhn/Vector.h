/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_VECTOR
#define FILE_VECTOR

#include "MathNet.h"
#include "../Logger.h"
#include "../../../Interoperability/GenericArray.h"
#include "../../../Interoperability/String.h"
#include "../../../Interoperability/Interoperability.h"

//+------------------------------------------------------------------+
class CVector{
    public:
		static double BFALSE;
		static double BTRUE;

        IGenericArray<double> Input;
        IGenericArray<double> Output;
        
        void Init(CVector &vec)
        {
            Init(vec.Input.Size(), vec.Output.Size());
            for(int i=0;i<Input.Size();i++)
            {
                Input.SetValue(i, vec.Input.GetValue(i));
            }
            for(int i=0;i<Output.Size();i++)
            {
                Output.SetValue(i, vec.Output.GetValue(i));
            }
        }
        
        void Init(int in, int out)
        {
            Input.Resize(in);
            Output.Resize(out);
        }
        
        void SetRandomValues(double min, double max)
        {
            for(int i=0;i<Input.Size();i++)
            {
                Input.SetValue(i, CMathNet::Random(min, max));
            }
            for(int i=0;i<Output.Size();i++)
            {
                Output.SetValue(i, CMathNet::Random(min, max));
            }
        }
        
        double MinValue()
        {
            double min = Input.GetValue(0);
        
            for(int i=1;i<Input.Size();i++)
            {
                if(min > Input.GetValue(i))
                {
                    min = Input.GetValue(i);
                }
            }
            for(int i=0;i<Output.Size();i++)
            {
                if(min > Output.GetValue(i))
                {
                    min = Output.GetValue(i);
                }
            }
            return min;
        }
        
        double MaxValue()
        {
            double max = Input.GetValue(0);
        
            for(int i=1;i<Input.Size();i++)
            {
                if(max < Input.GetValue(i))
                {
                    max = Input.GetValue(i);
                }
            }
            for(int i=0;i<Output.Size();i++)
            {
                if(max < Output.GetValue(i))
                {
                    max = Output.GetValue(i);
                }
            }
            return max;
        }
        
        void Normalize(double max)
        {
            for(int i=0;i<Input.Size();i++)
            {
                Input.SetValue(i, CMathNet::Normalize(Input.GetValue(i), max));
            }
            for(int i=0;i<Output.Size();i++)
            {
                Output.SetValue(i, CMathNet::Normalize(Output.GetValue(i), max));
            }            
        }
        
        void OneVector()
        {
            for(int i=0;i<Input.Size();i++)
            {
                if(Input.GetValue(i) >=0.0)
                {
                    Input.SetValue(i, 1.0);
                }
                else
                {
                    Input.SetValue(i, -1.0);
                }
            }
            for(int i=0;i<Output.Size();i++)
            {
                if(Output.GetValue(i) >=0.0)
                {
                    Output.SetValue(i, 1.0);
                }
                else
                {
                    Output.SetValue(i, -1.0);
                }
            }            
        }
        
        void DeNormalize(double max)
        {
            for(int i=0;i<Input.Size();i++)
            {
                Input.SetValue(i, CMathNet::DeNormalize(Input.GetValue(i), max));
            }
            for(int i=0;i<Output.Size();i++)
            {
                Output.SetValue(i, CMathNet::DeNormalize(Output.GetValue(i), max));
            }            
        }
        
        static void CopyVector(CVector &src, CVector &dest)
        {
            dest.Init(src.Input.Size(), src.Output.Size());
            
            for(int i=0;i<src.Input.Size();i++)
            {
                dest.Input.SetValue(i, src.Input.GetValue(i));
            }
            for(int i=0;i<src.Output.Size();i++)
            {
                dest.Output.SetValue(i, src.Output.GetValue(i));
            }
        }
        
        bool EmptyVector()
        {
            for(int i=0;i<Output.Size();i++)
            {
                if(Output.GetValue(i) != 0.0)
                {
                    return false;
                }
            }
            return true;           
        }
        
        void Log()
        {
            IString msg(" Input : ");
            
            for(int i=0;i<Input.Size();i++)
            {
                msg += (IString(" ;") + IInteroperability::DoubleToString(Input.GetValue(i)));
            }
            
            msg += IString(" ;Output : ");
            for(int i=0;i<Output.Size();i++)
            {
                msg += (IString(" ;") + IInteroperability::DoubleToString(Output.GetValue(i)));
            }
            CLogger::HeavyLog(msg);
        }       
};
double CVector::BFALSE = -1.0;
double CVector::BTRUE = 1.0;
//+------------------------------------------------------------------+
#endif
/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_MIN_MAX_DOUBLE
#define FILE_MIN_MAX_DOUBLE

#include "MathNet.h"

//+------------------------------------------------------------------+
class CMinMaxDouble{
    private:        
        double m_dX;
        double m_dMin;
        double m_dMax;
    
    public:
        static const double MinX;
        static const double MaxX;

        void Init(int nr, int ib)
        {
            m_dMin = MinX;
            m_dMax = MaxX;
            m_dX = m_dMin + (m_dMax - m_dMin) / ib * CMathNet::AmountOfOnes(nr, ib);
        }
        
        double const Value()
        {
            return CMathNet::FunctionWithAsymptotes(m_dMin, m_dMax, m_dX);
        }

        void AdaptByGradient(double dGradient, double dLernParam)
        {
            m_dX -= dLernParam * dGradient * CMathNet::DerivatFunctionWithAsymptotes(m_dMin, m_dMax, m_dX);
        }
};
const double CMinMaxDouble::MinX = -1.0;
const double CMinMaxDouble::MaxX = 1.0;
//+------------------------------------------------------------------+
#endif
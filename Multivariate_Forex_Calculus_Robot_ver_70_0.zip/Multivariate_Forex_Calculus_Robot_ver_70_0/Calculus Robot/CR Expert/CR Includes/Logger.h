/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_LOGGER
#define FILE_LOGGER

#include "Config.h"
#include "../../Interoperability/String.h"
#include "../../Interoperability/FileWriter.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/DateTime.h"

//+------------------------------------------------------------------+
class CLogger {
private:
	static IFileWriter Writer;
	static IFileWriter WriterSpecial;
	static IFileWriter WriterTrades;
	static IFileWriter WriterModificators;
	static IFileWriter WriterProfitPast;
	static bool Initialized;

public:
	void static Init(IString &name)
	{
		if (!Initialized)
		{
			IString time = IDateTime::TimeCurrentAsString();

			time.StringReplace(".", "_");
			time.StringReplace(":", "_");
			time.StringReplace(" ", "_");

			IString nameW;

			nameW.AssignString(name + "_" + time + ".txt");
			Writer.Initialize(nameW);

			nameW.AssignString(IString("special") + "_" + time + ".txt");
			WriterSpecial.Initialize(nameW);

			nameW.AssignString(IString("trades") + "_" + time + ".txt");
			WriterTrades.Initialize(nameW);

			nameW.AssignString(IString("modificators") + "_" + time + ".txt");
			WriterModificators.Initialize(nameW);

			nameW.AssignString(IString("ProfitPastValues.txt"));
			WriterProfitPast.Initialize(nameW);

			Initialized = true;
		}
	}

	void static Log(const IString &msg)
	{
	   IString tmp(msg);
	
		IInteroperability::Print(tmp);
		LogInFile(tmp);
	}

	void static LogInFile(const IString &msg)
	{
		IString time(IDateTime::TimeCurrentAsString());
      IString tmp(msg);
       
		Writer.Write(time + ", " + tmp);
	}

	void static HeavyLog(const IString &msg)
	{
		if (CConfig::HeavyLoggingInFile)
		{
			LogInFile(msg);
		}
	}

	void static LogSpecial(const IString &msg)
	{
		IString time(IDateTime::TimeCurrentAsString());
      IString tmp(msg);

		WriterSpecial.Write(time + ", " + tmp);
		Log(tmp);
	}

	void static LogTrade(const IString &msg)
	{
		IString time(IDateTime::TimeCurrentAsString());
      IString tmp(msg);
      
		WriterTrades.Write(time + ", " + tmp);
		Log(tmp);
	}

	void static LogFromModificator(const IString &msg)
	{
		IString time;
      IString tmp(msg);

		time = IDateTime::TimeCurrentAsString();

		WriterModificators.Write(time + ", " + tmp);
		Log(tmp);
	}

	void static LogFromProfitPast(const IString &msg)
	{
		IString time;
      IString tmp(msg);
      
		time = IDateTime::TimeCurrentAsString();

		WriterProfitPast.Write(time + ", " + tmp);
		Log(tmp);
	}
};
IFileWriter CLogger::Writer;
IFileWriter CLogger::WriterSpecial;
IFileWriter CLogger::WriterTrades;
IFileWriter CLogger::WriterModificators;
IFileWriter CLogger::WriterProfitPast;
bool CLogger::Initialized = false;
//+------------------------------------------------------------------+
class CLogProgress {
private:
	double AMOUNT;
	double m_Max;
	int m_LastDisplayed;
	IString m_Msg;

public:
	CLogProgress()
	{
		AMOUNT = 10.0;
		m_LastDisplayed = 0;
	}

	void Init(IString &msg, int max)
	{
		m_Max = max;
		m_Msg = msg;
	}

	void Log(int nr)
	{
		double display = nr * AMOUNT / m_Max;

		if (m_LastDisplayed < (int)(display))
		{
			CLogger::LogSpecial(m_Msg + IInteroperability::DoubleToString(display));
			m_LastDisplayed = (int)(display);
		}
	}
};
//+------------------------------------------------------------------+
#endif
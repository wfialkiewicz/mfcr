/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_FAR_PAST_DATA_FILE
#define FILE_FAR_PAST_DATA_FILE

#include "Logger.h"
#include "../../Interoperability/FileWriter.h"
#include "../../Interoperability/FileReader.h"
#include "CurrencyPairs.h"
#include "Values.h"
#include "../../Interoperability/Interoperability.h"
#include "Config.h"

//+------------------------------------------------------------------+
class CFarPastDataFile {
private:
	static IFileWriter Writer;

	static bool Parse(IString &line, CCurrencyPairs &pairs, CPastValues &values)
	{
		IGenericObjectArray<IString> arr;

		line.StringSplit(';', arr);
		if (IInteroperability::StringToDouble((*(arr.GetPointerToValue(1)))) != 0.0)
		{
			values.Date = IInteroperability::StringToTime((*(arr.GetPointerToValue(0))));
			values.Values.Resize(arr.Size() - 2);
			for (int i = 1; i < arr.Size() - 1 ; i++)
			{
				values.Values.SetValue(i - 1, IInteroperability::StringToDouble((*(arr.GetPointerToValue(i)))));
			}
			return true;
		}
		return false;
	}

public:
	static void Init()
	{
		IString name("FarPastData.txt");

		Writer.Initialize(name);
	}

	static void WriteDataColumnsValues(CCurrencyPairs &pairs)
	{
		IString dataNames(""), name;
		IDateTime time = IDateTime::TimeCurrent();

		dataNames += (time.TimeCurrentAsString() + IString(";"));
		for (int i = 0; i < pairs.AmountCurrencyPairsToBuy(); i++)
		{
			name = pairs.ReturnCurrencyPairToBuyNr(i);
			dataNames += (IInteroperability::DoubleToString(CValues::BuyPrice(name)) + IString(";"));
		}
		for (int i = 0; i < pairs.AmountCurrencyPairsToSell(); i++)
		{
			name = pairs.ReturnCurrencyPairToSellNr(i);
			dataNames += (IInteroperability::DoubleToString(CValues::BuyPrice(name)) + IString(";"));
		}
		for (int i = 0; i < pairs.AmountOtherSymbolsToBuy(); i++)
		{
			name = pairs.ReturnOtherSymbolToBuyNr(i);
			dataNames += (IInteroperability::DoubleToString(CValues::BuyPrice(name)) + IString(";"));
		}
		for (int i = 0; i < pairs.AmountOtherSymbolsToSell(); i++)
		{
			name = pairs.ReturnOtherSymbolToSellNr(i);
			dataNames += (IInteroperability::DoubleToString(CValues::BuyPrice(name)) + IString(";"));
		}
		Writer.Write(dataNames);
	}

    static void WriteDataColumnsNames(CCurrencyPairs &pairs)
	{
		IString dataNames("");
		IDateTime time = IDateTime::TimeCurrent();

		dataNames += (time.TimeCurrentAsString() + IString(";"));
		for (int i = 0; i < pairs.AmountCurrencyPairsToBuy(); i++)
		{
			dataNames += (pairs.ReturnCurrencyPairToBuyNr(i) + IString(";"));
		}
		for (int i = 0; i < pairs.AmountCurrencyPairsToSell(); i++)
		{
			dataNames += (pairs.ReturnCurrencyPairToSellNr(i) + IString(";"));
		}
		for (int i = 0; i < pairs.AmountOtherSymbolsToBuy(); i++)
		{
			dataNames += (pairs.ReturnOtherSymbolToBuyNr(i) + IString(";"));
		}
		for (int i = 0; i < pairs.AmountOtherSymbolsToSell(); i++)
		{
			dataNames += (pairs.ReturnOtherSymbolToSellNr(i) + IString(";"));
		}
		Writer.Write(dataNames);
	}

	static void ReadDataColumnsValues(CCurrencyPairs &pairs, IGenericObjectArray<CPastValues> &pastValues)
	{
		IString name("FarPastData.txt");
		IFileReader Reader;
		IString line;
		CPastValues values;

		Reader.Initialize(name);
		line = Reader.ReadLine();
		while (!IString::AreEqual(line, IString("")))
		{
			if (Parse(line, pairs, values))
			{
				pastValues.GrowIfNeeded();
				pastValues.IncreaseSize();
				CPastValues::CopyValues(values, (*(pastValues.GetPointerToValue(pastValues.LastNr()))));
			}
			line = Reader.ReadLine();
		}
	}

	static bool IsPastDataLongEnough(IGenericObjectArray<CPastValues> &pastValues)
	{
		if (IDateTime::MinutesDiff((*(pastValues.GetPointerToValue(0))).Date, (*(pastValues.GetPointerToValue(pastValues.Size() - 1))).Date) > CConfig::MinPastDataLength * 24 * 60)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	static void NarrowPastDataLenght(IGenericObjectArray<CPastValues> &pastValues)
	{
		IGenericObjectArray<CPastValues> pastTmp;
		IDateTime lastTime = (*(pastValues.GetPointerToValue(pastValues.Size() - 1))).Date;
		int first = -1;

		pastTmp.Resize(pastValues.Size());
		for (int i = 0; i < pastValues.Size(); i++)
		{
			CPastValues::CopyValues((*(pastValues.GetPointerToValue(i))), (*(pastTmp.GetPointerToValue(i))));
			if ((first == -1) && (IDateTime::MinutesDiff((*(pastValues.GetPointerToValue(i))).Date, lastTime) <= CConfig::MaxPastDataLength * 24 * 60))
			{
				first = i;
			}
		}
		pastValues.Resize(0);
		pastValues.Resize(pastTmp.Size() - first);
		for (int i = first; i < pastTmp.Size(); i++)
		{
			CPastValues::CopyValues((*(pastTmp.GetPointerToValue(i))), (*(pastValues.GetPointerToValue(i - first))));
		}
	}
};
IFileWriter CFarPastDataFile::Writer;
//+------------------------------------------------------------------+
#endif
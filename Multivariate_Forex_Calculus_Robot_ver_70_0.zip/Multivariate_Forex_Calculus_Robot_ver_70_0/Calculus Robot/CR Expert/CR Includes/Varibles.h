/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_VARIBLES
#define FILE_VARIBLES

#include "Config.h"
#include "Logger.h"
#include "../../Interoperability/String.h"
#include "../../Interoperability/FileWriter.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/FileReader.h"

//+------------------------------------------------------------------+
class CVaribles{
    private:
		static IString m_FileName;
		bool m_ReverseTrades;
		double m_LotSize;
		bool m_ExecuteTrades;

		static void CreateFile()
		{
			IFileWriter writer;

			writer.Delete(m_FileName);
			writer.Initialize(m_FileName);
			if (CConfig::ReverseTrades)
			{
				writer.Write(IString("ReverseTrades:true"));
			}
			else
			{
				writer.Write(IString("ReverseTrades:false"));
			}
		 	writer.Write(IString("LotSize:") + IInteroperability::DoubleToString(CConfig::LotSize));
			if (CConfig::ExecuteTrades)
			{
				writer.Write(IString("ExecuteTrades:true"));
			}
			else
			{
				writer.Write(IString("ExecuteTrades:false"));
			}
		}

    public:
		static void Init()
		{
			CreateFile();
		}

		void ReadVaribles()
		{
			IFileReader reader;
			IString line;
			IGenericObjectArray<IString> res;
			IString sign(":");

			reader.Initialize(m_FileName);
			line = reader.ReadLine();
			m_ReverseTrades = CConfig::ReverseTrades;
			if (line.Contains(sign))
			{
				line.StringSplit(':', res);
				if (IString::AreEqual((*(res.GetPointerToValue(1))), IString("true")))
				{
					m_ReverseTrades = true;
					CLogger::LogSpecial(IString("Readed Varibles ReverseTrades = true."));
				}
				else if (IString::AreEqual((*(res.GetPointerToValue(1))), IString("false")))
				{
					m_ReverseTrades = false;
					CLogger::LogSpecial(IString("Readed Varibles ReverseTrades = false."));
				}
			}
			line = reader.ReadLine();
			m_LotSize = CConfig::LotSize;
			if (line.Contains(sign))
			{
				res.Resize(0);
				line.StringSplit(':', res);
				m_LotSize = IInteroperability::StringToDouble((*(res.GetPointerToValue(1))));
				CLogger::LogSpecial(IString("Readed Varibles LotSize = ") + IInteroperability::DoubleToString(m_LotSize));
			}
			line = reader.ReadLine();
			m_ExecuteTrades = CConfig::ExecuteTrades;
			if (line.Contains(sign))
			{
				res.Resize(0);
				line.StringSplit(':', res);
				if (IString::AreEqual((*(res.GetPointerToValue(1))), IString("true")))
				{
					m_ExecuteTrades = true;
					CLogger::LogSpecial(IString("Readed Varibles ExecuteTrades = true."));
				}
				else if (IString::AreEqual((*(res.GetPointerToValue(1))), IString("false")))
				{
					m_ExecuteTrades = false;
					CLogger::LogSpecial(IString("Readed Varibles ExecuteTrades = false."));
				}
			}
		}

		bool ReverseTrades()
		{
			return m_ReverseTrades;
		}

		double LotSize()
		{
			return m_LotSize;
		}

		bool ExecuteTrades()
		{
			return m_ExecuteTrades;
		}
};
IString CVaribles::m_FileName = IString("ConfigurationVaribles.txt");
//+------------------------------------------------------------------+
#endif
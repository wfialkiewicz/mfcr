/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_PARAMS
#define FILE_PARAMS

#include "Config.h"
#include "Logger.h"
#include "Trading.h"
#include "../../Interoperability/DateTime.h"
#include "../../Interoperability/GenericArray.h"
#include "../../Interoperability/GenericObjectArray.h"
#include "Fcnnhn/Vector.h"
#include "../../Interoperability/SortableArray.h"

//+------------------------------------------------------------------+
class CFinishedTrade {
public:
	bool m_Success;
	IDateTime m_Date;
	bool m_PeriodStart;

	CFinishedTrade()
	{
		m_PeriodStart = false;
	}
};
//+------------------------------------------------------------------+
class CResult
{
public:
	int Hours;
	int Trade;
	double FailedRatio;
	int Successfull;
	int Failed;
	double SuccesfullRatio;
};
//+------------------------------------------------------------------+
class CParams {
private:
	IGenericArray<bool> m_PastTrades;
	IGenericObjectArray<IDateTime> m_PastTimes;
	int m_PastTradeCurr;
	IGenericObjectArray<CFinishedTrade> m_PastTradesWithRT;
	int m_PastTradeWithRTCurr;
	int m_AfterTrendHoursToAnalysisLength;
	double m_PastTradeWithRTSwitchRatio;
	int m_PastTradeWithRTMinAmount;
	bool m_AssingedParams;
	IGenericObjectArray<CResult> m_Results;

	void AssignMethoDParams(int afterTrendHoursToAnalysisLength, double pastTradeWithRTSwitchRatio, int pastTradeWithRTMinAmount)
	{
		m_AfterTrendHoursToAnalysisLength = afterTrendHoursToAnalysisLength;
		m_PastTradeWithRTSwitchRatio = pastTradeWithRTSwitchRatio;
		m_PastTradeWithRTMinAmount = pastTradeWithRTMinAmount;
		m_AssingedParams = true;
	}

	void CheckPermutation(IGenericObjectArray<CTrade> &trades, int hours, int tradesAm, double ratio)
	{
		bool reverseAfter = false;
		int globalSuccesfull = 0;
		int globalFailed = 0;

		IDateTime dateWindowStart = (*(trades.GetPointerToValue(0))).OpenTime;
		IDateTime dateWindowEnd = IDateTime::AddMinutes(dateWindowStart, 60 * hours);

		for (int i = 0; i < trades.Size(); i++)
		{
			int successfull = 0;
			int failed = 0;

			for (int j = 0; j < trades.Size(); j++)
			{
				if ((*(trades.GetPointerToValue(j))).OpenTime > dateWindowStart && (*(trades.GetPointerToValue(j))).OpenTime < dateWindowEnd)
				{
					(*(trades.GetPointerToValue(j))).AfterReverseTrades = reverseAfter;
				}
				if ((*(trades.GetPointerToValue(j))).CloseTime > dateWindowStart && (*(trades.GetPointerToValue(j))).CloseTime < dateWindowEnd)
				{
					if (((*(trades.GetPointerToValue(j))).Successfull && !(*(trades.GetPointerToValue(j))).AfterReverseTrades) || ((!(*(trades.GetPointerToValue(j))).Successfull && (*(trades.GetPointerToValue(j))).AfterReverseTrades)))
					{
						successfull++;
					}
					else
					{
						failed++;
					}
				}
			}

			globalSuccesfull += successfull;
			globalFailed += failed;

			if (tradesAm <= successfull + failed && !(successfull >= ratio * failed))
			{
				reverseAfter = !reverseAfter;
			}

			dateWindowStart = dateWindowEnd;

			if (IString::AreEqual(IDateTime::GetDay(dateWindowStart), IString("Saturday")))
			{
				dateWindowStart = IDateTime::AddMinutes(dateWindowStart, 48 * 60);
				if (dateWindowStart.GetHour() > 0)
				{
				   int minus = -(dateWindowStart.GetHour() - 1) * 60;
					dateWindowStart = IDateTime::AddMinutes(dateWindowStart, minus);
				}
			}
			else if (IString::AreEqual(IDateTime::GetDay(dateWindowStart), IString("Sunday")))
			{
				dateWindowStart = IDateTime::AddMinutes(dateWindowStart, 24 * 60);
				if (dateWindowStart.GetHour() > 0)
				{
				   int minus = -(dateWindowStart.GetHour() - 1) * 60;
					dateWindowStart = IDateTime::AddMinutes(dateWindowStart, minus);
				}
			}

			dateWindowEnd = IDateTime::AddMinutes(dateWindowStart, hours * 60);
		}

		CLogger::HeavyLog(IString("Combination hours : ") + IInteroperability::IntegerToString(hours) + IString(", trades : ") + IInteroperability::IntegerToString(tradesAm) +IString(", ratio : ") + IInteroperability::DoubleToString(ratio) + IString(", successfull : ") + IInteroperability::IntegerToString(globalSuccesfull) + IString(", failed : ") + IInteroperability::IntegerToString(globalFailed)+ IString("."));
		CResult res;

		res.Failed = globalFailed;
		res.Successfull = globalSuccesfull;
		res.Trade = tradesAm;
		res.Hours = hours;
		res.FailedRatio = ratio;
		if ((globalSuccesfull + globalFailed) != 0)
		{
			res.SuccesfullRatio = (double)globalSuccesfull / ((double)globalSuccesfull + (double)globalFailed);
		}
		else
		{
			res.SuccesfullRatio = 0;
		}

		m_Results.Add(res);
   }

	void GetBestWorstPermutations(int &best, int &worst)
	{
		ISortableArray<double> sortable;

		sortable.Resize(m_Results.Size());
		for (int i = 0; i < m_Results.Size(); i++)
		{
			sortable.SetPos(i, i);
			sortable.SetValue(i, (*(m_Results.GetPointerToValue(i))).SuccesfullRatio);
		}
		sortable.Sort();
		best = sortable.GetPos(sortable.Size() - 1);
		worst = sortable.GetPos(0);
	}

	void LogPermutation(int permNr, IString &name)
	{
		CLogger::LogSpecial(name + IString(" , hours : ") + IInteroperability::IntegerToString((*(m_Results.GetPointerToValue(permNr))).Hours) + IString(", trades : ") + IInteroperability::IntegerToString((*(m_Results.GetPointerToValue(permNr))).Trade) + ", ratio : " + IInteroperability::DoubleToString((*(m_Results.GetPointerToValue(permNr))).FailedRatio) + ", successfull : " + IInteroperability::IntegerToString((*(m_Results.GetPointerToValue(permNr))).Successfull) + IString(", failed : ") + IInteroperability::IntegerToString((*(m_Results.GetPointerToValue(permNr))).Failed));
	}

	void FindCommon(int nr, double hoursPercent, double tradesPercent, double ratioPercent, IGenericArray<int> &common)
	{
		common.Resize(0);

		for (int i = 0; i < m_Results.Size(); i++)
		{
			if (IInteroperability::MathAbs((*(m_Results.GetPointerToValue(i))).Hours - (*(m_Results.GetPointerToValue(nr))).Hours) <= hoursPercent)
			{
				if (IInteroperability::MathAbs((*(m_Results.GetPointerToValue(i))).Trade - (*(m_Results.GetPointerToValue(nr))).Trade) <= tradesPercent)
				{
					if (IInteroperability::MathAbs((*(m_Results.GetPointerToValue(i))).FailedRatio - (*(m_Results.GetPointerToValue(nr))).FailedRatio) <= ratioPercent)
					{
						common.Add(i);
					}
				}
			}
		}
	}

	void FindBestCommonCombination(double hoursPercent, double tradesPercent, double ratioPercent, int &bestCommon, int &worstCommon)
	{
		ISortableArray<double> SuccessSums;
        IGenericArray<int> common;
		CLogProgress progress;
		IString str("Finding Commons For : ");

		progress.Init(str, m_Results.Size());

		SuccessSums.Resize(m_Results.Size());
		for (int i = 0; i < m_Results.Size(); i++)
		{
			double sum = 0.0;

			FindCommon(i, hoursPercent, tradesPercent, ratioPercent, common);
			SuccessSums.SetPos(i, i);
			for (int j = 0; j < common.Size(); j++)
			{
				sum += (*(m_Results.GetPointerToValue(common.GetValue(j)))).SuccesfullRatio;
			}
			SuccessSums.SetValue(i, sum);
			progress.Log(i);
		}
		SuccessSums.Sort();

		bestCommon = SuccessSums.GetPos(SuccessSums.Size() - 1);
        worstCommon = SuccessSums.GetPos(0);
	}

	public:
		IDateTime Start;
		int SuccessfullInRow;
		int FailedInRow;
		bool StartedTrading;

		int SuccessfullFinds;
		int FailedFinds;

		bool AfterTrendReverseTrades;
		bool AutomaticParamsReverseTrades;

		void AddPastTrade(bool success)
		{
			IDateTime date = IDateTime::TimeCurrent();

			if (m_PastTradeCurr < CConfig::PastTradeMaxAmount)
			{
				m_PastTrades.SetValue(m_PastTradeCurr, success);
				m_PastTimes.SetValue(m_PastTradeCurr, date);
				m_PastTradeCurr++;
			}
			else
			{
				for (int i = 1; i < CConfig::PastTradeMaxAmount; i++)
				{
					m_PastTrades.SetValue(i - 1, m_PastTrades.GetValue(i));
					m_PastTimes.SetValue(i - 1, (*(m_PastTimes.GetPointerToValue(i))));
				}
				m_PastTrades.SetValue(m_PastTradeCurr - 1, success);
				m_PastTimes.SetValue(m_PastTradeCurr - 1, date);
			}
			CLogger::HeavyLog(IString("Trades in Params : ") + IInteroperability::IntegerToString(m_PastTradeCurr));
		}

		void WereAfterTradesSuccesfull()
		{
			if (m_PastTradeWithRTCurr > 0)
			{
				IDateTime timeNow = IDateTime::TimeCurrent();
				int AfterTrendHoursToAnalysisLength;
				double PastTradeWithRTSwitchRatio;
				int PastTradeWithRTMinAmount;

				if (CConfig::UseAfterTrendAutomaticParams || !m_AssingedParams)
				{
					AfterTrendHoursToAnalysisLength = CConfig::AfterTrendHoursToAnalysisLength;
					PastTradeWithRTSwitchRatio = CConfig::PastTradeWithRTSwitchRatio;
					PastTradeWithRTMinAmount = CConfig::PastTradeWithRTMinAmount;
				}
				else
				{
					AfterTrendHoursToAnalysisLength = m_AfterTrendHoursToAnalysisLength;
					PastTradeWithRTSwitchRatio = m_PastTradeWithRTSwitchRatio;
					PastTradeWithRTMinAmount = m_PastTradeWithRTMinAmount;
				}

				if ((*(m_PastTradesWithRT.GetPointerToValue(0))).m_Date < IDateTime::MinusHours(timeNow, AfterTrendHoursToAnalysisLength))
				{
					int success = 0;
					int failed = 0;
					bool wasPeriodStart = false;

					for (int i = m_PastTradeWithRTCurr - 1; i >= 0; i--)
					{
						if ((*(m_PastTradesWithRT.GetPointerToValue(i))).m_Date > IDateTime::MinusHours(timeNow, AfterTrendHoursToAnalysisLength))
						{
							if ((*(m_PastTradesWithRT.GetPointerToValue(i))).m_Success)
							{
								success++;
							}
							else
							{
								failed++;
							}
							if ((*(m_PastTradesWithRT.GetPointerToValue(i))).m_PeriodStart)
							{
								wasPeriodStart = true;
							}
						}
						else
						{
							break;
						}
					}

					CLogger::LogSpecial(IString("WereAfterTradesSuccesfull, success : ") + IInteroperability::IntegerToString(success) + IString(", failed : ") + IInteroperability::IntegerToString(failed) + IString(", wasPeriodStart : ") + IInteroperability::BoolToString(wasPeriodStart));

					if (success >= failed * PastTradeWithRTSwitchRatio)
					{
					}
					else if (!wasPeriodStart && (success + failed >= PastTradeWithRTMinAmount))
					{
						AfterTrendReverseTrades = !AfterTrendReverseTrades;
						(*(m_PastTradesWithRT.GetPointerToValue(m_PastTradeWithRTCurr - 1))).m_PeriodStart = true;
						CLogger::LogSpecial(IString("AfterTrendReverseTrades : ") + IInteroperability::BoolToString(AfterTrendReverseTrades));
					}
				}
			}
		}

		void AddPastTradeWithRT(bool success)
		{
			CFinishedTrade trade;

			trade.m_Success = success;
			trade.m_Date = IDateTime::TimeCurrent();

			if (m_PastTradeWithRTCurr < CConfig::PastTradeWithRTMaxAmount)
			{
				m_PastTradesWithRT.SetValue(m_PastTradeWithRTCurr, trade);
				m_PastTradeWithRTCurr++;
			}
			else
			{
				for (int i = 1; i < CConfig::PastTradeWithRTMaxAmount; i++)
				{
					m_PastTradesWithRT.SetValue(i - 1, (*(m_PastTradesWithRT.GetPointerToValue(i))));
				}
				m_PastTradesWithRT.SetValue(m_PastTradeWithRTCurr - 1, trade);
			}
			CLogger::HeavyLog(IString("Trades with RT in Params : ") + IInteroperability::IntegerToString(m_PastTradeWithRTCurr));
		}

		void ZeroFinds()
		{
			SuccessfullFinds = 0;
			FailedFinds = 0;
		}

		CParams()
		{
			if (CConfig::SuccededInRow == 0)
			{
				StartedTrading = true;
			}
			else
			{
				StartedTrading = false;
			}
			if (!CConfig::ReverseTrades)
			{
				SuccessfullInRow = 0;
				FailedInRow = CConfig::SuccededInRow;
			}
			else
			{
				SuccessfullInRow = CConfig::SuccededInRow;
				FailedInRow = 0;
			}
			ZeroFinds();
			m_PastTrades.Resize(CConfig::PastTradeMaxAmount);
			m_PastTimes.Resize(CConfig::PastTradeMaxAmount);
			m_PastTradeCurr = 0;
			m_PastTradesWithRT.Resize(CConfig::PastTradeWithRTMaxAmount);
			AfterTrendReverseTrades = false;
			AutomaticParamsReverseTrades = false;
		}

		bool GetSpeed(int lastHours, double &speed)
		{
			IDateTime date = IDateTime::TimeCurrent();
			date = IDateTime::AddMinutes(date, -60 * lastHours);
			double am = 0.0;

			if (m_PastTradeCurr > 0)
			{
				if ((*(m_PastTimes.GetPointerToValue(0))) > date)
				{
					return false;
				}
			}
			else
			{
				return false;
			}

			if (IString::AreEqual(IDateTime::GetDay(date), IString("Sunday")))
			{
				date = IDateTime::AddMinutes(date, -60 * 48);
			}
			else if (IString::AreEqual(IDateTime::GetDay(date), IString("Saturday")))
			{
				date = IDateTime::AddMinutes(date, -60 * 24);
			}


			for (int i = 0; i < m_PastTradeCurr; i++)
			{
				if ((*(m_PastTimes.GetPointerToValue(i))) > date)
				{
					if (m_PastTrades.GetValue(i))
					{
						am++;
					}
					else
					{
						am--;
					}
				}
			}
			speed = am / lastHours;
			return true;
		}

		bool FillVector(CVector &vec, int size)
		{
			if (size <= m_PastTradeCurr)
			{
				vec.Init(size, 0);
				for (int i = 0; i < size; i++)
				{
					if (m_PastTrades.GetValue(m_PastTradeCurr - size + i))
					{
						vec.Input.SetValue(i, CVector::BTRUE);
						CLogger::HeavyLog(IString("FillVector setting : true"));
					}
					else
					{
						vec.Input.SetValue(i, CVector::BFALSE);
						CLogger::HeavyLog(IString("FillVector setting : false"));
					}
				}
				CLogger::HeavyLog(IString("FillVector returning : true"));
				return true;
			}
			else
			{
				CLogger::HeavyLog(IString("FillVector returning : false"));
				return false;
			}
		}

		void DetermineMethodDParams(IGenericObjectArray<CTrade> &trades)
		{
			CLogProgress progress;
			IString str("Method D checking combinations : ");

			progress.Init(str, CConfig::PastTradeWithRTAutomaticParamsHoursMax - CConfig::PastTradeWithRTAutomaticParamsHoursMin);
			for (int h = CConfig::PastTradeWithRTAutomaticParamsHoursMin; h <= CConfig::PastTradeWithRTAutomaticParamsHoursMax; h++)
			{
				for (int t = CConfig::PastTradeWithRTAutomaticParamsTradesMin; t <= CConfig::PastTradeWithRTAutomaticParamsTradesMax; t++)
				{
					for (double r = CConfig::PastTradeWithRTAutomaticParamsSwitchRatioMin; r <= CConfig::PastTradeWithRTAutomaticParamsSwitchRatioMax; r += CConfig::PastTradeWithRTAutomaticParamsSwitchRatioStep)
					{
						CheckPermutation(trades, h, t, r);
					}
				}
				progress.Log(h - CConfig::PastTradeWithRTAutomaticParamsHoursMin);
			}

			int best, worst;
			int bestCommon = 0, worstCommon = 0;
			double percent = CConfig::PastTradWithRTCommonCombinationIncludePercent;

			GetBestWorstPermutations(best, worst);
			FindBestCommonCombination(percent * (CConfig::PastTradeWithRTAutomaticParamsHoursMax - CConfig::PastTradeWithRTAutomaticParamsHoursMin) / 2.0, percent * (CConfig::PastTradeWithRTAutomaticParamsTradesMax - CConfig::PastTradeWithRTAutomaticParamsTradesMin) / 2.0, percent * (CConfig::PastTradeWithRTAutomaticParamsSwitchRatioMax - CConfig::PastTradeWithRTAutomaticParamsSwitchRatioMin) / 2.0, bestCommon, worstCommon);

			IString bestStr("BestCombination"); IString worstStr("WorstCombination");
			IString bestCommonStr("BestCommonCombination"); IString worstCommonStr("WorstCommonCombination");
			IString chosenStr("ChosenCombination");

			LogPermutation(best, bestStr);
			LogPermutation(worst, worstStr);
			LogPermutation(bestCommon, bestCommonStr);
			LogPermutation(worstCommon, worstCommonStr);

			int chosen = best;

			AutomaticParamsReverseTrades = false;

			switch (CConfig::PastTradeWithRTCombination)
			{
			case MethodDCombinationType::BEST:
				if (CConfig::PastTradeWithRTAutomaticReverseTrade)
				{
					if ((*(m_Results.GetPointerToValue(best))).SuccesfullRatio < (1.0 - (*(m_Results.GetPointerToValue(worst))).SuccesfullRatio))
					{
						chosen = worst;
						AutomaticParamsReverseTrades = true;
					}
					else
					{
						chosen = best;
					}
				}
				else
				{
					chosen = best;
				}
				break;

			case MethodDCombinationType::BEST_COMMON:
				if (CConfig::PastTradeWithRTAutomaticReverseTrade)
				{
					if ((*(m_Results.GetPointerToValue(bestCommon))).SuccesfullRatio < (1.0 - (*(m_Results.GetPointerToValue(worstCommon))).SuccesfullRatio))
					{
						chosen = worstCommon;
						AutomaticParamsReverseTrades = true;
					}
					else
					{
						chosen = bestCommon;
					}
				}
				else
				{
					chosen = bestCommon;
				}
				break;

			case MethodDCombinationType::WORST:
				if (CConfig::PastTradeWithRTAutomaticReverseTrade)
				{
					if ((*(m_Results.GetPointerToValue(worst))).SuccesfullRatio < (1.0 - (*(m_Results.GetPointerToValue(best))).SuccesfullRatio))
					{
						chosen = best;
						AutomaticParamsReverseTrades = true;
					}
					else
					{
						chosen = worst;
					}
				}
				else
				{
					chosen = worst;
				}
				break;

			case MethodDCombinationType::WORST_COMMON:
				if (CConfig::PastTradeWithRTAutomaticReverseTrade)
				{
					if ((*(m_Results.GetPointerToValue(worstCommon))).SuccesfullRatio < (1.0 - (*(m_Results.GetPointerToValue(bestCommon))).SuccesfullRatio))
					{
						chosen = bestCommon;
						AutomaticParamsReverseTrades = true;
					}
					else
					{
						chosen = worstCommon;
					}
				}
				else
				{
					chosen = worstCommon;
				}
				break;

			default:
				break;
			}
			AssignMethoDParams((*(m_Results.GetPointerToValue(chosen))).Hours, (*(m_Results.GetPointerToValue(chosen))).FailedRatio, (*(m_Results.GetPointerToValue(chosen))).Trade);
			LogPermutation(chosen, chosenStr);
			CLogger::LogSpecial(IString("AutomaticReverseTrades : ") + IInteroperability::BoolToString(AutomaticParamsReverseTrades));
		}
	};
	//+------------------------------------------------------------------+
#endif

/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_MULTI_ANALYZER_PAST
#define FILE_MULTI_ANALYZER_PAST

#include "MultiAnalyzerBase.h"
#include "../../Interoperability/GenericObjectArray.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/DateTime.h"

//+------------------------------------------------------------------+
class CMultiAnalyzerPast : public CMultiAnalyzerBase {
private:
	void AddToAnalysis(int dataNr, bool Symbol, bool Buy)
	{
		double val;
		double difference = 0.0;

		for (int i = 0; i < (*m_Pairs).AmountSymbols(Symbol, Buy); i++)
		{
			IDateTime time((*values).ReturnDateTimeOfPastNr(dataNr));
			IString pair((*m_Pairs).ReturnSymbol(i, Symbol, Buy));

			val = (*values).ReturnPastValueNrToBuy(dataNr, i);
			(*WasMinimumMaximum(Symbol, Buy)).SetValue(i, (*((*Analyzers(Symbol, Buy)).GetPointerToValue(i))).CheckForMinimumMaximum(val, time, dataNr));
			if ((*((*ValuesAnalyzers(Symbol, Buy)).GetPointerToValue(i))).CheckProfit(pair, val, difference, false))
			{
				CPastPoint point = (*((*ValuesAnalyzers(Symbol, Buy)).GetPointerToValue(i))).ReturnPoint();

				m_PastPoints.AddPoint(point);
			}
			if ((*WasMinimumMaximum(Symbol, Buy)).GetValue(i) != CAnalyzer::NO_RESULT)
			{
				double diff = IInteroperability::MathAbs(val - (*WasMinimumMaximum(Symbol, Buy)).GetValue(i));
				CPastPoint point;

				point.SymbolNr = i;
				point.Symbol = Symbol;
				point.SymbolBuy = Buy;
				point.MinimumMaximumPointNr = (*((*Analyzers(Symbol, Buy)).GetPointerToValue(i))).ReturnLastMinimumMaximumDataNr();
				point.EstablishingMinimumMaximumPointNr = dataNr;
				point.Val = val;
				point.Diff = diff;
				point.ValDate = (*values).ReturnDateTimeOfPastNr(dataNr);

				(*((*ValuesAnalyzers(Symbol, Buy)).GetPointerToValue(i))).SearchForProfit(pair, val, (*m_Pairs).ReturnUpperLimit(val, diff, i, Symbol, Buy), (*m_Pairs).ReturnLowerLimit(val, diff, i, Symbol, Buy), Buy, point);
			}
		}
	}

	void SavePastPoints(IGenericObjectArray<CPastPoint> &points, IGenericObjectArray<CPastPoint> &saved, int amount)
	{
		saved.Resize(amount);
		for (int i = 0; i < points.Size(); i++)
		{
			saved.SetValue(i, (*(points.GetPointerToValue(i))));
		}
	}

    void CountSuccessfullAndTradable(IGenericObjectArray<CPastPoint> &points, int &successfull, int &failed)
	{
		successfull = 0;
		failed = 0;

		for (int i = 0; i < points.Size(); i++)
		{
			if ((*(points.GetPointerToValue(i))).Successful)
			{
				successfull++;
			}
			else
			{
				failed++;
			}
		}
	}
	
	void LogAndSavePastPoints()
	{
		IGenericObjectArray<CPastPoint> buys;
		IGenericObjectArray<CPastPoint> sells;

		m_PastPoints.FillArrays(buys, sells);

		int successfullBuys;
		int successfullSells;
		int failedBuys;
		int failedSells;

		CountSuccessfullAndTradable(buys, successfullBuys, failedBuys);
		CountSuccessfullAndTradable(sells, successfullSells, failedSells);

		SavePastPoints(buys, PastPointsBuys, successfullBuys + failedBuys);
		SavePastPoints(sells, PastPointsSells, successfullSells + failedSells);

		CLogger::LogSpecial(IString("AnalyzerPast Buy Past Examples Amount : ") + IInteroperability::IntegerToString(successfullBuys + failedBuys) + ", Successfull : " + IInteroperability::IntegerToString(successfullBuys) + ", Failed : " + IInteroperability::IntegerToString(failedBuys));
		CLogger::LogSpecial(IString("AnalyzerPast Sell Past Examples Amount : ") + IInteroperability::IntegerToString(successfullSells + failedSells) + ", Successfull : " + IInteroperability::IntegerToString(successfullSells) + ", Failed : " + IInteroperability::IntegerToString(failedSells));
	}

public:
	IGenericObjectArray<CPastPoint> PastPointsBuys;
	IGenericObjectArray<CPastPoint> PastPointsSells;
		
	void Analyze()
	{
		Init(0);
		for (int i = 0; i < (*values).PastValuesAmount(); i++)
		{
			SetWasMMtoFalse();
			AddToAnalysis(i, true, true);
			AddToAnalysis(i, true, false);
			AddToAnalysis(i, false, true);
			AddToAnalysis(i, false, false);
		}
		LogAndSavePastPoints();
	}
};
//+------------------------------------------------------------------+
#endif
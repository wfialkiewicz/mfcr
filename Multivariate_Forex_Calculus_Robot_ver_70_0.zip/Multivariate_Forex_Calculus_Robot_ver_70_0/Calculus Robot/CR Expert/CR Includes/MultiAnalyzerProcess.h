/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_MULTI_ANALYZER_PROCESS
#define FILE_MULTI_ANALYZER_PROCESS

#include "MultiAnalyzerBase.h"
#include "Trading.h"
#include "Learning.h"
#include "LineProcessed.h"
#include "LinesProcessor.h"
#include "Params.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/DateTime.h"
#include "PastTradesAnalyzer.h"
#include "Rules.h"
#include "DistancesProvider.h"

//+------------------------------------------------------------------+
class CMultiAnalyzerProcess : public CMultiAnalyzerBase{
    private:
        int m_SearchingProfit;
     
        CLearning *m_LearningBuys;
        CLearning *m_LearningSells;
    
        CParams *m_Params;
		CPastTradesAnalyzer *m_PastTradesAnalyzer;
		CLearning *m_PastTradesLearn;

		CDistancesProvider *m_DistancesProvider;

        double m_MaximumLoss;
        double m_MinimumProfit;
    
        void ConvertToLearnVector(CLineProcessed &line, CVector &vec, double upperLimit, double lowerLimit)
        {
             vec.Init(line.Points.Size() + 1 + 1, 1);
             for(int i=0;i<line.Points.Size();i++)
             {
                 vec.Input.SetValue(i, line.Points.GetValue(i));
             }
             vec.Input.SetValue(line.Points.Size(), upperLimit);
             vec.Input.SetValue(line.Points.Size() + 1, lowerLimit);
        }
    
        bool ProceedWithBuy(IString &symbol, IDateTime &dateOfMinimumMaximum, IDateTime &dateOfEstablishingMinimumMaximum, double upperLimit, double lowerLimit)
        {
            if(!CConfig::UseSellBuyNeuralNetworks)
            {
                return true;
            }
            if((*m_LearningBuys).IsValid())
            {
                CLineProcessed line;
                CVector vec;
            
                CLinesProcessor::GenerateDifferentialLine(symbol, dateOfMinimumMaximum, dateOfEstablishingMinimumMaximum, line);
                ConvertToLearnVector(line, vec, upperLimit, lowerLimit);
                
                return (*m_LearningBuys).IsPositive(vec);
            }
            else
            {
                return false;
            }
        }

        bool ProceedWithSell(IString &symbol, IDateTime &dateOfMinimumMaximum, IDateTime &dateOfEstablishingMinimumMaximum, double upperLimit, double lowerLimit)
        {
            if(!CConfig::UseSellBuyNeuralNetworks)
            {
                return true;
            }
            if((*m_LearningSells).IsValid())
            {
                CLineProcessed line;
                CVector vec;
            
                CLinesProcessor::GenerateDifferentialLine(symbol, dateOfMinimumMaximum, dateOfEstablishingMinimumMaximum, line);
                ConvertToLearnVector(line, vec, upperLimit, lowerLimit);
                
                return (*m_LearningSells).IsPositive(vec);
            }
            else
            {
                return false;
            }
        }
        
		bool ProceedWithOperation(bool Buy, IString &symbol, IDateTime &dateOfMinimumMaximum, IDateTime &dateOfEstablishingMinimumMaximum, double upperLimit, double lowerLimit)
		{
			if (Buy)
			{
				return ProceedWithBuy(symbol, dateOfMinimumMaximum, dateOfEstablishingMinimumMaximum, upperLimit, lowerLimit);
			}
			else
			{
				return ProceedWithSell(symbol, dateOfMinimumMaximum, dateOfEstablishingMinimumMaximum, upperLimit, lowerLimit);
			}
		}

        bool ProceedWithTrade(IString &symbol, int symbolNr, bool Symbol, bool SymbolBuy, IDateTime &dateOfMinimumMaximum, IDateTime &dateOfEstablishingMinimumMaximum, double upperLimit, double lowerLimit)
        {
            if(!CConfig::UseIndividualNeuralNetworks)
            {
                return true;
            }
            if((*(*m_Pairs).ReturnLearningObject(symbolNr, Symbol, SymbolBuy)).IsValid())
            {
                CLineProcessed line;
                CVector vec;
            
                CLinesProcessor::GenerateDifferentialLine(symbol, dateOfMinimumMaximum, dateOfEstablishingMinimumMaximum, line);
                ConvertToLearnVector(line, vec, upperLimit, lowerLimit);
                
                return (*(*m_Pairs).ReturnLearningObject(symbolNr, Symbol, SymbolBuy)).IsPositive(vec);
            }
            else
            {
                return false;
            }
        }
    
        bool ReverseTrades(bool reverse)
        {
            bool res = false;
            
            if(reverse)
            {
                res = !res;
            }
            return res;
        }
        
		bool CheckTrendReverseTrades()
		{
			if (CConfig::UseTrendFromLogs && (*m_PastTradesAnalyzer).IsValid())
			{
				CVector vec;

				if ((*m_Params).FillVector(vec, (*m_PastTradesAnalyzer).BestInputsAmount()))
				{
					if (CConfig::PastTrendsUseNeuralNetwork && (*m_PastTradesLearn).IsValid())
					{
						if ((*m_PastTradesLearn).IsPositive(vec))
						{
							return false;
						}
						else
						{
							return true;
						}
					}
					else
					{
						if ((*m_PastTradesAnalyzer).DeterminePrediction(vec))
						{
							return false;
						}
						else
						{
							return true;
						}
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}

		bool CheckParamsVector()
		{
			if (CConfig::UseTrendFromLogs)
			{
				CVector vec;

				if ((*m_Params).FillVector(vec, (*m_PastTradesAnalyzer).BestInputsAmount()))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}

		bool AfterTrendReverseTrades()
		{
			if (CConfig::UseAfterTrend)
			{
				(*m_Params).WereAfterTradesSuccesfull();
			}
			return (*m_Params).AfterTrendReverseTrades;
		}

		bool IsRuleHit(bool &reverseTrades)
		{
			CRules::ReadVaribles();
			double speed;

			if ((*m_Params).GetSpeed(CConfig::LastHours, speed))
			{
				bool hit = CRules::HitsRule(speed, reverseTrades);

				CLogger::LogSpecial(IString("Hit : ") + IInteroperability::BoolToString(hit) + IString(", Speed = ") + IInteroperability::DoubleToString(speed) + IString(", ReverseTrades : ") + IInteroperability::BoolToString(reverseTrades));
				return hit;
			}
			else
			{
				return false;
			}
		}

		bool CheckDistance(bool Symbol, bool Buy, int SymbolNr, bool &MethodFReverseTrades)
		{
			if (CConfig::UseCalculateDistance)
			{
				if ((*m_DistancesProvider).IsValid())
				{
					MethodFReverseTrades = false;
					CLogger::LogSpecial(IString("Check Distance : ") + IInteroperability::BoolToString(false));
					return true;
				}
				else
				{
					MethodFReverseTrades = false;
					CLogger::LogSpecial(IString("Check Distance : Distance Provider Not Valid."));
					return false;
				}
			}
			else
			{
				return false;
			}
		}

    public:

		void AssignDistancesProvider(CDistancesProvider &dp)
		{
			m_DistancesProvider = &dp;
		}

        void ZeroSearchingProfit()
        {
            m_SearchingProfit = 0;        
        }
    
        void AssignMaximumMinimumLossProfit(double loss, double profit)
        {
            m_MaximumLoss = loss;
            m_MinimumProfit = profit;
        }
    
        void AssignNetworks(CLearning &buys, CLearning &sells)
        {
            m_LearningBuys = &buys;
            m_LearningSells = &sells;
        }

		void SetPastTradesAnalyzer(CPastTradesAnalyzer &analyzer, CLearning &learn)
		{
			m_PastTradesAnalyzer = &analyzer;
			m_PastTradesLearn = &learn;
		}

        bool Init(CCurrencyPairs &pairs, IDateTime &date, CParams &params)
        {
            m_WasMinimumMaximumInForBuy.Resize(0);
            m_WasMinimumMaximumInForSell.Resize(0);
            m_WasMinimumMaximumOtherInForBuy.Resize(0);
            m_WasMinimumMaximumOtherInForSell.Resize(0);
            m_AnalyzersForToBuy.Resize(0);
            m_AnalyzersForToSell.Resize(0);
            m_AnalyzersOtherForToBuy.Resize(0);
            m_AnalyzersOtherForToSell.Resize(0);
            m_ValuesAnalyzersForToBuy.Resize(0);
            m_ValuesAnalyzersForToSell.Resize(0);
            m_ValuesAnalyzersOtherForToBuy.Resize(0);
            m_ValuesAnalyzersOtherForToSell.Resize(0);
            
            m_WasMinimumMaximumInForBuy.Resize((*m_Pairs).AmountCurrencyPairsToBuy());
            m_WasMinimumMaximumInForSell.Resize((*m_Pairs).AmountCurrencyPairsToSell());
            m_WasMinimumMaximumOtherInForBuy.Resize((*m_Pairs).AmountOtherSymbolsToBuy());
            m_WasMinimumMaximumOtherInForSell.Resize((*m_Pairs).AmountOtherSymbolsToSell());
            m_AnalyzersForToBuy.Resize((*m_Pairs).AmountCurrencyPairsToBuy());
            m_AnalyzersForToSell.Resize((*m_Pairs).AmountCurrencyPairsToSell());
            m_AnalyzersOtherForToBuy.Resize((*m_Pairs).AmountOtherSymbolsToBuy());
            m_AnalyzersOtherForToSell.Resize((*m_Pairs).AmountOtherSymbolsToSell());
            m_ValuesAnalyzersForToBuy.Resize((*m_Pairs).AmountCurrencyPairsToBuy());
            m_ValuesAnalyzersForToSell.Resize((*m_Pairs).AmountCurrencyPairsToSell());
            m_ValuesAnalyzersOtherForToBuy.Resize((*m_Pairs).AmountOtherSymbolsToBuy());
            m_ValuesAnalyzersOtherForToSell.Resize((*m_Pairs).AmountOtherSymbolsToSell());
                          
            m_Params = &params;

            IInteroperability::RefreshRates();  
                      
            double val;
            bool was = false;
                        
            for(int i=0;i<pairs.AmountCurrencyPairsToBuy();i++)
            {
				IString pair(pairs.ReturnCurrencyPairToBuyNr(i));

                val = CValues::GetPriceAtTime(pair, date);
                if(val!=0.0)
                {
                    was = true;
                }
                (*(m_AnalyzersForToBuy.GetPointerToValue(i))).SetDefaultMinimumMaximum(val, val * CConfig::PercentageOfChange, date, 0);
            }
            for(int i=0;i<pairs.AmountCurrencyPairsToSell();i++)
            {
				IString pair(pairs.ReturnCurrencyPairToSellNr(i));

                val = CValues::GetPriceAtTime(pair, date);
                if(val!=0.0)
                {
                    was = true;
                }
                (*(m_AnalyzersForToSell.GetPointerToValue(i))).SetDefaultMinimumMaximum(val, val * CConfig::PercentageOfChange, date, 0);
            }
            for(int i=0;i<pairs.AmountOtherSymbolsToBuy();i++)
            {
				IString pair(pairs.ReturnOtherSymbolToBuyNr(i));

                val = CValues::GetPriceAtTime(pair, date);
                if(val!=0.0)
                {
                    was = true;
                }
                (*(m_AnalyzersOtherForToBuy.GetPointerToValue(i))).SetDefaultMinimumMaximum(val, val * CConfig::PercentageOfChange, date, 0);
            }
            for(int i=0;i<pairs.AmountOtherSymbolsToSell();i++)
            {
				IString pair(pairs.ReturnOtherSymbolToSellNr(i));

                val = CValues::GetPriceAtTime(pair, date);
                if(val!=0.0)
                {
                    was = true;
                }
                (*(m_AnalyzersOtherForToSell.GetPointerToValue(i))).SetDefaultMinimumMaximum(val, val * CConfig::PercentageOfChange, date, 0);
            }
            
            m_Pairs = &pairs;
            return was;
        }
    
		void AddToAnalysis(IDateTime &data, bool Symbol, bool Buy)
		{
			double val;
			double diffrence = 0.0;
			double valAfterSpread;
			CPastPoint point;

			for (int i = 0; i < (*m_Pairs).AmountSymbols(Symbol, Buy); i++)
			{
				IString pair((*m_Pairs).ReturnSymbol(i, Symbol, Buy));

				val = CValues::Price(pair, Buy);
				valAfterSpread = CValues::Price(pair, Buy);
				(*WasMinimumMaximum(Symbol, Buy)).SetValue(i, (*((*Analyzers(Symbol, Buy)).GetPointerToValue(i))).CheckForMinimumMaximum(val, data, 0));
				if ((*((*ValuesAnalyzers(Symbol, Buy)).GetPointerToValue(i))).CheckProfit(pair, valAfterSpread, diffrence, true))
				{
					m_SearchingProfit--;
					if (diffrence > 0.0)
					{
						(*m_Params).SuccessfullInRow++;
						(*m_Params).SuccessfullFinds++;
						if ((*m_Params).SuccessfullInRow >= CConfig::SuccededInRow)
						{
							(*m_Params).FailedInRow = 0;
							if (CConfig::UseSingleInRow)
							{
								(*(*m_Pairs).ReturnMultiTo(i, Symbol, Buy)).SetSuccedded(pair, true);
							}
							(*m_Params).StartedTrading = true;
						}
						CLogger::LogSpecial(IString("Searching Succeded. ") + pair + " Value : " + IInteroperability::DoubleToString(val));
						CLogger::LogSpecial(IString("SuccessfullInRow : ") + IInteroperability::DoubleToString((*m_Params).SuccessfullInRow) + ", FailedInRow : " + IInteroperability::DoubleToString((*m_Params).FailedInRow));
					}
					else
					{
						(*m_Params).FailedInRow++;
						(*m_Params).FailedFinds++;
						if ((*m_Params).FailedInRow >= CConfig::FailedInRow)
						{
							(*m_Params).SuccessfullInRow = 0;
							if (CConfig::UseSingleInRow)
							{
								(*(*m_Pairs).ReturnMultiTo(i, Symbol, Buy)).SetSuccedded(pair, false);
							}
							(*m_Params).StartedTrading = true;
						}
						CLogger::LogSpecial(IString("Searching Failed. ") + pair);
						CLogger::LogSpecial(IString("SuccessfullInRow : ") + IInteroperability::DoubleToString((*m_Params).SuccessfullInRow) + ", FailedInRow : " + IInteroperability::DoubleToString((*m_Params).FailedInRow));
					}
				}
				if ((*WasMinimumMaximum(Symbol, Buy)).GetValue(i) != CAnalyzer::NO_RESULT)
				{
					if ((*m_Pairs).TradablePeriod() && (*m_Pairs).IsSymbolPredictedProfitable(i, Symbol, Buy))
					{
						double diff = IInteroperability::MathAbs(val - (*WasMinimumMaximum(Symbol, Buy)).GetValue(i));
						IDateTime mmDate((*((*Analyzers(Symbol, Buy)).GetPointerToValue(i))).ReturnLastMinimumMaximumDate());

						if (ProceedWithOperation(Buy, pair, mmDate, data, (*m_Pairs).ReturnUpperLimit(val, diff, i, Symbol, Buy), (*m_Pairs).ReturnLowerLimit(val, diff, i, Symbol, Buy)))
						{
							if (CConfig::UseSellBuyNeuralNetworks)
							{
								CLogger::LogSpecial(IString("Network allowed for : ") + pair);
							}
							if (ProceedWithTrade(pair, i, Symbol, Buy, mmDate, data, (*m_Pairs).ReturnUpperLimit(val, diff, i, Symbol, Buy), (*m_Pairs).ReturnLowerLimit(val, diff, i, Symbol, Buy)))
							{
								if (CConfig::UseIndividualNeuralNetworks)
								{
									CLogger::LogSpecial(IString("Symbol Network allowed for : ") + pair);
								}
								if (CTrading::ProceedWithSearching((*m_Pairs), !Symbol, i, Buy, (*m_Pairs).ReturnUpperLimit(val, diff, i, Symbol, Buy), (*m_Pairs).ReturnLowerLimit(val, diff, i, Symbol, Buy)))
								{
									if (m_SearchingProfit < CConfig::SingleTradesAmount)
									{
										bool trendReverseTrades;

										trendReverseTrades = CheckTrendReverseTrades();
										AfterTrendReverseTrades();
										(*((*ValuesAnalyzers(Symbol, Buy)).GetPointerToValue(i))).SearchForProfit(pair, val, (*m_Pairs).ReturnUpperLimit(val, diff, i, Symbol, Buy), (*m_Pairs).ReturnLowerLimit(val, diff, i, Symbol, Buy), Buy, point, false, trendReverseTrades, (*m_Params).AfterTrendReverseTrades, (*m_Params).AutomaticParamsReverseTrades);
										CLogger::LogSpecial(IString("SearchForProfit upprLimit : ") + IInteroperability::DoubleToString((*m_Pairs).ReturnUpperLimit(val, diff, i, Symbol, Buy)) + ", lowerLimit : " + IInteroperability::DoubleToString((*m_Pairs).ReturnLowerLimit(val, diff, i, Symbol, Buy)));
										CLogger::LogSpecial(IString("Started Searching. ") + pair + ", Diff : " + IInteroperability::DoubleToString(diff));
										m_SearchingProfit++;

										bool methodCmethodDReverseTrades = false;

										if (trendReverseTrades && CConfig::UseTrendFromLogs)
										{
											methodCmethodDReverseTrades = !methodCmethodDReverseTrades;
										}
										if((*m_Params).AfterTrendReverseTrades && CConfig::UseAfterTrend)
										{
											methodCmethodDReverseTrades = !methodCmethodDReverseTrades;
										}
										if((*m_Params).AutomaticParamsReverseTrades && CConfig::UseAfterTrend && CConfig::UseAfterTrendAutomaticParams)
										{
											methodCmethodDReverseTrades = !methodCmethodDReverseTrades;
										}
										
										if (CConfig::ByPassInRowCheck || ((*m_Params).StartedTrading && (((!ReverseTrades((*(*m_Pairs).ReturnMultiTo(i, Symbol, Buy)).ReverseTrades)) && (*m_Params).SuccessfullInRow >= CConfig::SuccededInRow && (*m_Params).FailedInRow <= CConfig::FailedInRow) || ((ReverseTrades((*(*m_Pairs).ReturnMultiTo(i, Symbol, Buy)).ReverseTrades)) && (*m_Params).FailedInRow >= CConfig::SuccededInRow && (*m_Params).SuccessfullInRow <= CConfig::FailedInRow))))
										{
											if (CheckParamsVector())
											{
												bool MethodEReverseTrades = false;

												if (!CConfig::UseRules || (CConfig::UseRules && IsRuleHit(MethodEReverseTrades)))
												{
													bool methodFReverseTrades;
													bool checkDistance = CheckDistance(Symbol, Buy, i, methodFReverseTrades);

													if (!CConfig::UseCalculateDistance || (checkDistance && (CConfig::UseCalculateDistance && ((methodFReverseTrades && (MethodEReverseTrades || !CConfig::UseRules)) || (!methodFReverseTrades && (!MethodEReverseTrades || !CConfig::UseRules))))))
													{
														if ((!CConfig::UseRules && !CConfig::UseCalculateDistance) || (CConfig::UseRules && (methodCmethodDReverseTrades == MethodEReverseTrades)) || (CConfig::UseCalculateDistance && (methodCmethodDReverseTrades == methodFReverseTrades)))
														{
															CTrading::SendOrder(*m_Pairs, !Symbol, i, Buy, (*m_Pairs).ReturnUpperLimit(val, diff, i, Symbol, Buy), (*m_Pairs).ReturnLowerLimit(val, diff, i, Symbol, Buy), trendReverseTrades, (*m_Params).AfterTrendReverseTrades, (*m_Params).AutomaticParamsReverseTrades, MethodEReverseTrades || methodFReverseTrades);
														}
													}
												}
											}
											else
											{
												CLogger::LogSpecial(IString("Params Vector not filled, bypassing Trade : ") + pair);
											}
										}
										else
										{
											CLogger::LogSpecial(IString("Order Filtered Out. ") + pair);
										}
									}
									else
									{
										CLogger::LogSpecial(IString("Searching Filtered Out. ") + pair);
									}
								}
								else
								{
									CLogger::LogSpecial(IString("Ignoring Searching for : ") + pair);
								}
							}
							else
							{
								if (CConfig::UseIndividualNeuralNetworks)
								{
									CLogger::LogSpecial(IString("Symbol Network disallowed for : ") + pair);
								}
							}
						}
						else
						{
							if (CConfig::UseSellBuyNeuralNetworks)
							{
								CLogger::LogSpecial(IString("Network disallowed for : ") + pair);
							}
						}
					}
				}
			}
		}

        void AddToAnalysis(IDateTime &data)
        {
            SetWasMMtoFalse();
			AddToAnalysis(data, true, true);
			AddToAnalysis(data, true, false);
			AddToAnalysis(data, false, true);
			AddToAnalysis(data, false, false);
        }   
};
//+------------------------------------------------------------------+
#endif
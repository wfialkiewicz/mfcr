/*Copyright 2022 Inconsoft Inc.777

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_PAST_TRADES_ANALYZER
#define FILE_PAST_TRADES_ANALYZER

#include "Logs.h"

//+------------------------------------------------------------------+
class CArgs
{
    public:
		double borderValue;
		double increaseFirst;
		double increaseLast;
		double percent;
		int inputsAmount;

		CArgs()
		{

		}

		CArgs(const CArgs &other)
		{
			borderValue = other.borderValue;
			increaseFirst = other.increaseFirst;
			increaseLast = other.increaseLast;
			percent = other.percent;
			inputsAmount = other.inputsAmount;
		}
};

class CPastTradesAnalyzer{
    private:
		IGenericArray<double> m_MultiplicationValues;
		IGenericArray<double> m_VectorsValues;
		ISortableArray<double> m_SortValues;
		ISortableArray<double> m_SortCorrectPercentage;
		IGenericObjectArray<CArgs> m_Args;
		ISortableArray<double> m_SortArgsPercentages;
		ISortableArray<double> m_SortArgsPastTradesMinMax;
		IGenericObjectArray<CArgs> m_ArgsPastTradesMinMax;
     	CArgs m_ArgsBest;
		bool m_Valid;

		double MultiplicationValue(int am, int nr, double incFirst, double incLast)
		{
			return (incLast - incFirst) / ((double)(am - 1)) * nr + incFirst;
		}

		void CalculateMultiplications(int am, double incFirst, double incLast)
		{
			for (int i = 0; i < am; i++)
			{
				m_MultiplicationValues.SetValue(i, MultiplicationValue(am, i, incFirst, incLast));
			}
		}
		
		double CalculateVectorValue(CVector &vec)
		{
			double res = 0.0;

			for (int i = 0; i < vec.Input.Size(); i++)
			{
				res += vec.Input.GetValue(i) * m_MultiplicationValues.GetValue(i);
			}
			return res;
		}

		double PercentCorrectForValue(double val, CVectors &vectors)
		{
			double correct = 0;

			for (int i = 0; i < vectors.Vectors.Size(); i++)
			{
				if (m_VectorsValues.GetValue(i) >= val && (*(vectors.Vectors.GetPointerToValue(i))).Output.GetValue(0) == CVector::BTRUE)
				{
					correct++;
				}
				else if (m_VectorsValues.GetValue(i) < val && (*(vectors.Vectors.GetPointerToValue(i))).Output.GetValue(0) == CVector::BFALSE)
				{
					correct++;
				}
			}
			return correct / vectors.Vectors.Size();
		}
			   
    public:
		CPastTradesAnalyzer()
		{
			m_Valid = false;
		}

		void Analyze(CLogs &logs)
		{
			double increaseFirst, increaseLast;
			double val;
			double min, max, maxPercent;
			double borderValue;
			CArgs args;

			m_SortArgsPastTradesMinMax.Resize(CConfig::PastTradeMaxAmount - CConfig::PastTradeMinAmount + 1);
			m_ArgsPastTradesMinMax.Resize(CConfig::PastTradeMaxAmount - CConfig::PastTradeMinAmount + 1);
			for (int i = CConfig::PastTradeMinAmount; i <= CConfig::PastTradeMaxAmount; i++)
			{
				CLogger::LogSpecial(IString("Trend Detect for Past Trades Amount : ") + IInteroperability::IntegerToString(i));
				logs.AssignVectors(i);
				logs.LimitVectorsAmount();
			    m_VectorsValues.Resize((*(logs.ReturnVectors())).Vectors.Size());
			    m_SortValues.Resize((*(logs.ReturnVectors())).Vectors.Size());
				m_MultiplicationValues.Resize(i);
				m_Args.Resize(CConfig::PastTradeLineMultiplyStepsAmount * CConfig::PastTradeLineMultiplyStepsAmount);
				for (int j = 0; j < CConfig::PastTradeLineMultiplyStepsAmount; j++)
				{
					increaseFirst = CConfig::PastTradeLineMultiplyMin + ((CConfig::PastTradeLineMultiplyMax - CConfig::PastTradeLineMultiplyMin) / (double)(CConfig::PastTradeLineMultiplyStepsAmount)) * j;
					for (int jj = 0; jj < CConfig::PastTradeLineMultiplyStepsAmount; jj++)
					{
						increaseLast = CConfig::PastTradeLineMultiplyMin + ((CConfig::PastTradeLineMultiplyMax - CConfig::PastTradeLineMultiplyMin) / (double)(CConfig::PastTradeLineMultiplyStepsAmount)) * jj;
						CalculateMultiplications(i, increaseFirst, increaseLast);
						for (int k = 0; k < (*(logs.ReturnVectors())).Vectors.Size(); k++)
						{
							val = CalculateVectorValue((*((*(logs.ReturnVectors())).Vectors.GetPointerToValue(k))));
							m_VectorsValues.SetValue(k, val);
							m_SortValues.SetPos(k, k);
							m_SortValues.SetValue(k, val);
						}
						if (m_SortValues.Size() > 0)
						{
							m_SortValues.Sort();
							min = m_SortValues.GetValue(0);
							max = m_SortValues.GetValue(m_SortValues.Size() - 1);
						}
						else
						{
							min = 0.0;
							max = 0.0;
						}
						m_SortCorrectPercentage.Resize(CConfig::PastTradeLineMultiplyStepsAmount);
						for (int k = 0; k < CConfig::PastTradeLineMultiplyStepsAmount; k++)
						{
							borderValue = min + ((max - min) / CConfig::PastTradeLineMultiplyStepsAmount) * k;
							val = PercentCorrectForValue(borderValue, *(logs.ReturnVectors()));
							m_SortCorrectPercentage.SetPos(k, k);
							m_SortCorrectPercentage.SetValue(k, val);
						}
						m_SortCorrectPercentage.Sort();
						maxPercent = m_SortCorrectPercentage.GetValue(m_SortCorrectPercentage.Size() - 1);
						args.borderValue = min + ((max - min) / CConfig::PastTradeLineMultiplyStepsAmount) * m_SortCorrectPercentage.GetPos(m_SortCorrectPercentage.Size() - 1);
						args.increaseFirst = increaseFirst;
						args.increaseLast = increaseLast;
						args.percent = maxPercent;
						(*(m_Args.GetPointerToValue(j * CConfig::PastTradeLineMultiplyStepsAmount + jj))) = args;
					}
				}
				m_SortArgsPercentages.Resize(CConfig::PastTradeLineMultiplyStepsAmount * CConfig::PastTradeLineMultiplyStepsAmount);
				for (int j = 0; j < CConfig::PastTradeLineMultiplyStepsAmount; j++)
				{
					for (int jj = 0; jj < CConfig::PastTradeLineMultiplyStepsAmount; jj++)
					{
						m_SortArgsPercentages.SetPos(j * CConfig::PastTradeLineMultiplyStepsAmount + jj, j);
						m_SortArgsPercentages.SetValue(j * CConfig::PastTradeLineMultiplyStepsAmount + jj, (*(m_Args.GetPointerToValue(j * CConfig::PastTradeLineMultiplyStepsAmount + jj))).percent);
					}
				}
				m_SortArgsPercentages.Sort();
				args = (*(m_Args.GetPointerToValue(m_SortArgsPercentages.GetPos(m_SortArgsPercentages.Size() - 1))));
				CLogger::LogSpecial(IString("Increase First : ") + IInteroperability::DoubleToString(args.increaseFirst) + IString(", Increase Last : ") + IInteroperability::DoubleToString(args.increaseLast) + IString(", Border Value : ") + IInteroperability::DoubleToString(args.borderValue) + IString(", Percent : ") + IInteroperability::DoubleToString(args.percent));
				args.inputsAmount = i;
				(*(m_ArgsPastTradesMinMax.GetPointerToValue(i - CConfig::PastTradeMinAmount))) = args;
				m_SortArgsPastTradesMinMax.SetPos(i - CConfig::PastTradeMinAmount, i - CConfig::PastTradeMinAmount);
				m_SortArgsPastTradesMinMax.SetValue(i - CConfig::PastTradeMinAmount, args.percent);
			}
			m_SortArgsPastTradesMinMax.Sort();
			args = (*(m_ArgsPastTradesMinMax.GetPointerToValue(m_SortArgsPastTradesMinMax.GetPos(m_SortArgsPastTradesMinMax.Size() - 1))));
			CLogger::LogSpecial(IString("Inputs Choosen :") + IInteroperability::IntegerToString(args.inputsAmount) + IString(", Increase First : ") + IInteroperability::DoubleToString(args.increaseFirst) + IString(", Increase Last : ") + IInteroperability::DoubleToString(args.increaseLast)  + IString(", Border Value : ") + IInteroperability::DoubleToString(args.borderValue) + IString(", Percent : ") + IInteroperability::DoubleToString(args.percent));
		    m_ArgsBest = args;
		}

		void CleanUpAndSetMultiplicationValues()
		{
			m_VectorsValues.Resize(0);
			m_SortArgsPastTradesMinMax.Resize(0);
			m_SortArgsPercentages.Resize(0);
			m_SortCorrectPercentage.Resize(0);
			m_SortValues.Resize(0);
			m_Args.Resize(0);
			m_ArgsPastTradesMinMax.Resize(0);

			m_MultiplicationValues.Resize(m_ArgsBest.inputsAmount);
			CalculateMultiplications(m_ArgsBest.inputsAmount, m_ArgsBest.increaseFirst, m_ArgsBest.increaseLast);
			m_Valid = true;
		}

		bool DeterminePrediction(CVector &vec)
		{
			double res = CalculateVectorValue(vec);

			CLogger::HeavyLog(IString("DeterminePrediction res : ") + IInteroperability::DoubleToString(res) + IString("borderValue : ") + IInteroperability::DoubleToString(m_ArgsBest.borderValue));
			if (res >= m_ArgsBest.borderValue)
			{
				CLogger::HeavyLog(IString("DeterminePrediction returning : true"));
				return true;
			}
			else
			{
				CLogger::HeavyLog(IString("DeterminePrediction returning : fslse"));
				return false;
			}
		}

		int BestInputsAmount()
		{
			return m_ArgsBest.inputsAmount;
		}

		bool IsValid()
		{
			return m_Valid;
		}
};
//+------------------------------------------------------------------+
#endif
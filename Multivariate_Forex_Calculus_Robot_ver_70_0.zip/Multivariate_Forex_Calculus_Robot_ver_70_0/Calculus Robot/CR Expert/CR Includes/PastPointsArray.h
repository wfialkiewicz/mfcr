/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_PAST_POINTS_ARRAY
#define FILE_PAST_POINTS_ARRAY

#include "PastPoint.h"
#include "Logger.h"
#include "../../Interoperability/GenericObjectArray.h"

//+------------------------------------------------------------------+
class CPastPointsArray{
    private:
        IGenericObjectArray<CPastPoint> m_Points;
        int m_PointsAmount;
        const static int ARRAY_SIZE;
        
    public:
        CPastPointsArray()
        {
            Reset();
        }
        
        void Reset()
        {
            m_Points.Resize(ARRAY_SIZE);
            m_PointsAmount = 0;
        }
        
        void ReturnPoints(IGenericObjectArray<CPastPoint> &points)
        {
            points.Resize(m_PointsAmount);
        }         
        
        void AddPoint(CPastPoint &point)
        {
            if(m_PointsAmount < ARRAY_SIZE - 1)
            {
                (*(m_Points.GetPointerToValue(m_PointsAmount))) = point;
                m_PointsAmount++;
            }
            else
            {
                CLogger::Log(IString("Error, to many points."));
            }
        }
        
        void FillArrays(IGenericObjectArray<CPastPoint> &buys, IGenericObjectArray<CPastPoint> &sells)
        {
            int buysAm = 0;
            
            for(int i=0;i<m_PointsAmount;i++)
            {
                if((*(m_Points.GetPointerToValue(i))).SymbolBuy)
                {
                    buysAm++;
                }
            }
            buys.Resize(buysAm);
            sells.Resize(m_PointsAmount - buysAm);
            
            int buyNr = 0;
            int sellNr = 0;
            
            for(int i=0;i<m_PointsAmount;i++)
            {
                if((*(m_Points.GetPointerToValue(i))).SymbolBuy)
                {
                    buys.SetValue(buyNr, (*(m_Points.GetPointerToValue(i))));
                    buyNr++;
                }
                else
                {
                    sells.SetValue(sellNr, (*(m_Points.GetPointerToValue(i))));
                    sellNr++;
                }
            }
        }
};
const int CPastPointsArray::ARRAY_SIZE = 1000000;
//+------------------------------------------------------------------+
#endif
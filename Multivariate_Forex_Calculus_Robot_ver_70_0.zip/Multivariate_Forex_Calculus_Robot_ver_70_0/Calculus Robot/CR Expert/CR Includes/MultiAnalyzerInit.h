/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_MULTI_ANALYZER_INIT
#define FILE_MULTI_ANALYZER_INIT

#include "MultiAnalyzerBase.h"
#include "../../Interoperability/GenericObjectArray.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/DateTime.h"

//+------------------------------------------------------------------+
class CMultiAnalyzerInit : public CMultiAnalyzerBase {
private:
	void AddToAnalysis(int dataNr, bool Symbol, bool Buy)
	{
		double val;
		double difference = 0.0;

		for (int i = 0; i < (*m_Pairs).AmountSymbols(Symbol, Buy); i++)
		{
			IDateTime time((*values).ReturnDateTimeOfPastNr(dataNr));
			IString pair((*m_Pairs).ReturnSymbol(i, Symbol, Buy));

			val = (*values).ReturnPastValueNrToBuy(dataNr, i);
			(*WasMinimumMaximum(Symbol, Buy)).SetValue(i, (*((*Analyzers(Symbol, Buy)).GetPointerToValue(i))).CheckForMinimumMaximum(val, time, dataNr));
			if ((*((*ValuesAnalyzers(Symbol, Buy)).GetPointerToValue(i))).CheckProfit(pair, val, difference, false))
			{
				CPastPoint point = (*((*ValuesAnalyzers(Symbol, Buy)).GetPointerToValue(i))).ReturnPoint();

				m_PastPoints.AddPoint(point);
			}
			if ((*WasMinimumMaximum(Symbol, Buy)).GetValue(i) != CAnalyzer::NO_RESULT)
			{
				double diff = IInteroperability::MathAbs(val - (*WasMinimumMaximum(Symbol, Buy)).GetValue(i));
				CPastPoint point;

				point.SymbolNr = i;
				point.Symbol = Symbol;
				point.SymbolBuy = Buy;
				point.MinimumMaximumPointNr = (*((*Analyzers(Symbol, Buy)).GetPointerToValue(i))).ReturnLastMinimumMaximumDataNr();
				point.EstablishingMinimumMaximumPointNr = dataNr;
				point.Val = val;
				point.Diff = diff;
				point.ValDate = (*values).ReturnDateTimeOfPastNr(dataNr);

				(*((*ValuesAnalyzers(Symbol, Buy)).GetPointerToValue(i))).SearchForProfit(pair, val, (*m_Pairs).ReturnUpperLimit(val, diff, i, Symbol, Buy), (*m_Pairs).ReturnLowerLimit(val, diff, i, Symbol, Buy), Buy, point);
			}
		}
	}

	void AddToAnalysis(int dataNr)
	{
		SetWasMMtoFalse();
		AddToAnalysis(dataNr, true, true);
		AddToAnalysis(dataNr, true, false);
		AddToAnalysis(dataNr, false, true);
		AddToAnalysis(dataNr, false, false);
	}

	double ProfitAnalyzedHistory(IString &msg)
	{
		CCurrencyPair pair;
		double profit = 0.0;

		for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToBuy(); i++)
		{
			IDateTime time(IDateTime::TimeCurrent());
			IString _pair((*m_Pairs).ReturnCurrencyPairToBuyNr(i));

			pair.Profit = (*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).Profit();
			pair.Symbol = (*m_Pairs).ReturnCurrencyPairToBuyNr(i);
			pair.CalculateProportionalProfit(time);
			profit += pair.ProportionalProfit;
			msg += ", ";
			msg += (*m_Pairs).ReturnCurrencyPairToBuyNr(i);
			msg += ":";
			msg += IInteroperability::DoubleToString((*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).Profit());
			msg += ", PMS : ";
			msg += IInteroperability::DoubleToString((*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).ProfitMinusSpread(_pair));
			msg += ", SLM:";
			msg += IInteroperability::DoubleToString((*(*m_Pairs).ReturnMultiTo(i, true, true)).StopLossMulti);
			msg += ", TPM:";
			msg += IInteroperability::DoubleToString((*(*m_Pairs).ReturnMultiTo(i, true, true)).PossibleProfitMulti);
			msg += ", GC : ";
			msg += IInteroperability::IntegerToString((*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).GainCount());
			msg += ", LC : ";
			msg += IInteroperability::IntegerToString((*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).LossCount());
		}
		for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToSell(); i++)
		{
			IDateTime time(IDateTime::TimeCurrent());
			IString _pair((*m_Pairs).ReturnCurrencyPairToSellNr(i));

			pair.Profit = (*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).Profit();
			pair.Symbol = (*m_Pairs).ReturnCurrencyPairToSellNr(i);
			pair.CalculateProportionalProfit(time);
			profit += pair.ProportionalProfit;
			msg += ", ";
			msg += (*m_Pairs).ReturnCurrencyPairToSellNr(i);
			msg += ":";
			msg += IInteroperability::DoubleToString((*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).Profit());
			msg += ", PMS : ";
			msg += IInteroperability::DoubleToString((*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).ProfitMinusSpread(_pair));
			msg += ", SLM:";
			msg += IInteroperability::DoubleToString((*(*m_Pairs).ReturnMultiTo(i, true, false)).StopLossMulti);
			msg += ", TPM:";
			msg += IInteroperability::DoubleToString((*(*m_Pairs).ReturnMultiTo(i, true, false)).PossibleProfitMulti);
			msg += ", GC : ";
			msg += IInteroperability::IntegerToString((*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).GainCount());
			msg += ", LC : ";
			msg += IInteroperability::IntegerToString((*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).LossCount());
		}
		for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToBuy(); i++)
		{
			IDateTime time(IDateTime::TimeCurrent());
			IString _pair((*m_Pairs).ReturnOtherSymbolToBuyNr(i));

			pair.Profit = (*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).Profit();
			pair.Symbol = (*m_Pairs).ReturnOtherSymbolToBuyNr(i);
			pair.CalculateProportionalProfit(time);
			profit += pair.ProportionalProfit;
			msg += ", ";
			msg += (*m_Pairs).ReturnOtherSymbolToBuyNr(i);
			msg += ":";
			msg += IInteroperability::DoubleToString((*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).Profit());
			msg += ", PMS : ";
			msg += IInteroperability::DoubleToString((*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).ProfitMinusSpread(_pair));
			msg += ", SLM:";
			msg += IInteroperability::DoubleToString((*(*m_Pairs).ReturnMultiTo(i, false, true)).StopLossMulti);
			msg += ", TPM:";
			msg += IInteroperability::DoubleToString((*(*m_Pairs).ReturnMultiTo(i, false, true)).PossibleProfitMulti);
			msg += ", GC : ";
			msg += IInteroperability::IntegerToString((*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).GainCount());
			msg += ", LC : ";
			msg += IInteroperability::IntegerToString((*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).LossCount());
		}
		for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToSell(); i++)
		{
			IDateTime time(IDateTime::TimeCurrent());
			IString _pair((*m_Pairs).ReturnOtherSymbolToSellNr(i));

			pair.Profit = (*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).Profit();
			pair.Symbol = (*m_Pairs).ReturnOtherSymbolToSellNr(i);
			pair.CalculateProportionalProfit(time);
			profit += pair.ProportionalProfit;
			msg += ", ";
			msg += (*m_Pairs).ReturnOtherSymbolToSellNr(i);
			msg += ":";
			msg += IInteroperability::DoubleToString((*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).Profit());
			msg += ", PMS : ";
			msg += IInteroperability::DoubleToString((*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).ProfitMinusSpread(_pair));
			msg += ", SLM:";
			msg += IInteroperability::DoubleToString((*(*m_Pairs).ReturnMultiTo(i, false, false)).StopLossMulti);
			msg += ", TPM:";
			msg += IInteroperability::DoubleToString((*(*m_Pairs).ReturnMultiTo(i, false, false)).PossibleProfitMulti);
			msg += ", GC : ";
			msg += IInteroperability::IntegerToString((*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).GainCount());
			msg += ", LC : ";
			msg += IInteroperability::IntegerToString((*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).LossCount());
		}

		return profit;
	}

	void LogMinimasMaximas()
	{
		for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToBuy(); i++)
		{
			IString pair((*m_Pairs).ReturnCurrencyPairToBuyNr(i));

			(*(m_AnalyzersForToBuy.GetPointerToValue(i))).LogCount(pair);
		}
		for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToSell(); i++)
		{
			IString pair((*m_Pairs).ReturnCurrencyPairToSellNr(i));

			(*(m_AnalyzersForToSell.GetPointerToValue(i))).LogCount(pair);
		}
		for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToBuy(); i++)
		{
			IString pair((*m_Pairs).ReturnOtherSymbolToBuyNr(i));

			(*(m_AnalyzersOtherForToBuy.GetPointerToValue(i))).LogCount(pair);
		}
		for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToSell(); i++)
		{
			IString pair((*m_Pairs).ReturnOtherSymbolToSellNr(i));

			(*(m_AnalyzersOtherForToSell.GetPointerToValue(i))).LogCount(pair);
		}
	}

	void CountSuccessfullAndTradable(IGenericObjectArray<CPastPoint> &points, int &successfull, int &failed)
	{
		successfull = 0;
		failed = 0;

		for (int i = 0; i < points.Size(); i++)
		{
			if ((*m_Pairs).IsLearnable((*(points.GetPointerToValue(i))).SymbolNr, (*(points.GetPointerToValue(i))).Symbol, (*(points.GetPointerToValue(i))).SymbolBuy))
			{
				if ((*(points.GetPointerToValue(i))).Successful)
				{
					successfull++;
				}
				else
				{
					failed++;
				}
			}
		}
	}

	void SavePastPoints(IGenericObjectArray<CPastPoint> &points, IGenericObjectArray<CPastPoint> &saved, int amount)
	{
		int pos = 0;

		saved.Resize(amount);
		for (int i = 0; i < points.Size(); i++)
		{
			if ((*m_Pairs).IsLearnable((*(points.GetPointerToValue(i))).SymbolNr, (*(points.GetPointerToValue(i))).Symbol, (*(points.GetPointerToValue(i))).SymbolBuy))
			{
				saved.SetValue(pos, (*(points.GetPointerToValue(i))));
				pos++;
			}
		}
	}

	void LogAndSavePastPoints()
	{
		IGenericObjectArray<CPastPoint> buys;
		IGenericObjectArray<CPastPoint> sells;

		m_PastPoints.FillArrays(buys, sells);

		int successfullBuys;
		int successfullSells;
		int failedBuys;
		int failedSells;

		CountSuccessfullAndTradable(buys, successfullBuys, failedBuys);
		CountSuccessfullAndTradable(sells, successfullSells, failedSells);

		SavePastPoints(buys, PastPointsBuys, successfullBuys + failedBuys);
		SavePastPoints(sells, PastPointsSells, successfullSells + failedSells);

		CLogger::LogSpecial(IString("Buy Past Examples Amount : ") + IInteroperability::IntegerToString(successfullBuys + failedBuys) + ", Successfull : " + IInteroperability::IntegerToString(successfullBuys) + ", Failed : " + IInteroperability::IntegerToString(failedBuys));
		CLogger::LogSpecial(IString("Sell Past Examples Amount : ") + IInteroperability::IntegerToString(successfullSells + failedSells) + ", Successfull : " + IInteroperability::IntegerToString(successfullSells) + ", Failed : " + IInteroperability::IntegerToString(failedSells));
		(*m_Pairs).LogTradableOfLearnable();
	}

public:
	IGenericObjectArray<CPastPoint> PastPointsBuys;
	IGenericObjectArray<CPastPoint> PastPointsSells;

	void CheckHistory()
	{
		double amountStop = (CConfig::StopLossMultiMax - CConfig::StopLossMultiMin) / (CConfig::CheckMultiStep);
		double amount = 0.0;

		for (double stopLoss = CConfig::StopLossMultiMin; stopLoss <= CConfig::StopLossMultiMax; stopLoss += CConfig::CheckMultiStep)
		{
			amount += 1.0;
			for (double takeProfit = CConfig::PossibleProfitMultiMin; takeProfit <= CConfig::PossibleProfitMultiMax; takeProfit += CConfig::CheckMultiStep)
			{
				if (CConfig::MakeStopLossEqualTakeProfit)
				{
					if (takeProfit != stopLoss)
					{
						continue;
					}
				}

				for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToBuy(); i++)
				{
					(*(*m_Pairs).ReturnMultiTo(i, true, true)).StopLossMulti = stopLoss;
					(*(*m_Pairs).ReturnMultiTo(i, true, true)).PossibleProfitMulti = takeProfit;
				}
				for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToSell(); i++)
				{
					(*(*m_Pairs).ReturnMultiTo(i, true, false)).StopLossMulti = stopLoss;
					(*(*m_Pairs).ReturnMultiTo(i, true, false)).PossibleProfitMulti = takeProfit;
				}
				for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToBuy(); i++)
				{
					(*(*m_Pairs).ReturnMultiTo(i, false, true)).StopLossMulti = stopLoss;
					(*(*m_Pairs).ReturnMultiTo(i, false, true)).PossibleProfitMulti = takeProfit;
				}
				for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToSell(); i++)
				{
					(*(*m_Pairs).ReturnMultiTo(i, false, false)).StopLossMulti = stopLoss;
					(*(*m_Pairs).ReturnMultiTo(i, false, false)).PossibleProfitMulti = takeProfit;
				}

				double multi;

				if (CConfig::UseMaxMultiTakeProfitStopLoss)
				{
					if (stopLoss >= takeProfit)
					{
						multi = 1.0 / (1.0 + stopLoss - takeProfit);
					}
					else
					{
						multi = 1.0 + takeProfit - stopLoss;
					}
				}
				else
				{
					multi = 1.0;
				}

				AnalyzeHistory();
				for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToBuy(); i++)
				{
					double prof = (*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).ProfitGains() * multi;
					IString pair((*m_Pairs).ReturnCurrencyPairToBuyNr(i));

					if ((*(*m_Pairs).ReturnMultiTo(i, true, true)).BiggestValue < prof && takeProfit * CConfig::TakeProfitPercentForStopLoss >= stopLoss && (*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).ProfitMinusSpread(pair) > CConfig::MinPMSValue)
					{
						(*(*m_Pairs).ReturnMultiTo(i, true, true)).ProfitMinusSpread = (*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).ProfitMinusSpread(pair);
						(*(*m_Pairs).ReturnMultiTo(i, true, true)).BiggestValue = prof;
						(*(*m_Pairs).ReturnMultiTo(i, true, true)).StopLossMultiForBiggestValue = stopLoss;
						(*(*m_Pairs).ReturnMultiTo(i, true, true)).PossibleProfitMultiForBiggestValue = takeProfit;
					}
				}
				for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToSell(); i++)
				{
					double prof = (*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).ProfitGains() * multi;
					IString pair((*m_Pairs).ReturnCurrencyPairToSellNr(i));

					if ((*(*m_Pairs).ReturnMultiTo(i, true, false)).BiggestValue < prof && takeProfit * CConfig::TakeProfitPercentForStopLoss >= stopLoss && (*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).ProfitMinusSpread(pair) > CConfig::MinPMSValue)
					{
						(*(*m_Pairs).ReturnMultiTo(i, true, false)).ProfitMinusSpread = (*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).ProfitMinusSpread(pair);
						(*(*m_Pairs).ReturnMultiTo(i, true, false)).BiggestValue = prof;
						(*(*m_Pairs).ReturnMultiTo(i, true, false)).StopLossMultiForBiggestValue = stopLoss;
						(*(*m_Pairs).ReturnMultiTo(i, true, false)).PossibleProfitMultiForBiggestValue = takeProfit;
					}
				}
				for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToBuy(); i++)
				{
					double prof = (*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).ProfitGains() * multi;
					IString pair((*m_Pairs).ReturnOtherSymbolToBuyNr(i));

					if ((*(*m_Pairs).ReturnMultiTo(i, false, true)).BiggestValue < prof && takeProfit * CConfig::TakeProfitPercentForStopLoss >= stopLoss && (*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).ProfitMinusSpread(pair) > CConfig::MinPMSValue)
					{
						(*(*m_Pairs).ReturnMultiTo(i, false, true)).ProfitMinusSpread = (*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).ProfitMinusSpread(pair);
						(*(*m_Pairs).ReturnMultiTo(i, false, true)).BiggestValue = prof;
						(*(*m_Pairs).ReturnMultiTo(i, false, true)).StopLossMultiForBiggestValue = stopLoss;
						(*(*m_Pairs).ReturnMultiTo(i, false, true)).PossibleProfitMultiForBiggestValue = takeProfit;
					}
				}
				for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToSell(); i++)
				{
					double prof = (*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).ProfitGains() * multi;
					IString pair((*m_Pairs).ReturnOtherSymbolToSellNr(i));

					if ((*(*m_Pairs).ReturnMultiTo(i, false, false)).BiggestValue < prof && takeProfit * CConfig::TakeProfitPercentForStopLoss >= stopLoss && (*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).ProfitMinusSpread(pair) > CConfig::MinPMSValue)
					{
						(*(*m_Pairs).ReturnMultiTo(i, false, false)).ProfitMinusSpread = (*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).ProfitMinusSpread(pair);
						(*(*m_Pairs).ReturnMultiTo(i, false, false)).BiggestValue = prof;
						(*(*m_Pairs).ReturnMultiTo(i, false, false)).StopLossMultiForBiggestValue = stopLoss;
						(*(*m_Pairs).ReturnMultiTo(i, false, false)).PossibleProfitMultiForBiggestValue = takeProfit;
					}
				}
				LogAnalyzedHistory();
			}
			CLogger::Log(IString("Multi Progress : ") + IInteroperability::DoubleToString(amount / amountStop));
		}

		for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToBuy(); i++)
		{
			(*(*m_Pairs).ReturnMultiTo(i, true, true)).SetToBiggest();
		}
		for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToSell(); i++)
		{
			(*(*m_Pairs).ReturnMultiTo(i, true, false)).SetToBiggest();
		}
		for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToBuy(); i++)
		{
			(*(*m_Pairs).ReturnMultiTo(i, false, true)).SetToBiggest();
		}
		for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToSell(); i++)
		{
			(*(*m_Pairs).ReturnMultiTo(i, false, false)).SetToBiggest();
		}

		AnalyzeHistory();

		for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToBuy(); i++)
		{
			IString pair((*m_Pairs).ReturnCurrencyPairToBuyNr(i));

			(*(*m_Pairs).ReturnMultiTo(i, true, true)).GainProfitsAmount = (*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).GainCount();
			(*(*m_Pairs).ReturnMultiTo(i, true, true)).LooseProfitsAmount = (*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).LossCount();
			(*(*m_Pairs).ReturnMultiTo(i, true, true)).ProfitMinusSpread = (*(m_ValuesAnalyzersForToBuy.GetPointerToValue(i))).ProfitMinusSpread(pair);
		}
		for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToSell(); i++)
		{
			IString pair((*m_Pairs).ReturnCurrencyPairToSellNr(i));

			(*(*m_Pairs).ReturnMultiTo(i, true, false)).GainProfitsAmount = (*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).GainCount();
			(*(*m_Pairs).ReturnMultiTo(i, true, false)).LooseProfitsAmount = (*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).LossCount();
			(*(*m_Pairs).ReturnMultiTo(i, true, false)).ProfitMinusSpread = (*(m_ValuesAnalyzersForToSell.GetPointerToValue(i))).ProfitMinusSpread(pair);
		}
		for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToBuy(); i++)
		{
			IString pair((*m_Pairs).ReturnOtherSymbolToBuyNr(i));

			(*(*m_Pairs).ReturnMultiTo(i, false, true)).GainProfitsAmount = (*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).GainCount();
			(*(*m_Pairs).ReturnMultiTo(i, false, true)).LooseProfitsAmount = (*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).LossCount();
			(*(*m_Pairs).ReturnMultiTo(i, false, true)).ProfitMinusSpread = (*(m_ValuesAnalyzersOtherForToBuy.GetPointerToValue(i))).ProfitMinusSpread(pair);
		}
		for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToSell(); i++)
		{
			IString pair((*m_Pairs).ReturnOtherSymbolToSellNr(i));

			(*(*m_Pairs).ReturnMultiTo(i, false, false)).GainProfitsAmount = (*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).GainCount();
			(*(*m_Pairs).ReturnMultiTo(i, false, false)).LooseProfitsAmount = (*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).LossCount();
			(*(*m_Pairs).ReturnMultiTo(i, false, false)).ProfitMinusSpread = (*(m_ValuesAnalyzersOtherForToSell.GetPointerToValue(i))).ProfitMinusSpread(pair);
		}
		LogSpecialAnalyzedHistory();
		LogMinimasMaximas();
		(*m_Pairs).DetermineTradable();
		LogAndSavePastPoints();
	}

	void AnalyzeHistory()
	{
		Init((*values).PastValuesStartNr());
		for (int i = (*values).PastValuesStartNr(); i < (*values).PastValuesAmount(); i++)
		{
			AddToAnalysis(i);
		}
		for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToBuy(); i++)
		{
			IString pair((*m_Pairs).ReturnCurrencyPairToBuyNr(i));

			(*(m_AnalyzersForToBuy.GetPointerToValue(i))).LogCount(pair);
		}
		for (int i = 0; i < (*m_Pairs).AmountCurrencyPairsToSell(); i++)
		{
			IString pair((*m_Pairs).ReturnCurrencyPairToSellNr(i));

			(*(m_AnalyzersForToSell.GetPointerToValue(i))).LogCount(pair);
		}
		for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToBuy(); i++)
		{
			IString pair((*m_Pairs).ReturnOtherSymbolToBuyNr(i));

			(*(m_AnalyzersOtherForToBuy.GetPointerToValue(i))).LogCount(pair);
		}
		for (int i = 0; i < (*m_Pairs).AmountOtherSymbolsToSell(); i++)
		{
			IString pair((*m_Pairs).ReturnOtherSymbolToSellNr(i));

			(*(m_AnalyzersOtherForToSell.GetPointerToValue(i))).LogCount(pair);
		}
	}

	double LogAnalyzedHistory()
	{
		IString msg;
		double profit = ProfitAnalyzedHistory(msg);

		CLogger::HeavyLog(msg);
		CLogger::HeavyLog(IString("Proportional Profit : ") + IInteroperability::DoubleToString(profit));

		return profit;
	}

	double LogSpecialAnalyzedHistory()
	{
		IString msg;
		double profit = ProfitAnalyzedHistory(msg);
		double timeSum = 0.0;
		int amount = 0;

		CLogger::LogSpecial(msg);

		CLogger::LogSpecial(IString("Proportional Profit : ") + IInteroperability::DoubleToString(profit));

		for (int i = 0; i < m_AnalyzersForToBuy.Size(); i++)
		{
			timeSum += (*(m_AnalyzersForToBuy.GetPointerToValue(i))).AverageTime();
			amount++;
		}
		for (int i = 0; i < m_AnalyzersForToSell.Size(); i++)
		{
			timeSum += (*(m_AnalyzersForToSell.GetPointerToValue(i))).AverageTime();
			amount++;
		}
		for (int i = 0; i < m_AnalyzersOtherForToBuy.Size(); i++)
		{
			timeSum += (*(m_AnalyzersOtherForToBuy.GetPointerToValue(i))).AverageTime();
			amount++;
		}
		for (int i = 0; i < m_AnalyzersOtherForToSell.Size(); i++)
		{
			timeSum += (*(m_AnalyzersOtherForToSell.GetPointerToValue(i))).AverageTime();
			amount++;
		}
		if (amount == 0)
		{
			amount = 1;
		}

		CLogger::LogSpecial(IString("Average Time : ") + IDateTime::FromSeconds(timeSum / amount));
		return profit;
	}
};
//+------------------------------------------------------------------+
#endif
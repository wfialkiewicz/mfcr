/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_RULES
#define FILE_RULES

#include "Config.h"
#include "Logger.h"
#include "../../Interoperability/String.h"
#include "../../Interoperability/FileWriter.h"
#include "../../Interoperability/Interoperability.h"
#include "../../Interoperability/FileReader.h"

//+------------------------------------------------------------------+
class CRules {
private:
	static IString m_FileName;
	static IGenericObjectArray<IString> m_Rules;

	static void CreateFile()
	{
		IFileWriter writer;

		writer.Delete(m_FileName);
		writer.Initialize(m_FileName);

		m_Rules.Resize(CConfig::Rules.Size());
		for (int i = 0; i < CConfig::Rules.Size(); i++)
		{
			(*(m_Rules.GetPointerToValue(i))) = (*(CConfig::Rules.GetPointerToValue(i)));
			writer.Write((*(CConfig::Rules.GetPointerToValue(i))));
		}
	}

	static void ReadRule(IString &rule, double& minSpeed, double& maxSpeed, double& percentSuccess)
	{
		IGenericObjectArray<IString> res;
		IGenericObjectArray<IString> vals;

		rule.StringSplit(';', res);
		(*(res.GetPointerToValue(0))).StringSplit(':', vals);
		minSpeed = IInteroperability::StringToDouble((*(vals.GetPointerToValue(1))));

		vals.Resize(0);
		(*(res.GetPointerToValue(1))).StringSplit(':', vals);
		maxSpeed = IInteroperability::StringToDouble((*(vals.GetPointerToValue(1))));

		vals.Resize(0);
		(*(res.GetPointerToValue(2))).StringSplit(':', vals);
		percentSuccess = IInteroperability::StringToDouble((*(vals.GetPointerToValue(1))));
	}

public:
	static void Init()
	{
		CreateFile();
	}

	static void ReadVaribles()
	{
		IFileReader reader;
		IString line;

		m_Rules.Resize(0);
		reader.Initialize(m_FileName);
		while (!reader.IsEnd())
		{
			line = reader.ReadLine();
			m_Rules.Add(line);
		}
	}

	static bool HitsRule(double speed, bool& reverseTrades)
	{
		for (int i = 0; i < m_Rules.Size(); i++)
		{
			IString rule = (*(m_Rules.GetPointerToValue(i)));
			double minSpeed;
			double maxSpeed;
			double percentSuccess;

			ReadRule(rule, minSpeed, maxSpeed, percentSuccess);
			if (speed >= minSpeed && speed <= maxSpeed)
			{
				if (percentSuccess >= 50.0)
				{
					reverseTrades = false;
				}
				else
				{
					reverseTrades = true;
				}
				return true;
			}
		}
		return false;
	}
};
IString CRules::m_FileName = IString("ConfigurationRules.txt");
IGenericObjectArray<IString> CRules::m_Rules;
//+------------------------------------------------------------------+
#endif
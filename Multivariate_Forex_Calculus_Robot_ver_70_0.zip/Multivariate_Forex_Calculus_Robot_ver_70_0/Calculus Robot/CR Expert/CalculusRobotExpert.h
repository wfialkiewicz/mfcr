/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

#ifndef FILE_CALCULUS_ROBOT_EXPERT
#define FILE_CALCULUS_ROBOT_EXPERT

#include "CR Includes\\Config.h"
#include "CR Includes\\Logger.h"
#include "CR Includes\\Logs.h"
#include "CR Includes\\PastTradesAnalyzer.h"
#include "CR Includes\\CurrencyPairs.h"
#include "CR Includes\\Timer.h"
#include "CR Includes\\Trading.h"
#include "CR Includes\\MultiAnalyzerInit.h"
#include "CR Includes\\MultiAnalyzerProcess.h"
#include "CR Includes\\MultiAnalyzerPast.h"
#include "CR Includes\\Learning.h"
#include "CR Includes\\LinesProcessor.h"
#include "CR Includes\\Fcnnhn\\Vectors.h"
#include "CR Includes\\Params.h"
#include "CR Includes\\FarPastDataFile.h"
#include "../Interoperability/Interoperability.h"
#include "../Interoperability/GenericObjectArray.h"
#include "../Interoperability/DateTime.h"
#include "CR Includes/Orders.h"
#include "CR Includes/DistancesProvider.h"

//+------------------------------------------------------------------+
class CCalculusRobotExpert{
    private:
        static const int MaxLeverage;
        IDateTime m_LastInitialization;
		IDateTime m_LastFarPastDate;
		IDateTime m_LastPastProfit;
		CCurrencyPairs *m_Pairs;
        CTimer m_Timer;
        CValues m_Values;
        CMultiAnalyzerInit m_AnlyzerInit;
        CMultiAnalyzerProcess *m_AnalyzerProcess;
		CMultiAnalyzerPast m_AnalyzerPast;
        CLearning m_NetBuys;
        CLearning m_NetSells;
        CLearning m_NetTestBuys;
        CLearning m_NetTestSells;
        CParams *m_Params;
		CPastTradesAnalyzer m_PastTradesAnalyzer;
		CLearning m_PastTradesLearn;
		CDistancesProvider m_DistancesProvider;

        bool IsValid()
        {
            if(CConfig::UseSellBuyNeuralNetworks)
            {
                return m_NetBuys.IsValid() || m_NetSells.IsValid();
            }
            else
            {
                return true;
            }
        }
        
        bool LearnNetwork(CLearning &learning, IGenericObjectArray<CLineProcessed> &lines, CVectors &vectors, double testPercent)
        {
            learning.Init((*(lines.GetPointerToValue(0))).Points.Size() + 1 + 1, 1, CConfig::HiddenLayersAmount, CConfig::ActivationFunctionDimension);
            learning.Learn(vectors, testPercent);
            return learning.IsValid();
        }
        
        bool LearnSymbolNetwork(CLearning &learning, IGenericObjectArray<CLineProcessed> &lines, CVectors &vectors, double testPercent)
        {
            learning.Init((*(lines.GetPointerToValue(0))).Points.Size() + 1 + 1, 1, CConfig::HiddenLayersAmountForSymbolNetwork, CConfig::ActivationFunctionDimensionForSymbolNetwork);
            learning.Learn(vectors, testPercent);
            return learning.IsValid();
        }
        
        bool LearnTestNetForBuy(IGenericObjectArray<CLineProcessed> &lines, CVectors &vectors)
        {
            CLogger::LogSpecial(IString("Learning Test Network to Buy."));
            for(int i=0;i<CConfig::NeuralNetworkLearnAttempts;i++)
            {
                CLogger::LogSpecial(IInteroperability::IntegerToString(i+1) + "|" + IInteroperability::IntegerToString(CConfig::NeuralNetworkLearnAttempts) + " Learn Attempt.");
                if(LearnNetwork(m_NetTestBuys, lines, vectors, CConfig::TestVectorsPercent))
                {
                    return true;
                }
            }
            return false;
        }

        bool LearnTestNetForSell(IGenericObjectArray<CLineProcessed> &lines, CVectors &vectors)
        {
            CLogger::LogSpecial(IString("Learning Test Network to Sell."));
            for(int i=0;i<CConfig::NeuralNetworkLearnAttempts;i++)
            {
                CLogger::LogSpecial(IInteroperability::IntegerToString(i+1) + "|" +IInteroperability:: IntegerToString(CConfig::NeuralNetworkLearnAttempts) + " Learn Attempt.");
                if(LearnNetwork(m_NetTestSells, lines, vectors, CConfig::TestVectorsPercent))
                {
                    return true;
                }
            }
            return false;
        }

        bool LearnNetForBuy(IGenericObjectArray<CLineProcessed> &lines, CVectors &vectors)
        {
            CLogger::LogSpecial(IString("Learning Network to Buy."));
            for(int i=0;i<CConfig::NeuralNetworkLearnAttempts;i++)
            {
                CLogger::LogSpecial(IInteroperability::IntegerToString(i+1) + "|" + IInteroperability::IntegerToString(CConfig::NeuralNetworkLearnAttempts) + " Learn Attempt.");
                if(LearnNetwork(m_NetBuys, lines, vectors, 0.0))
                {
                    return true;
                }
            }
            return false;
        }

        bool LearnNetForSell(IGenericObjectArray<CLineProcessed> &lines, CVectors &vectors)
        {
            CLogger::LogSpecial(IString("Learning Network to Sell."));
            for(int i=0;i<CConfig::NeuralNetworkLearnAttempts;i++)
            {
                CLogger::LogSpecial(IInteroperability::IntegerToString(i+1) + "|" + IInteroperability::IntegerToString(CConfig::NeuralNetworkLearnAttempts) + " Learn Attempt.");
                if(LearnNetwork(m_NetSells, lines, vectors, 0.0))
                {
                    return true;
                }
            }
            return false;
        }
        
        void ChoosePastPoints(int symbolNr, bool Symbol, bool SymbolBuy, IGenericObjectArray<CPastPoint> &points)
        {
            int am = 0;
            int pos = 0;
        
            if(SymbolBuy)
            {
                for(int i=0;i<m_AnlyzerInit.PastPointsBuys.Size();i++)
                {
                    if((*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).Symbol == Symbol && (*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).SymbolNr == symbolNr)
                    {
                        am++;
                    }                        
                }
                points.Resize(am);
                for(int i=0;i<m_AnlyzerInit.PastPointsBuys.Size();i++)
                {
                    if((*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).Symbol == Symbol && (*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).SymbolNr == symbolNr)
                    {
                        (*(points.GetPointerToValue(pos))) = (*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i)));
                        pos++;
                    }                        
                }
            }
            else
            {
                for(int i=0;i<m_AnlyzerInit.PastPointsSells.Size();i++)
                {
                    if((*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).Symbol == Symbol && (*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).SymbolNr == symbolNr)
                    {
                        am++;
                    }                        
                }
                points.Resize(am);
                for(int i=0;i<m_AnlyzerInit.PastPointsSells.Size();i++)
                {
                    if((*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).Symbol == Symbol && (*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).SymbolNr == symbolNr)
                    {
                        (*(points.GetPointerToValue(pos))) = (*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i)));
                        pos++;
                    }                        
                }                    
            }
        }
        
        bool LearnSymbolNet(CLearning &learn, IGenericObjectArray<CPastPoint> &points)
        {
            IGenericObjectArray<CLineProcessed> differentialLines;
            CLinesProcessor::GenerateDifferentialLines(points, differentialLines, m_Values);
        
            CVectors vectors;
            
            int pos = 0;
            double val, diff;
            int SymbolNr = 0;
                    
            if(differentialLines.Size() > 0)
            {
                vectors.Init(differentialLines.Size(), (*(differentialLines.GetPointerToValue(0))).Points.Size() + 1 + 1, 1);
                           
                for(int i=0;i<points.Size();i++)
                {
                    if((*(points.GetPointerToValue(i))).IsValid())
                    {     
                        SymbolNr = (*(points.GetPointerToValue(i))).SymbolNr;
                        for(int j=0;j<(*(differentialLines.GetPointerToValue(0))).Points.Size();j++)
                        {
                            (*(vectors.Vectors.GetPointerToValue(pos))).Input.SetValue(j, (*(differentialLines.GetPointerToValue(pos))).Points.GetValue(j));
                        }
                        if((*(points.GetPointerToValue(i))).Successful)
                        {
                            (*(vectors.Vectors.GetPointerToValue(pos))).Output.SetValue(0, 1.0);
                        }
                        else
                        {                    
                            (*(vectors.Vectors.GetPointerToValue(pos))).Output.SetValue(0, -1.0);
                        }
                        if((*(points.GetPointerToValue(i))).SymbolBuy)
                        {
                            if((*(points.GetPointerToValue(i))).Symbol)
                            {
                                val = m_Values.ReturnPastValueNrToBuy((*(points.GetPointerToValue(i))).EstablishingMinimumMaximumPointNr, SymbolNr);
                                diff = IInteroperability::MathAbs(val - m_Values.ReturnPastValueNrToBuy((*(points.GetPointerToValue(i))).MinimumMaximumPointNr, SymbolNr));
                                (*(vectors.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLines.GetPointerToValue(0))).Points.Size(), (*m_Pairs).ReturnUpperLimit(val, diff, SymbolNr, true, true));
                                (*(vectors.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLines.GetPointerToValue(0))).Points.Size() + 1, (*m_Pairs).ReturnLowerLimit(val, diff, SymbolNr, true, true));
                            }
                            else
                            {
                                val = m_Values.ReturnOtherPastValueNrToBuy((*(points.GetPointerToValue(i))).EstablishingMinimumMaximumPointNr, SymbolNr);
                                diff = IInteroperability::MathAbs(val - m_Values.ReturnOtherPastValueNrToBuy((*(points.GetPointerToValue(i))).MinimumMaximumPointNr, SymbolNr));
                                (*(vectors.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLines.GetPointerToValue(0))).Points.Size(), (*m_Pairs).ReturnUpperLimit(val, diff, SymbolNr, false, true));
                                (*(vectors.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLines.GetPointerToValue(0))).Points.Size() + 1, (*m_Pairs).ReturnLowerLimit(val, diff, SymbolNr, false, true));
                            }
                        }
                        else
                        {
                            if((*(points.GetPointerToValue(i))).Symbol)
                            {
                                val = m_Values.ReturnPastValueNrToSell((*(points.GetPointerToValue(i))).EstablishingMinimumMaximumPointNr, SymbolNr);
                                diff = IInteroperability::MathAbs(val - m_Values.ReturnPastValueNrToSell((*(points.GetPointerToValue(i))).MinimumMaximumPointNr, SymbolNr));
                                (*(vectors.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLines.GetPointerToValue(0))).Points.Size(), (*m_Pairs).ReturnUpperLimit(val, diff, SymbolNr, true, false));
                                (*(vectors.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLines.GetPointerToValue(0))).Points.Size() + 1, (*m_Pairs).ReturnLowerLimit(val, diff, SymbolNr, true, false));
                            }
                            else
                            {
                                val = m_Values.ReturnOtherPastValueNrToSell((*(points.GetPointerToValue(i))).EstablishingMinimumMaximumPointNr, SymbolNr);
                                diff = IInteroperability::MathAbs(val - m_Values.ReturnOtherPastValueNrToSell((*(points.GetPointerToValue(i))).MinimumMaximumPointNr, SymbolNr));
                                (*(vectors.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLines.GetPointerToValue(0))).Points.Size(), (*m_Pairs).ReturnUpperLimit(val, diff, SymbolNr, false, false));
                                (*(vectors.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLines.GetPointerToValue(0))).Points.Size() + 1, (*m_Pairs).ReturnLowerLimit(val, diff, SymbolNr, false, false));
                            }
                        }                        
                        pos++;
                    }
                }
                
                IString name;
                
                if((*(points.GetPointerToValue(0))).Symbol)
                {
                    if((*(points.GetPointerToValue(0))).SymbolBuy)
                    {
                        name.AssignString((*m_Pairs).ReturnCurrencyPairToBuyNr(SymbolNr));
                    }
                    else
                    {
                        name.AssignString((*m_Pairs).ReturnCurrencyPairToSellNr(SymbolNr));
                    }
                }
                else
                {
                    if((*(points.GetPointerToValue(0))).SymbolBuy)
                    {
                        name.AssignString((*m_Pairs).ReturnOtherSymbolToBuyNr(SymbolNr));
                    }
                    else
                    {
                        name.AssignString((*m_Pairs).ReturnOtherSymbolToSellNr(SymbolNr));
                    }
                }
                
                CLogger::LogSpecial(IString("Learning Symbol Network for ") + name);
                if(LearnSymbolNetwork(*(*m_Pairs).ReturnLearningObject((*(points.GetPointerToValue(0))).SymbolNr, (*(points.GetPointerToValue(0))).Symbol, (*(points.GetPointerToValue(0))).SymbolBuy), differentialLines, vectors, 0.0))
                {
                    return true;
                }
            }
            return false;
        }
        
        void LearnSymbolNets()
        {
            IGenericObjectArray<CPastPoint> points;
            int learned = 0;
            int all = 0;
        
            CLogger::LogSpecial(IString("Learning Symbol Nets."));
            for(int i=0;i<(*m_Pairs).AmountCurrencyPairsToBuy();i++)
            {
                if((*(*m_Pairs).ReturnMultiTo(i, true, true)).IsTradable)
                {
                    ChoosePastPoints(i, true, true, points);
                    if(LearnSymbolNet(*((*m_Pairs).ReturnLearningObject(i, true, true)), points))
                    {
                        learned++;
                    }
                    all++;
                }
            }
            for(int i=0;i<(*m_Pairs).AmountCurrencyPairsToSell();i++)
            {
                if((*(*m_Pairs).ReturnMultiTo(i, true, false)).IsTradable)
                {
                    ChoosePastPoints(i, true, false, points);
                    if(LearnSymbolNet(*((*m_Pairs).ReturnLearningObject(i, true, false)), points))
                    {
                        learned++;
                    }
                    all++;
                }
            }
            for(int i=0;i<(*m_Pairs).AmountOtherSymbolsToBuy();i++)
            {
                if((*(*m_Pairs).ReturnMultiTo(i, false, true)).IsTradable)
                {
                    ChoosePastPoints(i, false, true, points);
                    if(LearnSymbolNet(*((*m_Pairs).ReturnLearningObject(i, false, true)), points))
                    {
                        learned++;
                    }
                    all++;
                }                
            }
            for(int i=0;i<(*m_Pairs).AmountOtherSymbolsToSell();i++)
            {
                if((*(*m_Pairs).ReturnMultiTo(i, false, false)).IsTradable)
                {
                    ChoosePastPoints(i, false, false, points);
                    if(LearnSymbolNet(*((*m_Pairs).ReturnLearningObject(i, false, false)), points))
                    { 
                        learned++;
                    }
                    all++;
                }
            }
            CLogger::LogSpecial(IString("Symbol Nets Learned : ") + IInteroperability::IntegerToString(learned) + "|" + IInteroperability::IntegerToString(all));
        }
        
		void DetermineMethodDPArams()
		{
			if (CConfig::UseAfterTrendAutomaticParams)
			{
				CLogs logs;

				logs.ReadLogs();
				logs.ExtractTrades((*m_Pairs).TradableAmount(), true);
				logs.AssignOrder();

				CLogger::LogSpecial(IString("Amount of Trades Extracted from logs : ") + IInteroperability::IntegerToString(logs.TradesAmount()));
				if (logs.TradesAmount() > CConfig::TradesAmountMin)
				{
					CLogger::LogSpecial(IString("Determining Method D Params."));
				}
				else
				{
					CLogger::LogSpecial(IString("Determining Method D Params skipped. Extracted Trades Amount is less then : ") + IInteroperability::IntegerToString(CConfig::TradesAmountMin));
					return;
				}

				IGenericObjectArray<CTrade> trades;

				logs.FillTrades(trades);
				(*m_Params).DetermineMethodDParams(trades);
			}
		}

		void AnalyzePastData()
		{
			CValues values;

			{
				IGenericObjectArray<CPastValues> vals;

				CFarPastDataFile::ReadDataColumnsValues(*m_Pairs, vals);
				if (CFarPastDataFile::IsPastDataLongEnough(vals))
				{
					CFarPastDataFile::NarrowPastDataLenght(vals);
					values.AssignPastValues(vals, *m_Pairs);
					CLogger::LogSpecial(IString("Past Data long enough."));
				}
				else
				{
					CLogger::LogSpecial(IString("Past Data not long enough."));
					return;
				}
			}

			m_AnalyzerPast.SetValues(values);
			m_AnalyzerPast.PreInit(*m_Pairs);
			m_AnalyzerPast.Analyze();

			m_DistancesProvider.AssignPoints(m_AnalyzerPast.PastPointsBuys, m_AnalyzerPast.PastPointsSells, *m_Pairs);			
			m_DistancesProvider.SetValidity(true);
		}

    public:
		void InitFarPastData()
		{
			if (CConfig::WriteFarPastData)
			{
				CFarPastDataFile::WriteDataColumnsNames(*m_Pairs);
				m_LastFarPastDate = IDateTime::TimeCurrent();
			}
			if (CConfig::WritePastProfit)
			{
				m_LastPastProfit = IDateTime::TimeCurrent();
			}
		}

		void IntervalElapsedFarPastData()
		{
			if (CConfig::WriteFarPastData)
			{
				IDateTime date = IDateTime::TimeCurrent();

				if (IDateTime::SecondsDiff(m_LastFarPastDate, date) > CConfig::FarPastDataIntervalSeconds)
				{
					CFarPastDataFile::WriteDataColumnsValues(*m_Pairs);
					m_LastFarPastDate = date;
				}
			}
		}

		void IntervalElapsedPastProfit()
		{
			if (CConfig::WritePastProfit)
			{
				IDateTime date = IDateTime::TimeCurrent();

				if (IDateTime::SecondsDiff(m_LastPastProfit, date) > CConfig::PastProfitIntervalSeconds)
				{
					double prof;
					int total;

					prof = COrders::Profit(total);
					CLogger::LogFromProfitPast(IString("LotSize : ") + IInteroperability::DoubleToString(CConfig::LotSize) + IString(", Profit : ") + IInteroperability::DoubleToString(prof) + IString(", Trades Amount : ") + IInteroperability::IntegerToString(total));
					m_LastPastProfit = date;
				}
			}
		}

        void SetParams(CParams &params, CCurrencyPairs &pairs)
        {
            m_Params = &params;
            m_Pairs = &pairs;
			CValueAnalyzer::SetParams(params);
        }
    
        void SetInitialization()
        {
            m_LastInitialization = IDateTime::TimeCurrent();
        }

        void AssignAnalyzerProcess(CMultiAnalyzerProcess &process)
        {
            m_AnalyzerProcess = &process;
			(*m_AnalyzerProcess).SetPastTradesAnalyzer(m_PastTradesAnalyzer, m_PastTradesLearn);
			(*m_AnalyzerProcess).AssignDistancesProvider(m_DistancesProvider);
        }
        
        void KillTimer()
        {
            m_Timer.KillTimer();
        }
        
        void SetTimer()
        {
            m_Timer.SetTimer();
        }
    
        static bool CheckLeverage()
        {
            CLogger::LogSpecial(IString("Account Leverage equal to : ") + IInteroperability::IntegerToString(IInteroperability::AccountLeverage()));
            if(CConfig::CheckLeverage)
            {
                if(IInteroperability::AccountLeverage() > MaxLeverage)
                {
                    CLogger::LogSpecial(IString("Account Leverage can be at max : ") + IInteroperability::IntegerToString(MaxLeverage));
                    return false;
                }
            }
            return true;
        }
        
        bool CheckForInitialization()
        {
            IDateTime date = IDateTime::TimeCurrent();
            
            if(IDateTime::MinutesDiff(m_LastInitialization, date) > CConfig::FutureHoursWindow * 60)
            {
                return true;
            }
            else if(!IsValid())
            {
                if(IDateTime::MinutesDiff(m_LastInitialization, date) > CConfig::FutureHoursInvalidRestart * 60)
                {
                    return true;
                }
            }
            return false;
        }
        
        CCalculusRobotExpert()
        {
     	    IString logs("Logs");

            CLogger::Init(logs);
            CLearning::InitStatic();
        }
      
        bool GetValues()
        {
            IDateTime now = IDateTime::TimeCurrent();
            
            for(int i=0;i<(*m_Pairs).AmountCurrencyPairsToBuy();i++)
            {
				IString pair((*m_Pairs).ReturnCurrencyPairToBuyNr(i));

                CLogger::Log(IString((*m_Pairs).ReturnCurrencyPairToBuyNr(i)) + " : " + IInteroperability::DoubleToString(CValues::GetPriceAtTime(pair, now)));
            }

            for(int i=0;i<(*m_Pairs).AmountCurrencyPairsToSell();i++)
            {
				IString pair((*m_Pairs).ReturnCurrencyPairToSellNr(i));

                CLogger::Log(IString((*m_Pairs).ReturnCurrencyPairToSellNr(i)) + " : " + IInteroperability::DoubleToString(CValues::GetPriceAtTime(pair, now)));
            }
            
            for(int i=0;i<(*m_Pairs).AmountOtherSymbolsToBuy();i++)
            {
				IString pair((*m_Pairs).ReturnOtherSymbolToBuyNr(i));

                CLogger::Log(IString((*m_Pairs).ReturnOtherSymbolToBuyNr(i)) + " : " + IInteroperability::DoubleToString(CValues::GetPriceAtTime(pair, now)));
            }

            for(int i=0;i<(*m_Pairs).AmountOtherSymbolsToSell();i++)
            {
				IString pair((*m_Pairs).ReturnOtherSymbolToSellNr(i));

                CLogger::Log(IString((*m_Pairs).ReturnOtherSymbolToSellNr(i)) + " : " + IInteroperability::DoubleToString(CValues::GetPriceAtTime(pair, now)));
            }
            
            if(!m_Values.InitWithNowTime(*m_Pairs))
            {
                return false;
            }
            else
            {
                m_Values.Log();
                return true;
            }
        } 
         
        
        CValues* ReturnValues()
        {
            return &m_Values;
        }
         
		void CheckHistory()
		{
			m_AnlyzerInit.PreInit(*m_Pairs);
			m_AnlyzerInit.SetValues(m_Values);

			m_AnlyzerInit.CheckHistory();

			if (CConfig::UseTrendFromLogs && (*m_Pairs).TradablePeriod())
			{
				TrainTrendNetwork();
			}
			if (CConfig::UseAfterTrend && CConfig::UseAfterTrendAutomaticParams && (*m_Pairs).TradablePeriod())
			{
				DetermineMethodDPArams();
			}
			if (CConfig::UseSellBuyNeuralNetworks && (*m_Pairs).TradablePeriod())
			{
				TrainNeuralNetworks();
	        }
			if (CConfig::UseIndividualNeuralNetworks && (*m_Pairs).TradablePeriod())
			{
     			LearnSymbolNets();
			}
			if (CConfig::UseCalculateDistance && (*m_Pairs).TradablePeriod())
			{
				AnalyzePastData();
			}
		}

		void TrainTrendNetwork()
		{
			if (CConfig::UseTrendFromLogs)
			{
			    CLogs logs;

			    logs.ReadLogs();
			    logs.ExtractTrades((*m_Pairs).TradableAmount());
				logs.AssignOrder();

			    CLogger::LogSpecial(IString("Amount of Trades Extracted from logs : ") + IInteroperability::IntegerToString(logs.TradesAmount()));
			    if (logs.TradesAmount() > CConfig::TradesAmountMin)
			    {
				    CLogger::LogSpecial(IString("Detecting Trend."));
			    }
			    else
			    {
				    CLogger::LogSpecial(IString("Detecting Trend Skipped. Extracted Trades Amount is less then : ") + IInteroperability::IntegerToString(CConfig::TradesAmountMin));
					return;
			    }

				m_PastTradesAnalyzer.Analyze(logs);
				m_PastTradesAnalyzer.CleanUpAndSetMultiplicationValues();

				if (CConfig::PastTrendsUseNeuralNetwork)
				{
					m_PastTradesLearn.Init(m_PastTradesAnalyzer.BestInputsAmount(), 1, CConfig::HiddenLayersAmountForTrendNetwork, CConfig::ActivationFunctionDimensionForTrendNetwork);
					logs.AssignVectors(m_PastTradesAnalyzer.BestInputsAmount());
					m_PastTradesLearn.Learn(*(logs.ReturnVectors()), 0.0);
				}
			}
		}
        
        void TrainNeuralNetworks()
        {
            IGenericObjectArray<CLineProcessed> differentialLinesBuys;
            IGenericObjectArray<CLineProcessed> differentialLinesSells;
        
            CLinesProcessor::GenerateDifferentialLines(m_AnlyzerInit.PastPointsBuys, differentialLinesBuys, m_Values);
            CLinesProcessor::GenerateDifferentialLines(m_AnlyzerInit.PastPointsSells, differentialLinesSells, m_Values);
        
            CVectors vectorsBuy;
            CVectors vectorsSell;
            
            int pos = 0;
            double val, diff;
            int SymbolNr;
                    
            if(differentialLinesBuys.Size() > 0)
            {
                vectorsBuy.Init(differentialLinesBuys.Size(), (*(differentialLinesBuys.GetPointerToValue(0))).Points.Size() + 1 + 1, 1);
                           
                for(int i=0;i<m_AnlyzerInit.PastPointsBuys.Size();i++)
                {
                    if((*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).IsValid())
                    {     
                        SymbolNr = (*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).SymbolNr;
                        for(int j=0;j<(*(differentialLinesBuys.GetPointerToValue(0))).Points.Size();j++)
                        {
                            (*(vectorsBuy.Vectors.GetPointerToValue(pos))).Input.SetValue(j, (*(differentialLinesBuys.GetPointerToValue(pos))).Points.GetValue(j));
                        }
                        if((*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).Successful)
                        {
                            (*(vectorsBuy.Vectors.GetPointerToValue(pos))).Output.SetValue(0, 1.0);
                        }
                        else
                        {                    
                            (*(vectorsBuy.Vectors.GetPointerToValue(pos))).Output.SetValue(0, -1.0);
                        }
                        if((*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).Symbol)
                        {
                            val = m_Values.ReturnPastValueNrToBuy((*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).EstablishingMinimumMaximumPointNr, SymbolNr);
                            diff = IInteroperability::MathAbs(val - m_Values.ReturnPastValueNrToBuy((*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).MinimumMaximumPointNr, SymbolNr));
                            (*(vectorsBuy.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLinesBuys.GetPointerToValue(0))).Points.Size(), (*m_Pairs).ReturnUpperLimit(val, diff, SymbolNr, true, true));
                            (*(vectorsBuy.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLinesBuys.GetPointerToValue(0))).Points.Size() + 1,  (*m_Pairs).ReturnLowerLimit(val, diff, SymbolNr, true, true));
                        }
                        else
                        {
                            val = m_Values.ReturnOtherPastValueNrToBuy((*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).EstablishingMinimumMaximumPointNr, SymbolNr);
                            diff = IInteroperability::MathAbs(val - m_Values.ReturnOtherPastValueNrToBuy((*(m_AnlyzerInit.PastPointsBuys.GetPointerToValue(i))).MinimumMaximumPointNr, SymbolNr));
                            (*(vectorsBuy.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLinesBuys.GetPointerToValue(0))).Points.Size(), (*m_Pairs).ReturnUpperLimit(val, diff, SymbolNr, false, true));
                            (*(vectorsBuy.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLinesBuys.GetPointerToValue(0))).Points.Size() + 1, (*m_Pairs).ReturnLowerLimit(val, diff, SymbolNr, false, true));
                        }
                        pos++;
                    }
                }
            }
            
            if(differentialLinesSells.Size() > 0)
            {
                vectorsSell.Init(differentialLinesSells.Size(), (*(differentialLinesSells.GetPointerToValue(0))).Points.Size() + 1 + 1, 1);
        
                pos = 0;
                for(int i=0;i<m_AnlyzerInit.PastPointsSells.Size();i++)
                {
                    if((*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).IsValid())
                    {     
                        SymbolNr = (*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).SymbolNr;
                        for(int j=0;j<(*(differentialLinesSells.GetPointerToValue(0))).Points.Size();j++)
                        {
                            (*(vectorsSell.Vectors.GetPointerToValue(pos))).Input.SetValue(j, (*(differentialLinesSells.GetPointerToValue(pos))).Points.GetValue(j));
                        }
                        if((*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).Successful)
                        {
                            (*(vectorsSell.Vectors.GetPointerToValue(pos))).Output.SetValue(0, 1.0);
                        }
                        else
                        {                    
                            (*(vectorsSell.Vectors.GetPointerToValue(pos))).Output.SetValue(0, -1.0);
                        }
                        if((*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).Symbol)
                        {
                            val = m_Values.ReturnPastValueNrToSell((*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).EstablishingMinimumMaximumPointNr, SymbolNr);
                            diff = IInteroperability::MathAbs(val - m_Values.ReturnPastValueNrToSell((*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).MinimumMaximumPointNr, SymbolNr));
                            (*(vectorsSell.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLinesSells.GetPointerToValue(0))).Points.Size(), (*m_Pairs).ReturnUpperLimit(val, diff, SymbolNr, true, false));
                            (*(vectorsSell.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLinesSells.GetPointerToValue(0))).Points.Size() + 1, (*m_Pairs).ReturnLowerLimit(val, diff, SymbolNr, true, false));
                        }
                        else
                        {
                            val = m_Values.ReturnOtherPastValueNrToSell((*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).EstablishingMinimumMaximumPointNr, SymbolNr);
                            diff = IInteroperability::MathAbs(val - m_Values.ReturnOtherPastValueNrToSell((*(m_AnlyzerInit.PastPointsSells.GetPointerToValue(i))).MinimumMaximumPointNr, SymbolNr));
                            (*(vectorsSell.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLinesSells.GetPointerToValue(0))).Points.Size(), (*m_Pairs).ReturnUpperLimit(val, diff, SymbolNr, false, false));
                            (*(vectorsSell.Vectors.GetPointerToValue(pos))).Input.SetValue((*(differentialLinesSells.GetPointerToValue(0))).Points.Size() + 1, (*m_Pairs).ReturnLowerLimit(val, diff, SymbolNr, false, false));
                        }
                        pos++;
                    }
                }
            }
            
            if(differentialLinesBuys.Size() > 0)
            {
                if(LearnTestNetForBuy(differentialLinesBuys, vectorsBuy))
                {
                    LearnNetForBuy(differentialLinesBuys, vectorsBuy);
                }
            }
            
            if(differentialLinesSells.Size() > 0)
            {   
                if(LearnTestNetForSell(differentialLinesSells, vectorsSell))
                {
                    LearnNetForSell(differentialLinesSells, vectorsSell);
                }
            }
            (*m_AnalyzerProcess).AssignNetworks(m_NetBuys, m_NetSells);
        }
        
        void DoTrading()
        {
            if(CConfig::CheckBalance && IInteroperability::AccountBalance() >= 200000.0)
            {
				CLogger::Log(IString("Account Balance reached maximum."));
                return;
            }
            else
            {
          	   IDateTime time(IDateTime::TimeCurrent());

			   COrders::ZeroProfit();
               (*m_AnalyzerProcess).AddToAnalysis(time);
            }
        }
};
const int CCalculusRobotExpert::MaxLeverage = 30;
//+------------------------------------------------------------------+
#endif

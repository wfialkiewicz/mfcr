﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using System;
using System.Collections.Generic;

namespace CommonLibrary
{
    public class ProfitSearch
    {
        private List<Profit> m_pSearch;

        public int CompareToDateBased(Profit objA, Profit objB)
        {
            return objA.TradeBegin.CompareTo(objB.TradeBegin);
        }

        public List<Profit> Trades
        {
            get
            {
                return m_pSearch;
            }
        }

        public static long Parse(string line)
        {
            string[] words;
            string number;

            words = line.Split(new char[] { ' ' });
            number = words[words.Length - 1];
            number = number.Trim();
            return long.Parse(number);
        }

        public static string ParseSymbol(string line)
        {
            string[] words;
            string symbol;

            words = line.Split(new char[] { ',' });
            symbol = words[2];
            words = symbol.Split(new char[] { ':' });
            symbol = words[1];
            symbol = symbol.Trim();
            return symbol;
        }


        public void AssignProfitSearchList()
        {
            m_pSearch = new List<Profit>();
        }

        public void SearchProfitStart(FileLines list)
        {
            foreach (Line line in list.Lines)
            {
                if (line.Content.Contains("Profit Search Start"))
                {
                    Profit ps = new Profit();

                    ps.Nr = ProfitSearch.Parse(line.Content);
                    ps.TradeBegin = line.Date;
                    m_pSearch.Add(ps);
                }
            }
            m_pSearch.Sort();
        }

        public int SearchProfitEnd(FileLines list)
        {
            int allEnded = 0;

            foreach (Line line in list.Lines)
            {
                if (line.Content.Contains("Profit Search End"))
                {
                    Profit ps = new Profit();
                    int pos;

                    ps.Nr = ProfitSearch.Parse(line.Content);
                    ps.Symbol = ProfitSearch.ParseSymbol(line.Content);

                    pos = m_pSearch.BinarySearch(ps);
                    if (pos >= 0)
                    {
                        if (line.Content.Contains("Profit found"))
                        {
                            m_pSearch[pos].Successfull = true;
                        }
                        else if (!line.Content.Contains("_RT"))
                        {
                            m_pSearch[pos].Successfull = false;
                        }
                        m_pSearch[pos].Ended = true;
                        m_pSearch[pos].TradeEnd = line.Date;
                        allEnded++;
                    }
                }
            }
            return allEnded;
        }

        public int SearchProfitEndRT(FileLines list)
        {
            int allEnded = 0;

            foreach (Line line in list.Lines)
            {
                if (line.Content.Contains("Profit Search End"))
                {
                    Profit ps = new Profit();
                    int pos;

                    ps.Nr = ProfitSearch.Parse(line.Content);
                    ps.Symbol = ProfitSearch.ParseSymbol(line.Content);

                    pos = m_pSearch.BinarySearch(ps);
                    if (pos >= 0)
                    {
                        if (line.Content.Contains("Profit_found_RT"))
                        {
                            m_pSearch[pos].Successfull = true;
                        }
                        else if (line.Content.Contains("_RT"))
                        {
                            m_pSearch[pos].Successfull = false;
                        }
                        m_pSearch[pos].Ended = true;
                        m_pSearch[pos].TradeEnd = line.Date;
                        allEnded++;
                    }
                }
            }
            return allEnded;
        }

        public int SearchProfitArg(FileLines list, string arg)
        {
            int found = 0;

            foreach (Line line in list.Lines)
            {
                if (line.Content.Contains(arg))
                {
                    Profit ps = new Profit();
                    int pos;

                    ps.Nr = ProfitSearch.Parse(line.Content);
                    pos = m_pSearch.BinarySearch(ps);
                    if (pos >= 0 && m_pSearch[pos].Ended)
                    {
                        found++;
                    }
                }
            }
            return found;
        }

        public void SortBasedOnDate()
        {
            m_pSearch.Sort(new Comparison<Profit>(CompareToDateBased));
        }
    }
}

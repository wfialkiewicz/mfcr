﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using System;
using System.Collections.Generic;

namespace CommonLibrary
{
    public class LogString
    {
        private static int GetPos(int pos)
        {
            if(pos >=0)
            {
                return pos;
            }
            else
            {
                int newPos = ~pos;

                if(newPos > 0)
                {
                    newPos--;
                }
                return newPos;
            }
        }

        public static int CountStrings(FileLines list, string search)
        {
            int count = 0;

            for (int i = 0; i < list.Lines.Count; i++)
            {
                if (list.Lines[i].Content.Contains(search))
                {
                    count++;
                }
            }

            return count;
        }

        public static int CountStrings(FileLines list, string search, DateTime beg, DateTime end)
        {
            int count = 0;
            DateTime date;
            Line beg_line = new Line();
            int pos;

            beg_line.Date = beg;
            pos = list.Lines.BinarySearch(beg_line);
            pos = GetPos(pos);

            for (int i = pos; i < list.Lines.Count; i++)
            {
                if (list.Lines[i].Content.Contains(search))
                {
                    date = list.Lines[i].Date;
                    if (date >= beg && date < end)
                    {
                        count++;
                        if (date > end)
                        {
                            break;
                        }
                    }
                }
            }

            return count;
        }

        public static List<string> ParseOrders(FileLines list, string search, DateTime beg, DateTime end)
        {
            DateTime date;
            List<string> res = new List<string>();
            Line beg_line = new Line();
            int pos;

            beg_line.Date = beg;
            pos = list.Lines.BinarySearch(beg_line);
            pos = GetPos(pos);

            for (int i = pos; i < list.Lines.Count; i++)
            {
                if (list.Lines[i].Content.Contains(search))
                {
                    date = list.Lines[i].Date;
                    if (date >= beg && date < end)
                    {
                        string[] arr = list.Lines[i].Content.Split(' ');

                        res.Add(arr[arr.Length - 1].Trim());
                        if (date > end)
                        {
                            break;
                        }
                    }
                }
            }
            return res;
        }
    }
}

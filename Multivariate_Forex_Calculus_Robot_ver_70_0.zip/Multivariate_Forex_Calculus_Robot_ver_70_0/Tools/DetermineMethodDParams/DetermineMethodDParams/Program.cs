﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using CommonLibrary;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace DetermineMethodDParams
{
    class Program
    {
        static List<Result> m_Results;

        static void CheckPermutation(ProfitSearch ps, int hours, int trades, double ratio)
        {
            bool reverseAfter = false;
            int globalSuccesfull = 0;
            int globalFailed = 0;

            DateTime dateWindowStart = ps.Trades[0].TradeBegin;
            DateTime dateWindowEnd = dateWindowStart.AddHours(hours);

            for (int i = 0; i < ps.Trades.Count; i++)
            {
                int successfull = 0;
                int failed = 0;

                for (int j = 0; j < ps.Trades.Count; j++)
                {
                    if (ps.Trades[j].Ended)
                    {
                        if (ps.Trades[j].TradeBegin >= dateWindowStart && ps.Trades[j].TradeBegin <= dateWindowEnd)
                        {
                            ps.Trades[j].AfterTrendReverseTrades = reverseAfter;
                        }
                        if (ps.Trades[j].TradeEnd >= dateWindowStart && ps.Trades[j].TradeEnd <= dateWindowEnd)
                        {
                            if (ps.Trades[j].Successfull && !ps.Trades[j].AfterTrendReverseTrades || (!ps.Trades[j].Successfull && ps.Trades[j].AfterTrendReverseTrades))
                            {
                                successfull++;
                            }
                            else
                            {
                                failed++;
                            }
                        }
                    }
                }

                globalSuccesfull += successfull;
                globalFailed += failed;

                if (trades <= successfull + failed && !(successfull >= ratio * failed))
                {
                    reverseAfter = !reverseAfter;
                }

                dateWindowStart = dateWindowEnd;
                if (dateWindowStart.DayOfWeek == DayOfWeek.Saturday)
                {
                    dateWindowStart = dateWindowStart.AddHours(48);
                    if (dateWindowStart.Hour > 0)
                    {
                        dateWindowStart = dateWindowStart.AddHours(-(dateWindowStart.Hour - 1));
                    }
                }
                else if (dateWindowStart.DayOfWeek == DayOfWeek.Sunday)
                {
                    dateWindowStart = dateWindowStart.AddHours(24);
                    if (dateWindowStart.Hour > 0)
                    {
                        dateWindowStart = dateWindowStart.AddHours(-(dateWindowStart.Hour - 1));
                    }
                }

                dateWindowEnd = dateWindowStart.AddHours(hours);
            }

            Console.WriteLine("Combination hours : {0}, trades : {1}, ratio : {2}, successfull : {3}, failed : {4}.", hours, trades, ratio, globalSuccesfull, globalFailed);
            Result res = new Result();

            res.Failed = globalFailed;
            res.Successfull = globalSuccesfull;
            res.Trade = trades;
            res.Hours = hours;
            res.FailedRatio = ratio;
            res.SuccesfullRatio = (double)globalSuccesfull / (double)globalFailed;

            m_Results.Add(res);
        }

        static ProfitSearch ReadLog(string fileName)
        {
            FileLines fl = new FileLines();
            ProfitSearch ps = new ProfitSearch();

            fl.ReadFile(fileName);
            ps.AssignProfitSearchList();
            ps.SearchProfitStart(fl);
            ps.SearchProfitEndRT(fl);
            ps.SortBasedOnDate();

            return ps;
        }

        static void Main(string[] args)
        {
            if (args.Count() != 9)
            {
                Console.WriteLine("DetermineMethodDParams.exe fileName hoursMin hoursMax tradesMin tradesMax falseRatioMin falseRatioMax falseRatioStep commonPercent");
                Console.ReadLine();
            }
            else
            {
                string fileName;
                int hoursMin, hoursMax;
                int tradesMin, tradesMax;
                double falseRatioMin, falseRatioMax, falseRatioStep;
                double percent;

                fileName = args[0];
                hoursMin = int.Parse(args[1]);
                hoursMax = int.Parse(args[2]);
                tradesMin = int.Parse(args[3]);
                tradesMax = int.Parse(args[4]);
                falseRatioMin = double.Parse(args[5], CultureInfo.InvariantCulture);
                falseRatioMax = double.Parse(args[6], CultureInfo.InvariantCulture);
                falseRatioStep = double.Parse(args[7], CultureInfo.InvariantCulture);
                percent = double.Parse(args[8], CultureInfo.InvariantCulture);

                ProfitSearch ps = ReadLog(fileName);
                m_Results = new List<Result>();

                for (int h = hoursMin; h <= hoursMax; h++)
                {
                    for (int t = tradesMin; t <= tradesMax; t++)
                    {
                        for (double r = falseRatioMin; r <= falseRatioMax; r += falseRatioStep)
                        {
                            CheckPermutation(ps, h, t, r);
                        }
                    }
                }

                FindBestCommonCombination(percent * (hoursMax - hoursMin) / 2.0, percent * (tradesMax - tradesMin) / 2.0, percent * (falseRatioMax - falseRatioMin) / 2.0);

                m_Results.Sort();
                Console.WriteLine();
                Console.WriteLine("Best combination : ");
                Print(m_Results[m_Results.Count - 1]);

                Console.WriteLine();
                Console.WriteLine("Worst combination : ");
                Print(m_Results[0]);

                Console.ReadLine();
            }
        }

        static void Print(Result res)
        {
            Console.WriteLine("CConfig::PastTradeWithRTSwitchRatio : {0}.", res.FailedRatio);
            Console.WriteLine("CConfig::PastTradeWithRTMinAmount : {0}.", res.Trade);
            Console.WriteLine("CConfig::AfterTrendHoursToAnalysisLength : {0}.", res.Hours);
            Console.WriteLine("Succesfull Amount : {0}.", res.Successfull);
            Console.WriteLine("Failed Amount : {0}.", res.Failed);
        }

        static void FindBestCommonCombination(double hoursPercent, double tradesPercent, double ratioPercent)
        {
            List<Res> SuccessSums = new List<Res>();
            List<int> common;
            
            for (int i = 0; i < m_Results.Count; i++)
            {
                Res sum = new Res();

                sum.Nr = i;
                common = FindCommon(i, hoursPercent, tradesPercent, ratioPercent);
                for(int j=0;j<common.Count;j++)
                {
                    sum.SuccessSum += m_Results[common[j]].SuccesfullRatio;
                }

                SuccessSums.Add(sum);
                Console.WriteLine("FindingCommonsFor : {0}/{1}.", i, m_Results.Count);
            }
            SuccessSums.Sort();

            Console.WriteLine();
            Console.WriteLine("Best common combination : ");
            Print(m_Results[SuccessSums[SuccessSums.Count - 1].Nr]);

            Console.WriteLine();
            Console.WriteLine("Worst common combination : ");
            Print(m_Results[SuccessSums[0].Nr]);

        }

        static List<int> FindCommon(int nr, double hoursPercent, double tradesPercent, double ratioPercent)
        {
            List<int> common = new List<int>();

            for (int i = 0; i < m_Results.Count; i++)
            {
                if (Math.Abs(m_Results[i].Hours - m_Results[nr].Hours) <= hoursPercent)
                {
                    if (Math.Abs(m_Results[i].Trade - m_Results[nr].Trade) <= tradesPercent)
                    {
                        if (Math.Abs(m_Results[i].FailedRatio - m_Results[nr].FailedRatio) <= ratioPercent)
                        {
                            common.Add(i);
                        }
                    }
                }
            }
            return common;
        }
    }
}

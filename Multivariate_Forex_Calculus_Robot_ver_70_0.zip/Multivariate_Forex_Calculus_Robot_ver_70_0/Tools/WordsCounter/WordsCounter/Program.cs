﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using CommonLibrary;
using System;
using System.Collections.Generic;

namespace WordsCounter
{
    class Program
    {
        static bool WasWeekend(DateTime beg, DateTime end)
        {
            DateTime date = beg;

            while(date < end)
            {
                date = date.AddDays(1);
                if(date.DayOfWeek == DayOfWeek.Saturday)
                {
                    return true;
                }
                if (date.DayOfWeek == DayOfWeek.Sunday)
                {
                    return true;
                }
            }
            return false;
        }

        static void CallingArguments()
        {
            Console.WriteLine("WordsCounter fileName.txt -c|-cps \"term1\" \"term2\" ... ");
            Console.WriteLine("WordsCounter fileName.txt -chd hours \"term1\" \"term2\" ... ");
            Console.WriteLine("WordsCounter fileName.txt -chh hours hoursMove hoursFuture");
            Console.WriteLine("WordsCounter filename.txt -at");
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            if (args.Length < 2)
            {
                CallingArguments();
                return;
            }
            if (args[1] == "-c")
            {
                FileLines list = new FileLines();
                List<int> amounts = new List<int>();
                double sum = 0;

                list.ReadFile(args[0]);

                for (int i = 2; i < args.Length; i++)
                {
                    amounts.Add(LogString.CountStrings(list, args[i]));
                    sum += amounts[i - 2];
                }

                for (int i = 2; i < args.Length; i++)
                {
                    Console.WriteLine(args[i] + " : " + amounts[i - 2] + ", Fraction : " + amounts[i - 2] / sum);
                }
            }
            else if (args[1] == "-cps")
            {
                FileLines list = new FileLines();
                ProfitSearch pSearch = new ProfitSearch();
                double allEnded;

                list.ReadFile(args[0]);
                pSearch.AssignProfitSearchList();
                pSearch.SearchProfitStart(list);
                allEnded = pSearch.SearchProfitEnd(list);

                for (int i = 2; i < args.Length; i++)
                {
                    int found = pSearch.SearchProfitArg(list, args[i]);
                    Console.WriteLine("{2}, Found : {0}, Percent : {1}.", found, allEnded > 0.0 ? (found / allEnded) : 0.0, args[i]);
                }

                Console.WriteLine("All : {0}.", allEnded);
                Console.ReadLine();
                return;
            }
            else if (args[1] == "-chd")
            {
                FileLines list = new FileLines();
                DateTime beg, end, cur;
                int hours;


                list.ReadFile(args[0]);
                beg = list.GetBeginDate();
                end = list.GetEndDate();
                hours = int.Parse(args[2]);

                cur = beg;
                do
                {
                    List<int> amounts = new List<int>();
                    double sum = 0;

                    Console.WriteLine(cur.ToString());
                    for (int i = 3; i < args.Length; i++)
                    {
                        amounts.Add(LogString.CountStrings(list, args[i], cur, Date.AddHours(cur, hours)));
                        sum += amounts[i - 3];
                    }

                    for (int i = 3; i < args.Length; i++)
                    {
                        Console.WriteLine(args[i] + " : " + amounts[i - 3] + ", Fraction : " + amounts[i - 3] / sum);
                    }
                    cur = Date.AddHours(cur, hours);
                } while (cur < end);
            }
            else if (args[1] == "-chh")
            {
                FileLines list = new FileLines();
                DateTime beg, end, cur, curEnd;
                int hours, hoursMove, hoursFuture;

                list.ReadFile(args[0]);
                beg = list.GetBeginDate();
                end = list.GetEndDate();
                hours = int.Parse(args[2]);
                hoursMove = int.Parse(args[3]);
                hoursFuture = int.Parse(args[4]);

                cur = beg;
                do
                {
                    List<string> opened;
                    List<string> sucessfull;
                    List<string> failed;
                    int succ = 0;
                    int fail = 0;
                    double sum = 0;

                    curEnd = Date.AddHours(cur, hours);

                    opened = LogString.ParseOrders(list, "Profit Search Start Nr", cur, curEnd);
                    sucessfull = LogString.ParseOrders(list, "Profit found", cur, curEnd);
                    failed = LogString.ParseOrders(list, "Profit lost", cur, curEnd);

                    foreach (string o in opened)
                    {
                        if (sucessfull.Contains(o))
                        {
                            succ++;
                        }
                        else if (failed.Contains(o))
                        {
                            fail++;
                        }
                    }

                    sum += succ;
                    sum += fail;

                    Console.Write(curEnd + ";");
                    Console.Write(succ / sum + ";");
                    Console.Write(fail / sum + ";");

                    succ = 0;
                    fail = 0;

                    DateTime future = Date.AddHours(curEnd, hoursFuture);

                    opened = LogString.ParseOrders(list, "Profit Search Start Nr", curEnd, future);
                    sucessfull = LogString.ParseOrders(list, "Profit found", curEnd, end);
                    failed = LogString.ParseOrders(list, "Profit lost", curEnd, end);

                    foreach (string o in opened)
                    {
                        if (sucessfull.Contains(o))
                        {
                            succ++;
                        }
                        else if (failed.Contains(o))
                        {
                            fail++;
                        }
                    }
                    Console.WriteLine(succ + ";" + fail + ";");
                    cur = Date.AddHours(cur, hoursMove);
                } while (Date.AddHours(cur, hours + hoursFuture) < end);
            }
            else if (args[1] == "-at")
            {
                FileLines list = new FileLines();
                ProfitSearch pSearch = new ProfitSearch();
                double allEnded;

                list.ReadFile(args[0]);
                pSearch.AssignProfitSearchList();
                pSearch.SearchProfitStart(list);
                allEnded = pSearch.SearchProfitEnd(list);

                double all = 0.0;
                int am = 0;

                foreach (Profit p in pSearch.Trades)
                {
                    if ((p.TradeEnd - p.TradeBegin).TotalMinutes > 0)
                    {
                        all += (p.TradeEnd - p.TradeBegin).TotalMinutes;
                        if(WasWeekend(p.TradeBegin, p.TradeEnd))
                        {
                            all -= 48 * 60;
                        }
                        am++;
                    }
                }
                all /= am;
                Console.WriteLine("Trade Average in hours : {0}.", all / 60.0);
                Console.ReadLine();
            }
            else
            {
                CallingArguments();
                return;
            }
            Console.ReadLine();
        }
    }
}

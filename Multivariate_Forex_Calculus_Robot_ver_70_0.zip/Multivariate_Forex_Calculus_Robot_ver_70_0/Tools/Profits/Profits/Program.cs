﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using System;
using System.Globalization;
using System.IO;
using System.Linq;

namespace Profits
{
    class Program
    {
        static void Prompt()
        {
            Console.WriteLine("Profits.exe -mql4 filename.htm \"datetime\"");
            Console.WriteLine("Profits.exe -mql5 filename.html \"datetime\"");
            Console.ReadLine();
        }

        static string GetInnerString(string line)
        {
            return line.Substring(line.IndexOf('>') + 1, line.IndexOf('<', line.IndexOf('>') + 1) - line.IndexOf('>') - 1);
        }

        static int PosOf(string line, char sign, int occurence)
        {
            int pos = -1;
            int nr = 0;

            while (nr < occurence)
            {
                pos = line.IndexOf(sign, pos + 1);
                nr++;
            }
            return pos;
        }

        static bool ReadProfitMQL5(StreamReader reader, DateTime date, out double profit)
        {
            profit = 0.0;
            string line;
            string time;
            string prof;

            try
            {
                line = reader.ReadLine();
                line = reader.ReadLine();
                time = GetInnerString(line);
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                line = reader.ReadLine();
                prof = GetInnerString(line);
                line = reader.ReadLine();
                line = reader.ReadLine();

                if (DateTime.Parse(time) > date)
                {
                    Console.Write(" {0},", double.Parse(prof, CultureInfo.InvariantCulture));
                    profit = double.Parse(prof);
                }
                return true;
            }
            catch (Exception ex)
            {
                line = reader.ReadLine();
            }
            return false;
        }

        static bool ReadProfitMQL4(StreamReader reader, DateTime date, out double profit)
        {
            profit = 0.0;

            string line, tmp;
            string time;
            string prof;
            int pos;

            try
            {
                line = reader.ReadLine();
                pos = PosOf(line, '<', 4);
                tmp = line.Substring(pos + 1);
                time = GetInnerString(tmp);
                pos = PosOf(line, '<', 28);
                tmp = line.Substring(pos + 1);
                prof = GetInnerString(tmp);

                if (DateTime.Parse(time) > date)
                {
                    Console.Write(" {0},", double.Parse(prof, CultureInfo.InvariantCulture));
                    profit = double.Parse(prof);
                }
                return true;
            }
            catch (Exception ex)
            {
                line = reader.ReadLine();
            }
            return false;
        }

        static double ProfitsMQL4(StreamReader reader, DateTime date, out double tradesPosAm, out double tradesNegAm)
        {
            string line;
            tradesPosAm = 0;
            tradesNegAm = 0;
            double profits = 0.0, profit;

            while ((line = reader.ReadLine()) != null)
            {
                if (line.Contains("Closed Transactions:"))
                {
                    break;
                }
            }
            reader.ReadLine();
            reader.ReadLine();
            reader.ReadLine();
            reader.ReadLine();
            while (ReadProfitMQL4(reader, date, out profit))
            {
                profits += profit;
                if (profit > 0.0)
                {
                    tradesPosAm++;
                }
                else if(profit < 0.0)
                {
                    tradesNegAm++;
                }
            }
            return profits;
        }

        static double ProfitsMQL5(StreamReader reader, DateTime date, out double tradesPosAm, out double tradesNegAm)
        {
            string line;
            tradesPosAm = 0;
            tradesNegAm = 0;
            double profits = 0.0, profit;

            while ((line = reader.ReadLine()) != null)
            {
                if (line.Contains("Positions"))
                {
                    break;
                }
            }
            reader.ReadLine();
            ReadProfitMQL5(reader, date, out profit);
            while (ReadProfitMQL5(reader, date, out profit))
            {
                profits += profit;
                if (profit > 0.0)
                {
                    tradesPosAm++;
                }
                else if (profit < 0.0)
                {
                    tradesNegAm++;
                }
            }
            return profits;
        }

        static void Main(string[] args)
        {
            if (args.Count() < 3)
            {
                Prompt();
                return;
            }

            string fileName = args[1];
            DateTime date = DateTime.Parse(args[2]);
            double profits = 0.0;
            double tradesPosAm;
            double tradesNegAm;

            Console.WriteLine("filename : {0}.", fileName);
            Console.WriteLine("DateTime : {0}.", date);
            Console.WriteLine();
            Console.WriteLine("Profits : ");

            StreamReader reader = new StreamReader(fileName);

            if (args[0] == "-mql4")
            {
                profits = ProfitsMQL4(reader, date, out tradesPosAm, out tradesNegAm);
            }
            else if (args[0] == "-mql5")
            {
                profits = ProfitsMQL5(reader, date, out tradesPosAm, out tradesNegAm);
            }
            else
            {
                Prompt();
                return;
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Profits Sum : {0}.", profits);
            Console.WriteLine("Positive Trades Amount : {0}.", tradesPosAm);
            Console.WriteLine("Negative Trades Amount : {0}.", tradesNegAm);
            Console.WriteLine("Positive Trades Ratio : {0}.", (tradesPosAm)/(((tradesPosAm + tradesNegAm > 0) ? (tradesPosAm + tradesNegAm) : 1.0)));
            Console.ReadLine();
        }
    }
}

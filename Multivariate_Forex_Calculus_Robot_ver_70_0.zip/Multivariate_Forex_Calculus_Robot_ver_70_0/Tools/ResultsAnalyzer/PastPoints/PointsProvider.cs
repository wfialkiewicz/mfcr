﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using CommonLibrary;
using System;
using System.Collections.Generic;

namespace PastPoints
{
    public class PointsProvider
    {
        public GraphPoints GPoints { get; set; }
        public List<PastPoint> Points { get; set; }

        private static List<PastPoint> ReadPoints(string fileName)
        {
            FileLines list = new FileLines();
            ProfitSearch pSearch = new ProfitSearch();
            List<PastPoint> points = new List<PastPoint>();
            PastPoint point;

            list.ReadFile(fileName);
            pSearch.AssignProfitSearchList();
            pSearch.SearchProfitStart(list);
            pSearch.SearchProfitEnd(list);

            foreach (Profit p in pSearch.Trades)
            {
                point = new PastPoint();
                point.BeginTime = p.TradeBegin;
                point.EndTime = p.TradeEnd;
                point.Success = p.Successfull;
                point.Symbol = p.Symbol;

                points.Add(point);
            }

            return points;
        }

        private static void GetBeginEndDates(List<PastPoint> points, out DateTime BeginDate, out DateTime EndDate)
        {
            BeginDate = DateTime.MinValue;
            EndDate = DateTime.MaxValue;

            if (points != null && points.Count > 0)
            {
                BeginDate = points[0].BeginTime;
                EndDate = points[0].EndTime;

                foreach (PastPoint pp in points)
                {
                    if (pp.BeginTime < BeginDate)
                    {
                        BeginDate = pp.BeginTime;
                    }
                    if (pp.EndTime > EndDate)
                    {
                        EndDate = pp.EndTime;
                    }
                }
            }
        }

        private static List<GraphPoint> GetGraphPoints(List<PastPoint> points, DateTime BeginDate, DateTime EndDate, int SecondsStep)
        {
            List<GraphPoint> gpoints = new List<GraphPoint>();
            GraphPoint gpoint;

            for (DateTime date = BeginDate; date <= EndDate; date = date.AddSeconds(SecondsStep))
            {
                if (date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday)
                {
                    gpoint = new GraphPoint();
                    gpoint.Date = date;
                    gpoint.Value = GetOccurences(points, date);

                    gpoints.Add(gpoint);
                }
            }
            return gpoints;
        }

        private static double GetOccurences(List<PastPoint> points, DateTime point)
        {
            double occurences = 0.0;

            foreach (PastPoint pp in points)
            {
                if (pp.EndTime <= point)
                {
                    if (pp.Success)
                    {
                        occurences++;
                    }
                    else
                    {
                        occurences--;
                    }
                }
            }
            return occurences;
        }

        private double GetMaxValue()
        {
            double max = GPoints.Points[0].Value;

            foreach (GraphPoint gp in GPoints.Points)
            {
                if (gp.Value > max)
                {
                    max = gp.Value;
                }
            }
            return max;
        }

        private double GetMinValue()
        {
            double min = GPoints.Points[0].Value;

            foreach (GraphPoint gp in GPoints.Points)
            {
                if (gp.Value < min)
                {
                    min = gp.Value;
                }
            }
            return min;
        }

        private DateTime GetMaxDate()
        {
            DateTime max = GPoints.Points[0].Date;

            foreach (GraphPoint gp in GPoints.Points)
            {
                if (gp.Date > max)
                {
                    max = gp.Date;
                }
            }
            return max;
        }

        private DateTime GetMinDate()
        {
            DateTime min = GPoints.Points[0].Date;

            foreach (GraphPoint gp in GPoints.Points)
            {
                if (gp.Date < min)
                {
                    min = gp.Date;
                }
            }
            return min;
        }

        private DateTime GetMinPastPointDate(List<PastPoint> points)
        {
            DateTime date = DateTime.MaxValue;

            foreach (PastPoint pp in points)
            {
                if (pp.BeginTime < date)
                {
                    date = pp.BeginTime;
                }
            }
            return date;
        }

        private DateTime GetMaxPastPointDate(List<PastPoint> points)
        {
            DateTime date = DateTime.MinValue;

            foreach (PastPoint pp in points)
            {
                if (pp.EndTime > date)
                {
                    date = pp.EndTime;
                }
            }
            return date;
        }

        public void GetGraphPoints(string name)
        {
            List<PastPoint> points = ReadPoints(name);
            List<GraphPoint> gpoints = GetGraphPoints(points, GetMinPastPointDate(points), GetMaxPastPointDate(points), 60 * 60);

            Points = points;
            if (gpoints != null && gpoints.Count > 0)
            {
                GPoints = new GraphPoints();

                GPoints.Points = gpoints;
                GPoints.MinValue = GetMinValue();
                GPoints.MaxValue = GetMaxValue();
                GPoints.MinTime = GetMinDate();
                GPoints.MaxTime = GetMaxDate();
            }
        }

        public bool HasGraphPoints()
        {
            return GPoints != null;
        }

        private double PercentSuccesfull(DateTime dateBegin, DateTime dateEnd)
        {
            double successfull = 0.0;
            double failed = 0.0;

            foreach (PastPoint pp in Points)
            {
                if (pp.BeginTime >= dateBegin && pp.BeginTime <= dateEnd)
                {
                    if (pp.Success)
                    {
                        successfull++;
                    }
                    else
                    {
                        failed++;
                    }
                }
            }
            if (successfull + failed != 0.0)
            {
                return successfull / (successfull + failed);
            }
            else
            {
                return 0.0;
            }
        }

        public List<Results> GetResults(int pastHours, int futureHours)
        {
            List<Results> results = new List<Results>();
            double sum;

            for (int date = 0; date < GPoints.Points.Count - (pastHours + futureHours); date++)
            {
                sum = 0;
                for (int j = 0; j < pastHours; j++)
                {
                    sum += GPoints.Points[date + j].Value - GPoints.Points[date].Value;
                }
                Results res = new Results();

                res.Speed = (sum) / (double)(pastHours);
                res.PercentSuccesfull = WasFirstSuccesfull(GPoints.Points[date].Date.AddHours(pastHours));

                if (date > 0)
                {
                    res.Acceleration = (res.Speed - results[results.Count - 1].Speed) / (TimeSpan.FromTicks(GPoints.Points[date + pastHours].Date.Ticks - GPoints.Points[date + pastHours - 1].Date.Ticks).TotalSeconds);
                }
                else
                {
                    res.Acceleration = 0.0;
                }

                results.Add(res);
            }
            return results;
        }

        private DateTime FirstEnded(DateTime date)
        {
            foreach (PastPoint pp in Points)
            {
                if (pp.EndTime > date)
                {
                    return pp.EndTime;
                }
            }
            return DateTime.MaxValue;
        }

        private double WasFirstSuccesfull(DateTime date)
        {
            DateTime end = FirstEnded(date);
            double success = 0.0;
            double failed = 0.0;

            foreach (PastPoint pp in Points)
            {
                if (pp.BeginTime > date && pp.BeginTime < end)
                {
                    if (pp.Success)
                    {
                        success++;
                    }
                    else
                    {
                        failed++;
                    }
                }
            }
            if (success + failed > 0.0d)
            {
                return success / (success + failed);
            }
            else
            {
                return 0.0d;
            }
        }
    }
}

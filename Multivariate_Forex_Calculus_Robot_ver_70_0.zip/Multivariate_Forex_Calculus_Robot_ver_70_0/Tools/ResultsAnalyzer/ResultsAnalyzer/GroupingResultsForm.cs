﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using PastPoints;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace ResultsAnalyzer
{
    public partial class GroupingResultsForm : Form
    {
        private List<Results> Results { get; set; }

        public GroupingResultsForm()
        {
            InitializeComponent();
        }

        private double MinSpeedResult()
        {
            double speed = double.MaxValue;

            foreach (Results r in Results)
            {
                if (r.Speed < speed)
                {
                    speed = r.Speed;
                }
            }
            return speed;
        }

        private double MaxSpeedResult()
        {
            double speed = double.MinValue;

            foreach (Results r in Results)
            {
                if (r.Speed > speed)
                {
                    speed = r.Speed;
                }
            }
            return speed;
        }


        public void AddResults(List<Results> res)
        {
            dataGridView.Rows.Clear();
            Results = res;
            List<GroupingResults> gres = new List<GroupingResults>();

            double minSpeed = MinSpeedResult();
            double maxSpeed = MaxSpeedResult();

            for (int i = 1; i < 100; i++)
            {
                for (double s = minSpeed; s <= maxSpeed - (maxSpeed - minSpeed) / i; s += ((maxSpeed - minSpeed) / 100.0))
                {
                    double ds = s + ((maxSpeed - minSpeed) / i);
                    double sum = 0.0;
                    int am = 0;
                    double minAcc = 0.0;
                    double maxAcc = 0.0;

                    foreach (Results r in Results)
                    {
                        if (r.Speed >= s && r.Speed <= ds)
                        {
                            sum += r.PercentSuccesfull;
                            am++;
                            if(minAcc > r.Acceleration)
                            {
                                minAcc = r.Acceleration;
                            }
                            if(maxAcc < r.Acceleration)
                            {
                                maxAcc = r.Acceleration;
                            }
                        }
                    }
                    if (am > 0)
                    {
                        sum /= am;
                    }
                    else
                    {
                        sum = 0.0;
                    }
                    GroupingResults gr = new GroupingResults();

                    gr.MinAcceleration = minAcc;
                    gr.MaxAcceleration = maxAcc;
                    gr.MinSpeed = s;
                    gr.MaxSpeed = ds;
                    gr.PercentSuccesfull = sum;
                    gr.AmountPoints = am;
                    gr.PercentAll = am /(double)Results.Count();

                    if (sum >= 0.5)
                    {
                        gr.Order = (sum - 0.5) * am;
                    }
                    else
                    {
                        gr.Order = (0.5 - sum) * am;
                    }

                    gres.Add(gr);
                }
            }


            foreach (GroupingResults gr in gres)
            {
                DataGridViewRow row = (DataGridViewRow)dataGridView.RowTemplate.Clone();

                row.CreateCells(dataGridView, gr.MinSpeed, gr.MaxSpeed, gr.PercentSuccesfull, gr.AmountPoints, gr.Order, gr.PercentAll, gr.MinAcceleration, gr.MaxAcceleration);
                dataGridView.Rows.Add(row);
            }
        }

        private void buttonChoose_Click(object sender, EventArgs e)
        {
            double percentAllPointsMin = double.Parse(textBoxPercentAllPoints.Text, CultureInfo.InvariantCulture);
            double percentAllPointsMax = double.Parse(textBoxPercentAllMax.Text, CultureInfo.InvariantCulture);
            double minSpeed = double.MinValue;
            double maxSpeed = double.MaxValue;
            double sum = 0.0;
            int am = 0;
            double minAcc = double.MinValue;
            double maxAcc = double.MaxValue;

            if(checkBoxOver50.Checked)
            {
                foreach(DataGridViewRow dr in dataGridView.Rows)
                {
                    if (dr.Cells[0].Value != null)
                    {
                        if ((double)dr.Cells[5].Value >= percentAllPointsMin && (double)dr.Cells[5].Value <= percentAllPointsMax && (double)dr.Cells[2].Value >= 0.5d)
                        {
                            if (minSpeed < (double)dr.Cells[0].Value)
                            {
                                minSpeed = (double)dr.Cells[0].Value;
                            }
                            if (maxSpeed > (double)dr.Cells[1].Value)
                            {
                                maxSpeed = (double)dr.Cells[1].Value;
                            }
                            if (minAcc < (double)dr.Cells[6].Value)
                            {
                                minAcc = (double)dr.Cells[6].Value;
                            }
                            if (maxAcc > (double)dr.Cells[7].Value)
                            {
                                maxAcc = (double)dr.Cells[7].Value;
                            }

                            sum += (double)dr.Cells[2].Value;
                            am++;
                        }
                    }
                }
            }
            else
            {
                foreach (DataGridViewRow dr in dataGridView.Rows)
                {
                    if (dr.Cells[0].Value != null)
                    {
                        if ((double)dr.Cells[5].Value >= percentAllPointsMin && (double)dr.Cells[5].Value <= percentAllPointsMax && (double)dr.Cells[2].Value < 0.5d)
                        {
                            if (minSpeed < (double)dr.Cells[0].Value)
                            {
                                minSpeed = (double)dr.Cells[0].Value;
                            }
                            if (maxSpeed > (double)dr.Cells[1].Value)
                            {
                                maxSpeed = (double)dr.Cells[1].Value;
                            }
                            if (minAcc < (double)dr.Cells[6].Value)
                            {
                                minAcc = (double)dr.Cells[6].Value;
                            }
                            if (maxAcc > (double)dr.Cells[7].Value)
                            {
                                maxAcc = (double)dr.Cells[7].Value;
                            }

                            sum += (double)dr.Cells[2].Value;
                            am++;
                        }
                    }
                }
            }
            if(am > 0)
            {
                double overallPercent = sum / am;

                ChoosenForm form = new ChoosenForm();

                form.MdiParent = (Form)this.Parent.Parent;
                form.SetValues(minSpeed, maxSpeed, minAcc, maxAcc, overallPercent);

                form.Show();
            }
            else
            {
                MessageBox.Show("No Points.");
            }
        }
    }
}

﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using PastPoints;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ResultsAnalyzer
{
    public partial class UCGraph : UserControl
    {
        public PointsProvider Provider { get; set; }

        public UCGraph()
        {
            InitializeComponent();
            dateTimePickerBegin.CustomFormat = "MM/dd/yyyy HH:mm";
            dateTimePickerEnd.CustomFormat = "MM/dd/yyyy HH:mm";
        }

        private void DrawLine(Graphics g, float width, float height, float xBeg, float yBeg, float xEnd, float yEnd, Color color)
        {
            xBeg = xBeg * width;
            xEnd = xEnd * width;
            yBeg = height - yBeg * height;
            yEnd = height - yEnd * height;

            g.DrawLine(new Pen(color), xBeg, yBeg, xEnd, yEnd);
        }

        private void panelGraph_Paint(object sender, PaintEventArgs e)
        {
            textBoxStartAmount.Text = ((int)Provider.GPoints.Points[0].Value).ToString();
            dateTimePickerBegin.Value = Provider.GPoints.Points[0].Date;
            dateTimePickerEnd.Value = Provider.GPoints.Points[Provider.GPoints.Points.Count() - 1].Date;

            Graphics g = panelGraph.CreateGraphics();

            g.Clear(Color.White);

            float minValue = (float)Provider.GPoints.MinValue;
            float maxValue = (float)Provider.GPoints.MaxValue;
            double MinTime = Provider.GPoints.MinTime.Ticks;
            double MaxTime = Provider.GPoints.MaxTime.Ticks;
            int daysCount = 0;

            for (DateTime date = Provider.GPoints.MinTime; date <= Provider.GPoints.MaxTime; date = date.AddDays(1))
            {
                if (date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday)
                {
                    daysCount++;
                }
            }

            for (int i = 0; i < daysCount + 1; i++)
            {
                DrawLine(g, panelGraph.Width, panelGraph.Height, i * (1.0f / daysCount), 0.0f, i * (1.0f / daysCount), 1.0f, Color.Green);
            }

            DrawLine(g, panelGraph.Width, panelGraph.Height, 0.0f, (0.5f - minValue) / (maxValue - minValue), 1.0f, (0.5f - minValue) / (maxValue - minValue), Color.Green);

            for (int i = 0; i < Provider.GPoints.Points.Count - 1; i++)
            {
                DrawLine(g, panelGraph.Width, panelGraph.Height, (float)((Provider.GPoints.Points[i].Date.Ticks - MinTime) / (MaxTime - MinTime)), (float)(Provider.GPoints.Points[i].Value - minValue) / (maxValue - minValue), (float)((Provider.GPoints.Points[i + 1].Date.Ticks - MinTime) / (MaxTime - MinTime)), (float)(Provider.GPoints.Points[i + 1].Value - minValue) / (maxValue - minValue), Color.Blue);
            }
        }

        private void panelGraph_Resize(object sender, EventArgs e)
        {
            panelGraph.Invalidate();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            ResultsForm form = new ResultsForm();

            form.AddResults(Provider.GetResults(int.Parse(textBoxLastHours.Text), 1));
            form.MdiParent = (Form)this.Parent.Parent.Parent;
            form.Show();
        }
    }
}

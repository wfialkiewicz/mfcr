﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using PastPoints;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace ResultsAnalyzer
{
    public partial class ResultsForm : Form
    {
        private List<Results> Results { get; set; }

        public ResultsForm()
        {
            InitializeComponent();
        }

        public void AddResults(List<Results> res)
        {
            dataGridView.Rows.Clear();
            Results = res;

            foreach (Results r in res)
            {
                DataGridViewRow row = (DataGridViewRow)dataGridView.RowTemplate.Clone();

                row.CreateCells(dataGridView, r.Speed, r.PercentSuccesfull);
                dataGridView.Rows.Add(row);
            }
        }

        private void buttonShow_Click(object sender, System.EventArgs e)
        {
            SpeedResults form = new SpeedResults();

            form.Results = Results;
            form.MdiParent = (Form)this.Parent.Parent;
            form.Show();
        }

        private void buttonGroupingResults_Click(object sender, System.EventArgs e)
        {
            GroupingResultsForm form = new GroupingResultsForm();

            form.AddResults(Results);
            form.MdiParent = (Form)this.Parent.Parent;
            form.Show();

        }
    }
}

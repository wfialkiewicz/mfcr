﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

namespace ResultsAnalyzer
{
    partial class GroupingResultsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.MinSpeed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxSpeed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PercentSuccesfull = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AmountPoints = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Order = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PercentAllPoints = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBoxOver50 = new System.Windows.Forms.CheckBox();
            this.textBoxPercentAllPoints = new System.Windows.Forms.TextBox();
            this.buttonChoose = new System.Windows.Forms.Button();
            this.textBoxPercentAllMax = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.MinAcceleration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxAcceleration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView
            // 
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MinSpeed,
            this.MaxSpeed,
            this.PercentSuccesfull,
            this.AmountPoints,
            this.Order,
            this.PercentAllPoints,
            this.MinAcceleration,
            this.MaxAcceleration});
            this.dataGridView.Location = new System.Drawing.Point(12, 12);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(891, 367);
            this.dataGridView.TabIndex = 0;
            // 
            // MinSpeed
            // 
            this.MinSpeed.HeaderText = "MinSpeed";
            this.MinSpeed.Name = "MinSpeed";
            // 
            // MaxSpeed
            // 
            this.MaxSpeed.HeaderText = "MaxSpeed";
            this.MaxSpeed.Name = "MaxSpeed";
            // 
            // PercentSuccesfull
            // 
            this.PercentSuccesfull.HeaderText = "PercentSuccesfull";
            this.PercentSuccesfull.Name = "PercentSuccesfull";
            // 
            // AmountPoints
            // 
            this.AmountPoints.HeaderText = "AmountPoints";
            this.AmountPoints.Name = "AmountPoints";
            // 
            // Order
            // 
            this.Order.HeaderText = "Order";
            this.Order.Name = "Order";
            // 
            // PercentAllPoints
            // 
            this.PercentAllPoints.HeaderText = "PercentAllPoints";
            this.PercentAllPoints.Name = "PercentAllPoints";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(90, 413);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Percent All Points Min : ";
            // 
            // checkBoxOver50
            // 
            this.checkBoxOver50.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxOver50.AutoSize = true;
            this.checkBoxOver50.Location = new System.Drawing.Point(12, 412);
            this.checkBoxOver50.Name = "checkBoxOver50";
            this.checkBoxOver50.Size = new System.Drawing.Size(72, 17);
            this.checkBoxOver50.TabIndex = 2;
            this.checkBoxOver50.Text = "Over 50%";
            this.checkBoxOver50.UseVisualStyleBackColor = true;
            // 
            // textBoxPercentAllPoints
            // 
            this.textBoxPercentAllPoints.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxPercentAllPoints.Location = new System.Drawing.Point(212, 410);
            this.textBoxPercentAllPoints.Name = "textBoxPercentAllPoints";
            this.textBoxPercentAllPoints.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBoxPercentAllPoints.Size = new System.Drawing.Size(100, 20);
            this.textBoxPercentAllPoints.TabIndex = 3;
            this.textBoxPercentAllPoints.Text = "0.8";
            // 
            // buttonChoose
            // 
            this.buttonChoose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonChoose.Location = new System.Drawing.Point(571, 408);
            this.buttonChoose.Name = "buttonChoose";
            this.buttonChoose.Size = new System.Drawing.Size(75, 23);
            this.buttonChoose.TabIndex = 4;
            this.buttonChoose.Text = "Choose";
            this.buttonChoose.UseVisualStyleBackColor = true;
            this.buttonChoose.Click += new System.EventHandler(this.buttonChoose_Click);
            // 
            // textBoxPercentAllMax
            // 
            this.textBoxPercentAllMax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxPercentAllMax.Location = new System.Drawing.Point(443, 410);
            this.textBoxPercentAllMax.Name = "textBoxPercentAllMax";
            this.textBoxPercentAllMax.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBoxPercentAllMax.Size = new System.Drawing.Size(100, 20);
            this.textBoxPercentAllMax.TabIndex = 6;
            this.textBoxPercentAllMax.Text = "1.0";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(321, 413);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Percent All Points Max : ";
            // 
            // MinAcceleration
            // 
            this.MinAcceleration.HeaderText = "MinAcceleration";
            this.MinAcceleration.Name = "MinAcceleration";
            // 
            // MaxAcceleration
            // 
            this.MaxAcceleration.HeaderText = "MaxAcceleration";
            this.MaxAcceleration.Name = "MaxAcceleration";
            // 
            // GroupingResultsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 450);
            this.Controls.Add(this.textBoxPercentAllMax);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonChoose);
            this.Controls.Add(this.textBoxPercentAllPoints);
            this.Controls.Add(this.checkBoxOver50);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView);
            this.Name = "GroupingResultsForm";
            this.Text = "Grouping Results";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinSpeed;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaxSpeed;
        private System.Windows.Forms.DataGridViewTextBoxColumn PercentSuccesfull;
        private System.Windows.Forms.DataGridViewTextBoxColumn AmountPoints;
        private System.Windows.Forms.DataGridViewTextBoxColumn Order;
        private System.Windows.Forms.DataGridViewTextBoxColumn PercentAllPoints;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBoxOver50;
        private System.Windows.Forms.TextBox textBoxPercentAllPoints;
        private System.Windows.Forms.Button buttonChoose;
        private System.Windows.Forms.TextBox textBoxPercentAllMax;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinAcceleration;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaxAcceleration;
    }
}
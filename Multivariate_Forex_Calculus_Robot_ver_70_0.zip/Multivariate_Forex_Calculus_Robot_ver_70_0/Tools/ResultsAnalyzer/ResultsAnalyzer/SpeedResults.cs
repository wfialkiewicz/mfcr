﻿/*Copyright 2022 Inconsoft Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.*/

using PastPoints;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ResultsAnalyzer
{
    public partial class SpeedResults : Form
    {
        public List<Results> Results { get; set; }

        public SpeedResults()
        {
            InitializeComponent();
        }

        private void DrawLine(Graphics g, float width, float height, float xBeg, float yBeg, float xEnd, float yEnd, Color color)
        {
            xBeg = xBeg * width;
            xEnd = xEnd * width;
            yBeg = height - yBeg * height;
            yEnd = height - yEnd * height;

            g.DrawLine(new Pen(color), xBeg, yBeg, xEnd, yEnd);
        }

        private void DrawDot(Graphics g, float width, float height, float xBeg, float yBeg, Color color)
        {
            xBeg = xBeg * width;
            yBeg = height - yBeg * height;

            g.DrawRectangle(new Pen(color), xBeg, yBeg, 1, 1);
        }

        private void panelGraph_Resize(object sender, EventArgs e)
        {
            panelGraph.Invalidate();
        }

        private double GetMinSpeed()
        {
            double speed = double.MaxValue;

            foreach (Results r in Results)
            {
                if (r.Speed < speed)
                {
                    speed = r.Speed;
                }
            }
            return speed;
        }

        private double GetMaxSpeed()
        {
            double speed = double.MinValue;

            foreach (Results r in Results)
            {
                if (r.Speed > speed)
                {
                    speed = r.Speed;
                }
            }
            return speed;
        }

        private double GetMinPercent()
        {
            double speed = double.MaxValue;

            foreach (Results r in Results)
            {
                if (r.PercentSuccesfull < speed)
                {
                    speed = r.PercentSuccesfull;
                }
            }
            return speed;
        }

        private double GetMaxPercent()
        {
            double speed = double.MinValue;

            foreach (Results r in Results)
            {
                if (r.PercentSuccesfull > speed)
                {
                    speed = r.PercentSuccesfull;
                }
            }
            return speed;
        }

        private void panelGraph_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = panelGraph.CreateGraphics();

            float minValue = (float)GetMinPercent();
            float maxValue = (float)GetMaxPercent();
            double MinTime = GetMinSpeed();
            double MaxTime = GetMaxSpeed();

            g.Clear(Color.White);
            DrawLine(g, panelGraph.Width, panelGraph.Height, 0.0f, (0.5f - minValue) / (maxValue - minValue), 1.0f, (0.5f - minValue) / (maxValue - minValue), Color.Green);

            foreach (Results r in Results)
            {
                DrawDot(g, panelGraph.Width, panelGraph.Height, (float)((r.Speed - MinTime) / (MaxTime - MinTime)), (float)((r.PercentSuccesfull - minValue) / (maxValue - minValue)), Color.Green);
            }
        }
    }
}
